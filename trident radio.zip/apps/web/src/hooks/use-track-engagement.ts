import { useCallback, useEffect, useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbase-client';

type Reaction = 'like' | 'dislike';

type ReactionRecord = { id: string; track: string; kind: Reaction };
type PlaylistRecord = { id: string; track: string };
type FollowRecord = { id: string; artist: string };

/**
 * Per-user track engagement: thumbs-up/down reactions, personal playlist
 * membership, and artist follows. All data is owner-scoped in PocketBase, so
 * each signed-in user only sees and changes their own records. When signed out,
 * every state map is empty and the toggles are no-ops (callers gate the UI on
 * `isAuthed` and surface a sign-in link instead).
 */
export function useTrackEngagement() {
	const { isAuthed } = useAuth();
	const [reactions, setReactions] = useState<Record<string, Reaction>>({});
	const [reactionIds, setReactionIds] = useState<Record<string, string>>({});
	const [playlistIds, setPlaylistIds] = useState<Set<string>>(new Set());
	const [playlistRecordIds, setPlaylistRecordIds] = useState<Record<string, string>>({});
	const [follows, setFollows] = useState<Set<string>>(new Set());
	const [followIds, setFollowIds] = useState<Record<string, string>>({});
	const [busy, setBusy] = useState(false);

	useEffect(() => {
		if (!isAuthed) {
			setReactions({});
			setReactionIds({});
			setPlaylistIds(new Set());
			setPlaylistRecordIds({});
			setFollows(new Set());
			setFollowIds({});
			return;
		}
		let cancelled = false;
		void (async () => {
			try {
				const [reacts, items, followList] = await Promise.all([
					pb.collection('track_reactions').getFullList<ReactionRecord>({ requestKey: 'eng-reactions' }),
					pb.collection('playlist_items').getFullList<PlaylistRecord>({ requestKey: 'eng-playlist' }),
					pb.collection('follows').getFullList<FollowRecord>({ requestKey: 'eng-follows' }),
				]);
				if (cancelled) return;
				const r: Record<string, Reaction> = {};
				const rids: Record<string, string> = {};
				for (const x of reacts) {
					r[x.track] = x.kind;
					rids[x.track] = x.id;
				}
				setReactions(r);
				setReactionIds(rids);
				setPlaylistIds(new Set(items.map((i) => i.track)));
				const prids: Record<string, string> = {};
				for (const i of items) prids[i.track] = i.id;
				setPlaylistRecordIds(prids);
				setFollows(new Set(followList.map((f) => f.artist)));
				const fids: Record<string, string> = {};
				for (const f of followList) fids[f.artist] = f.id;
				setFollowIds(fids);
			} catch {
				/* owner-scoped reads may fail silently when signed out mid-flight */
			}
		})();
		return () => {
			cancelled = true;
		};
	}, [isAuthed]);

	const toggleReaction = useCallback(
		async (trackId: string, kind: Reaction) => {
			if (!isAuthed) return;
			const uid = pb.authStore.record?.id;
			if (!uid) return;
			setBusy(true);
			try {
				const existingKind = reactions[trackId];
				const existingId = reactionIds[trackId];
				if (existingKind === kind && existingId) {
					await pb.collection('track_reactions').delete(existingId);
					setReactions((prev) => {
						const n = { ...prev };
						delete n[trackId];
						return n;
					});
					setReactionIds((prev) => {
						const n = { ...prev };
						delete n[trackId];
						return n;
					});
				} else if (existingId) {
					await pb.collection('track_reactions').update(existingId, { kind });
					setReactions((prev) => ({ ...prev, [trackId]: kind }));
				} else {
					const rec = await pb
						.collection('track_reactions')
						.create({ track: trackId, kind, owner: uid });
					setReactions((prev) => ({ ...prev, [trackId]: kind }));
					setReactionIds((prev) => ({ ...prev, [trackId]: rec.id }));
				}
			} catch {
				/* validation / rule errors are surfaced via the busy flag only */
			} finally {
				setBusy(false);
			}
		},
		[isAuthed, reactions, reactionIds],
	);

	const togglePlaylist = useCallback(
		async (trackId: string) => {
			if (!isAuthed) return;
			const uid = pb.authStore.record?.id;
			if (!uid) return;
			setBusy(true);
			try {
				const existingId = playlistRecordIds[trackId];
				if (existingId) {
					await pb.collection('playlist_items').delete(existingId);
					setPlaylistIds((prev) => {
						const n = new Set(prev);
						n.delete(trackId);
						return n;
					});
					setPlaylistRecordIds((prev) => {
						const n = { ...prev };
						delete n[trackId];
						return n;
					});
				} else {
					const rec = await pb
						.collection('playlist_items')
						.create({ track: trackId, owner: uid });
					setPlaylistIds((prev) => new Set(prev).add(trackId));
					setPlaylistRecordIds((prev) => ({ ...prev, [trackId]: rec.id }));
				}
			} catch {
				/* ignore */
			} finally {
				setBusy(false);
			}
		},
		[isAuthed, playlistRecordIds],
	);

	const toggleFollow = useCallback(
		async (artistId: string) => {
			if (!isAuthed) return;
			const uid = pb.authStore.record?.id;
			if (!uid) return;
			setBusy(true);
			try {
				const existingId = followIds[artistId];
				if (existingId) {
					await pb.collection('follows').delete(existingId);
					setFollows((prev) => {
						const n = new Set(prev);
						n.delete(artistId);
						return n;
					});
					setFollowIds((prev) => {
						const n = { ...prev };
						delete n[artistId];
						return n;
					});
				} else {
					const rec = await pb
						.collection('follows')
						.create({ artist: artistId, owner: uid });
					setFollows((prev) => new Set(prev).add(artistId));
					setFollowIds((prev) => ({ ...prev, [artistId]: rec.id }));
				}
			} catch {
				/* ignore */
			} finally {
				setBusy(false);
			}
		},
		[isAuthed, followIds],
	);

	return {
		isAuthed,
		reactions,
		playlistIds,
		follows,
		busy,
		toggleReaction,
		togglePlaylist,
		toggleFollow,
	};
}
