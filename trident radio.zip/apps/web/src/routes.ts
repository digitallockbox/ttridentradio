import { type RouteConfig, index, route } from '@react-router/dev/routes';

export default [
	index('routes/home.tsx'),
	route('station', 'routes/station.tsx'),
	route('artist', 'routes/artist.tsx'),
	route('playbook', 'routes/playbook.tsx'),
	route('podcast', 'routes/podcast.tsx'),
	route('playlist', 'routes/playlist.tsx'),
	route('login', 'routes/login.tsx'),
	route('signup', 'routes/signup.tsx'),
	route('account', 'routes/account.tsx'),
	route('checkout/success', 'routes/checkout.success.tsx'),
	route('checkout/cancelled', 'routes/checkout.cancelled.tsx'),
	route('sitemap.xml', 'routes/sitemap.xml.ts'),
	route('robots.txt', 'routes/robots.txt.ts'),
	route('api/health', 'routes/api.health.ts'),
	route('api/v1/radio', 'routes/api.v1.radio.ts'),
	route('api/v1/radio/update', 'routes/api.v1.radio.update.ts'),
	route('api/v1/upload', 'routes/api.v1.upload.ts'),
	route('api/*', 'routes/api.$.ts'),
] satisfies RouteConfig;
