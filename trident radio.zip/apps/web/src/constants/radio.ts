export const RADIO_ART = 'https://images.hostinger.com/f6881439-8a7e-4aec-a226-489cfe40cc9a/4605273b-0870-4e8f-af06-1a5d1d0a809a.png';
export const RADIO_ART_SRCSET = `${RADIO_ART}?width=375 375w, ${RADIO_ART}?width=768 768w, ${RADIO_ART} 1024w`;
export type PlaybackState = 'disconnected' | 'ready' | 'connecting' | 'playing' | 'paused' | 'error';
export const STATE_LABELS: Record<PlaybackState, string> = {
  disconnected: 'Stream not connected', ready: 'Ready to listen', connecting: 'Connecting to stream', playing: 'You’re listening live', paused: 'Playback paused', error: 'Connection interrupted',
};
