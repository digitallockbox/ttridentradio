import {
	data,
	isRouteErrorResponse,
	Links,
	Meta,
	Outlet,
	Scripts,
	ScrollRestoration,
	useLoaderData,
} from 'react-router';
import type { Route } from './+types/root';
import stylesheet from '@/index.css?url';
import dashboardStylesheet from '@/dashboard.css?url';
import { siteOrigin } from '@/lib/site-origin.server';
import { getConfig as getRadioConfig } from '@/lib/radio-engine.server';
import { HorizonsPreviewScripts } from '@/horizons-preview-scripts';
import { RadioProvider } from '@/components/radio-provider';
import { UploadProvider } from '@/components/upload-dialog';
import { CartProvider } from '@/hooks/use-ecommerce-cart';
import { SiteShell } from '@/components/site-shell';
import { PersistentPlayer } from '@/components/persistent-player';
import { StreamDialog } from '@/components/stream-dialog';
import { CookieBanner } from '@/components/cookie-banner';

export const links: Route.LinksFunction = () => [
	{ rel: 'stylesheet', href: stylesheet, precedence: 'default' },
	{ rel: 'stylesheet', href: dashboardStylesheet },
	{ rel: 'icon', href: '/favicon.png', type: 'image/png' },
	{ rel: 'preconnect', href: 'https://fonts.googleapis.com' },
	{
		rel: 'preconnect',
		href: 'https://fonts.gstatic.com',
		crossOrigin: 'anonymous',
	},
	{
		rel: 'stylesheet',
		href: 'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;650;700;750;800&display=swap',
	},
];

/**
 * Publishes the site's public origin, which `seo()` reads to build canonical and
 * `og:url` tags, and advertises the sitemap to crawlers that read response
 * headers rather than HTML.
 *
 * A `meta` export can only reach server data through `matches`, and the `headers`
 * export cannot see loader data at all, so both have to travel this way.
 */
export function loader({ request }: Route.LoaderArgs) {
	const origin = siteOrigin(request);
	// The official stream comes from the radio ingest config (updated via
	// POST /api/v1/radio/update), with the TRIDENT_STREAM_URL env var as a
	// deploy-time override.
	const radioConfig = getRadioConfig();
	const configuredSource = process.env.TRIDENT_STREAM_URL || radioConfig.streamUrl || '';
	let streamSource = '';
	try {
		const url = new URL(configuredSource);
		if (url.protocol === 'https:' && !url.username && !url.password) streamSource = url.href;
	} catch { /* No official stream is configured yet. */ }

	return data(
		{ origin, streamSource },
		{ headers: { Link: `<${origin}/sitemap.xml>; rel="sitemap"; type="application/xml"` } },
	);
}

/**
 * A page route that exports `headers` replaces this one, so merge `parentHeaders`
 * there rather than returning only that route's own headers.
 */
export function headers({ loaderHeaders }: Route.HeadersArgs) {
	return loaderHeaders;
}

export function Layout({ children }: { children: React.ReactNode }) {
	return (
		// suppressHydrationWarning absorbs attributes injected by browser extensions
		// and theme scripts before hydration; attribute-only, one element deep. Keep both.
		<html lang="en" suppressHydrationWarning>
			<head>
				<meta charSet="utf-8" />
				<meta name="viewport" content="width=device-width, initial-scale=1" />
				<Meta />
				<Links />
				<HorizonsPreviewScripts />
			</head>
			<body suppressHydrationWarning>
				<div id="root">{children}</div>
				<CookieBanner />
				<ScrollRestoration />
				<Scripts />
			</body>
		</html>
	);
}

export default function App() {
	const { streamSource } = useLoaderData<typeof loader>();
	return <RadioProvider initialSource={streamSource}><UploadProvider><CartProvider><SiteShell><Outlet /></SiteShell><PersistentPlayer /><StreamDialog /></CartProvider></UploadProvider></RadioProvider>;
}

export function ErrorBoundary({ error }: Route.ErrorBoundaryProps) {
	const isClientErrorResponse = isRouteErrorResponse(error) && error.status < 500;

	if (import.meta.env.DEV && !isClientErrorResponse) {
		return null;
	}

	let message = 'Oops!';
	let details = 'An unexpected error occurred.';

	if (isRouteErrorResponse(error)) {
		message = error.status === 404 ? '404' : 'Error';
		details = error.status === 404 ? 'The requested page could not be found.' : error.statusText || details;
	}

	return (
		<main>
			<h1>{message}</h1>
			<p>{details}</p>
		</main>
	);
}
