/**
 * Artist profile for Anthony D. Simmons, the founding artist on Trident Radio.
 *
 * The name, role, and label are the artist's own profile details. Tracks shown
 * on the artist page are the real audio the artist uploads through the
 * CreatorOS upload flow — there is no placeholder catalog here.
 */
export const ARTIST = {
	name: 'Anthony D. Simmons',
	initials: 'AS',
	role: 'Independent R&B / Trap-Soul Artist',
	label: 'Brickyard Beats',
	summary:
		'Independent R&B and Trap-Soul artist on the Trident Radio roster. Tracks added through the CreatorOS upload flow play in the Trident player and can be activated into rotation.',
};
