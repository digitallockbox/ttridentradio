/**
 * Creator Campaign Playbook content for tridentradio.live.
 *
 * Every capability below is an EXTERNAL artist-platform tool or concept.
 * None are connected to this site, and none are claimed as configured, verified,
 * or delivering results here. Availability depends on account access, eligibility,
 * region, and the platform's current terms. No specific platform is endorsed or
 * integrated, and no artist music or profile is imported into Trident Radio.
 */

export type PlaybookItem = {
	icon: string;
	title: string;
	body: string;
};

export type PlaybookSection = {
	id: string;
	eyebrow: string;
	title: string;
	intro: string;
	items: PlaybookItem[];
};

export const PLAYBOOK_SECTIONS: PlaybookSection[] = [
	{
		id: 'account-setup',
		eyebrow: 'SECTION 01',
		title: 'Account access & setup essentials',
		intro: 'The foundation for running tridentradio.live as a creator presence on a streaming artist platform. These are external account-management steps, not features wired into this site.',
		items: [
			{
				icon: 'LogIn',
				title: 'Login & apps',
				body: 'Access your artist-platform management dashboard securely using your official tridentradio.live creator credentials. For day-to-day team monitoring and live metrics on the go, use the platform’s companion mobile app alongside its standard listener app (iOS, Android, and Desktop).',
			},
			{
				icon: 'ShieldCheck',
				title: 'Account & payment',
				body: 'Configure team access permissions, secure your login with multi-factor authentication, and set up your billing profile to seamlessly run paid promotion tools for your station’s releases.',
			},
			{
				icon: 'Music',
				title: 'Music & distribution',
				body: 'Ensure all audio broadcasts, radio sessions, and station releases distributed under the tridentradio.live banner are cleanly delivered with accurate metadata and proper sonic formatting.',
			},
		],
	},
	{
		id: 'campaign-kit',
		eyebrow: 'SECTION 02',
		title: 'Promotion & discovery toolkit',
		intro: 'A target-driven promotional suite for growing an audience on a streaming platform. Eligibility, pricing, and availability are governed by the platform’s current terms — not by this site.',
		items: [
			{
				icon: 'Compass',
				title: 'Algorithmic discovery',
				body: 'Opt eligible tracks into algorithmic recommendation feeds (such as radio, autoplay, and personalized mixes) to expand your listener base — often processed via a commission on streams generated in those specific contexts, with no upfront ad spend.',
			},
			{
				icon: 'Megaphone',
				title: 'Sponsored recommendations',
				body: 'Full-screen sponsored mobile recommendations designed to capture high-intent attention during a new release drop.',
			},
			{
				icon: 'LayoutDashboard',
				title: 'Home banner placement',
				body: 'A targeted banner placement on the platform’s home screen to spotlight fresh tracks, revive catalog favorites, or drive traffic to special broadcast events.',
			},
			{
				icon: 'ListMusic',
				title: 'Editorial pitching',
				body: 'Pitch unreleased singles or station compilations directly to the platform’s editorial team via your dashboard (ideal for pitching 4–6 weeks prior to release), alongside independent and algorithmic curation strategies.',
			},
		],
	},
	{
		id: 'visual-branding',
		eyebrow: 'SECTION 03',
		title: 'Video & visual branding',
		intro: 'Establish a distinct, unforgettable aesthetic for tridentradio.live that translates broadcast energy into a visual experience on the platform.',
		items: [
			{
				icon: 'UserCircle',
				title: 'Artist profile',
				body: 'Customize your hero banner, high-res profile photo, verified bio, social links, and pin active milestones using your artist pick — ideal for pointing fans straight to tridentradio.live.',
			},
			{
				icon: 'Clapperboard',
				title: 'Looping track visuals',
				body: 'Add a short looping vertical visualizer to every track to dramatically increase track shares and saves.',
			},
			{
				icon: 'Timer',
				title: 'Countdown pages',
				body: 'Build pre-release hype by letting fans preview tracklists, pre-save upcoming drops, view live countdown timers, and grab station merch.',
			},
			{
				icon: 'Share2',
				title: 'Shareable promo graphics',
				body: 'Generate custom, shareable graphics optimized for social media to announce milestones, charts, or new station episodes.',
			},
			{
				icon: 'Video',
				title: 'Music videos',
				body: 'Upload official visual media directly to your tracks to give fans an immersive in-app viewing experience.',
			},
		],
	},
	{
		id: 'monetization',
		eyebrow: 'SECTION 04',
		title: 'Merch, live events & monetization',
		intro: 'Turn passive listeners into core superfans of the tridentradio.live movement by integrating your live footprint and storefront on the platform.',
		items: [
			{
				icon: 'Calendar',
				title: 'Live events',
				body: 'Sync your station’s live broadcast schedules, tour dates, or festival appearances through official ticketing partners so they appear contextually on your profile.',
			},
			{
				icon: 'Link2',
				title: 'Smartlink routing',
				body: 'For global tours and multi-region releases, route fans through a single optimized landing page that detects location and surfaces the right ticketing, currency, and streaming options per city. This removes the friction of listeners hunting for their local show or currency and keeps your campaign funnel clean across regions. Set this up in an external music smartlink tool — smartlink functionality is not connected to or provided by this site.',
			},
			{
				icon: 'ShoppingBag',
				title: 'Merch',
				body: 'Connect an ecommerce storefront to display, pin, and tag physical station apparel and goods directly where fans stream.',
			},
			{
				icon: 'Heart',
				title: 'Fan support',
				body: 'Set up direct fundraising or tip links so your loyal listener community can directly back the growth of tridentradio.live.',
			},
		],
	},
	{
		id: 'analytics',
		eyebrow: 'SECTION 05',
		title: 'Audience understanding & analytics',
		intro: 'Read-only insight tools inside an artist-platform dashboard. They surface platform data — this site does not generate, verify, or display live analytics of its own.',
		items: [
			{
				icon: 'BarChart3',
				title: 'Analytics',
				body: 'Track real-time performance metrics across your catalog, measuring audience demographics, stream counts, save ratios, and listener geography.',
			},
			{
				icon: 'Users',
				title: 'Audience behavior insights',
				body: 'Deep-dive into platform-wide data insights to understand how listeners transition from casual tune-ins to dedicated station regulars.',
			},
			{
				icon: 'Layers',
				title: 'Segments',
				body: 'Use audience segmentation tools to visualize your listener base across categories — from newly discovered casuals to core super-listeners — so you can tailor your marketing and broadcast strategies precisely.',
			},
		],
	},
	{
		id: 'execution-pipeline',
		eyebrow: 'SECTION 06',
		title: 'Campaign execution pipeline',
		intro: 'A phased release workflow built around artist-platform tools. Each phase is an external action you run on the platform — none of it is wired into or automated by this site, and no results are guaranteed.',
		items: [
			{
				icon: 'Rocket',
				title: 'Phase 1 — Asset & metadata prep',
				body: 'Prepare distributor-ready audio (WAV 24-bit/44.1kHz) and high-res 3000×3000px square cover art. Sync your artist-platform bio and social links, and pin a call-to-action pointing listeners back to tridentradio.live. Create short looping visuals for each track to lift engagement.',
			},
			{
				icon: 'Megaphone',
				title: 'Phase 2 — Editorial & campaign scheduling',
				body: 'Submit unreleased tracks through your artist-platform dashboard at least 4 weeks before release for editorial consideration. Opt eligible catalog into algorithmic discovery to prime recommendation feeds, and allocate sponsored-recommendation and home-banner budgets for high-impact release windows.',
			},
			{
				icon: 'Rocket',
				title: 'Phase 3 — Launch & integration',
				body: 'On release Friday, link your ecommerce storefront and live event schedules to your profile so fans can interact without leaving the app. Generate custom promo graphics and share them across social channels and your tridentradio.live landing pages.',
			},
			{
				icon: 'LineChart',
				title: 'Phase 4 — Analytics & fan segmentation',
				body: 'Monitor real-time stream velocity, save rates, and audience demographics via your analytics dashboard. Review listener segments (active vs. casual) to refine your broadcast schedule and future promotional pushes.',
			},
		],
	},
	{
		id: 'live-concert-listings',
		eyebrow: 'SECTION 07',
		title: 'Live concert listings & ticketing widgets',
		intro: 'Free embeddable widgets from major live-music platforms can display tour dates and ticket links on tridentradio.live. These are third-party services — none are connected, configured, or deployed here, and no affiliate or ticketing integration exists in this project.',
		items: [
			{
				icon: 'Ticket',
				title: 'Songkick Tourbox widget',
				body: 'Songkick powers live event listings across streaming platforms. A free Tourbox account lets you claim an artist profile, add events, and paste a responsive HTML/JavaScript widget that displays dates, venues, and “Buy Tickets” links. Set this up externally on Songkick — the widget is not embedded here.',
			},
			{
				icon: 'CalendarDays',
				title: 'Bandsintown concert widget',
				body: 'Bandsintown offers a free widget builder for artists. Customize its color scheme to match your branding, then grab the embed code. It updates automatically when new concerts are added and lets fans RSVP or buy tickets. Configure it on Bandsintown — no widget is connected to this site.',
			},
			{
				icon: 'Link2',
				title: 'Ticketmaster / Live Nation affiliate links',
				body: 'Join the Ticketmaster or Live Nation affiliate program (typically via Rakuten Advertising or Impact) to generate custom deep links for specific tours or festival dates. Style these as buttons or event cards in your dashboard. The affiliate program is external and not joined or configured here.',
			},
			{
				icon: 'MapPin',
				title: 'Smartlink routing for global tours',
				body: 'For multi-region tours, an external music smartlink tool routes fans to the right ticketing, currency, and streaming option per city, removing the friction of hunting for a local show. Smartlink functionality is not connected to or provided by this site — set it up in a dedicated smartlink platform.',
			},
		],
	},
];
