import fs from 'node:fs';
import path from 'node:path';

/**
 * Trident Radio stream ingest config.
 *
 * Mirrors the radio_engine.js contract from the original Trident Radio
 * deployment: a small JSON file holds the active stream source, and the server
 * exposes a GET (read) and POST (update) endpoint over it. The config drives
 * the default source the player boots with, so an operator can swap the live
 * feed (direct HLS, Icecast/Shoutcast relay, or a third-party relay label)
 * without redeploying.
 *
 * Storage is a JSON file next to the running process. In environments where
 * the filesystem is read-only, writes are swallowed and the in-memory default
 * is served instead — the app never throws over config I/O.
 */

export type RadioSourceType =
  | 'Direct Audio Stream'
  | 'HLS (.m3u8) Relay'
  | 'Icecast/Direct Audio Relay'
  | 'Shoutcast Relay'
  | 'Third-Party Relay'
  | 'Custom Relay';

export type RadioConfig = {
  streamTitle: string;
  streamUrl: string;
  sourceType: string;
  status: string;
};

const radioConfigFile = path.join(process.cwd(), 'radio_config.json');

const defaultConfig: RadioConfig = {
  streamTitle: 'Trident Radio • Live Creator Stream',
  streamUrl: 'https://streams.fluxfm.de/chillhop/mp3-128/stream/',
  sourceType: 'Icecast/Direct Audio Relay',
  status: 'Connected & Streaming',
};

function ensureConfigFile(): void {
  try {
    if (!fs.existsSync(radioConfigFile)) {
      fs.writeFileSync(radioConfigFile, JSON.stringify(defaultConfig, null, 2));
    }
  } catch {
    /* Read-only filesystem — defaults are served in-memory. */
  }
}

export function getConfig(): RadioConfig {
  try {
    ensureConfigFile();
    const parsed = JSON.parse(fs.readFileSync(radioConfigFile, 'utf8'));
    return { ...defaultConfig, ...parsed };
  } catch {
    return defaultConfig;
  }
}

export function updateConfig(
  streamUrl: string,
  streamTitle?: string,
  sourceType?: string,
): RadioConfig {
  const config: RadioConfig = {
    streamTitle: streamTitle || 'Trident Radio • Custom Stream',
    streamUrl,
    sourceType: sourceType || 'Direct Audio Stream',
    status: 'Active & Relaying',
  };
  try {
    fs.writeFileSync(radioConfigFile, JSON.stringify(config, null, 2));
  } catch {
    /* Filesystem may be read-only; config is returned for this process. */
  }
  return config;
}
