import { AudioLines, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router';
import { openCookiePreferences } from '@/lib/cookie-consent';

export function SiteFooter() {
  return <footer className="site-footer"><div><AudioLines size={16} /><span>Trident Radio</span><span className="footer-copyright">© 2026</span></div><nav aria-label="Footer navigation"><Link to="/#radio">Trident Radio</Link><Link to="/artist">Artist catalog <ArrowUpRight size={12} /></Link><Link to="/podcast">Podcast <ArrowUpRight size={12} /></Link><Link to="/playbook">Campaign Playbook <ArrowUpRight size={12} /></Link><Link to="/#creatoros">CreatorOS Hub <ArrowUpRight size={12} /></Link><button onClick={openCookiePreferences}>Cookie settings</button></nav></footer>;
}
