import { AlertTriangle, ArrowUpRight, Coins, Radio, ServerCog, Wallet } from 'lucide-react';
import { useRadio } from '@/components/radio-provider';

type Placeholder = {
	icon: React.ReactNode;
	title: string;
	body: string;
};

const PLACEHOLDERS: Placeholder[] = [
	{
		icon: <Radio size={17} />,
		title: 'Current rotation metadata',
		body: 'Live now-playing metadata is not ingested. The in-app rotation catalog above lists tracks artists have activated, but no live “now spinning” feed is available.',
	},
	{
		icon: <ServerCog size={17} />,
		title: 'Syndication node identity',
		body: 'No node ID has been assigned or verified. The “24/7 global syndication” concept is a plan, not an active deployment.',
	},
	{
		icon: <Wallet size={17} />,
		title: 'Wallet connection',
		body: 'No wallet authentication is configured. Any “Connect Wallet” flow would be a placeholder until a provider is set up.',
	},
	{
		icon: <Coins size={17} />,
		title: 'Royalty routing & on-chain backing',
		body: 'No royalty split, Solana contract, or treasury routing is established. Any creator/platform split is unverified and not configured.',
	},
];

export function StationPlaceholders() {
	const radio = useRadio();
	return (
		<section id="station-setup" className="station-placeholders">
			<div className="section-heading">
				<div>
					<div className="eyebrow">SETUP PLACEHOLDERS</div>
					<h2>What’s not configured yet<span className="text-cyan">.</span></h2>
					<p>Items carried over from the original TridentRadio.live plan that are clearly labeled as unverified. None of these are active or claimed to be live.</p>
				</div>
				<span className="hub-label"><AlertTriangle size={14} /> UNVERIFIED — READ FIRST</span>
			</div>

			<div className="rights-banner" role="note">
				<AlertTriangle size={18} />
				<p>
					<strong>These are placeholders, not live features.</strong> Live broadcast, current rotation, founder identity, node identity, Solana backing, wallet authentication, and royalty splits are <strong>not</strong> configured or verified by this project. They are listed here so the plan is visible. Playback status elsewhere on this page reflects the actual player state only.
				</p>
			</div>

			<ul className="gaps-list station-gaps">
				{PLACEHOLDERS.map((item, i) => (
					<li key={i}>
						<span className="gap-icon">{item.icon}</span>
						<div>
							<strong>{item.title}</strong>
							<span>{item.body}</span>
						</div>
					</li>
				))}
			</ul>

			<div className="gaps-cta">
				<span>The player is ready for a source you provide.</span>
				<button className="text-link" onClick={radio.connection.open}>Connect a stream source <ArrowUpRight size={14} /></button>
			</div>
		</section>
	);
}
