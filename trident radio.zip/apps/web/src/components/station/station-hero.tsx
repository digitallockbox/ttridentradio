import { ArrowUpRight, AudioLines, LoaderCircle, Pause, Play, Radio, SlidersHorizontal } from 'lucide-react';
import { RADIO_ART, STATE_LABELS } from '@/constants/radio';
import { useRadio } from '@/components/radio-provider';
import { VolumeControl } from '@/components/player-controls';

const STATUS_BADGE: Record<string, { label: string; tone: 'live' | 'idle' | 'connecting' | 'error' }> = {
	disconnected: { label: 'Signal not connected', tone: 'idle' },
	ready: { label: 'Ready to tune in', tone: 'idle' },
	connecting: { label: 'Connecting to stream', tone: 'connecting' },
	playing: { label: 'On air', tone: 'live' },
	paused: { label: 'Playback paused', tone: 'idle' },
	error: { label: 'Connection interrupted', tone: 'error' },
};

export function StationHero() {
	const radio = useRadio();
	const active = radio.state === 'playing' || radio.state === 'connecting';
	const badge = STATUS_BADGE[radio.state] ?? STATUS_BADGE.disconnected;

	return (
		<section id="station" className="station-hub-hero">
			<div className="page-heading">
				<div>
					<div className="eyebrow"><span className="tiny-line" /> STATION HUB</div>
					<h1>Trident Radio Station Rotation<span className="text-cyan">.</span></h1>
					<p>A single hub for independent R&amp;B, hip-hop, and creator audio. Press play to listen, or explore the rotation below.</p>
				</div>
				<span className="outline-label"><Radio size={13} /> TRIDENTRADIO.LIVE</span>
			</div>

			<div className="station-hub-panel">
				<div className="station-hub-top">
					<span className={`station-status station-status-${badge.tone}`}>
						<i className="status-dot" /> {badge.label}
					</span>
					<span className="signal-label"><AudioLines size={14} /> {STATE_LABELS[radio.state]}</span>
				</div>

				<div className="station-hub-body">
					<div className={`station-hub-art ${radio.state === 'playing' ? 'art-playing' : ''}`}>
						<img src={RADIO_ART} alt="Sculptural chrome trident illuminated in cyan, Trident Radio station artwork" width="1024" height="1024" />
						<span className="art-corner">TRIDENT<br /><b>RADIO</b></span>
						<span className="art-index">STATION HUB</span>
					</div>

					<div className="station-hub-details">
						<div className="station-type">
							<span className="type-pill">STATION ROTATION</span>
							<span>BY TRIDENT RADIO</span>
						</div>
						<h2>Trident Radio</h2>
						<p className="station-description">
							A rotation worth tuning into.<br />
							A shared space to listen, create, and connect.
						</p>

						<div className={`playback-state ${radio.state === 'playing' ? 'playing' : ''}`} aria-live="polite">
							<span className="signal-bars" aria-hidden="true"><i /><i /><i /><i /></span>
							<span>{STATE_LABELS[radio.state]}</span>
							{radio.source && <span className="session-source">SESSION SOURCE</span>}
						</div>

						<div className="primary-controls">
							<button className="button button-cyan listen-button" onClick={radio.toggle}>
								{radio.state === 'connecting' ? <LoaderCircle size={18} className="spin" /> : active ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" />}
								{radio.state === 'connecting' ? 'Cancel connection' : active ? 'Pause stream' : radio.state === 'error' ? 'Try again' : 'Tune in'}
							</button>
							<button className="round-button" onClick={radio.connection.open} aria-label="Stream settings" title="Stream settings">
								<SlidersHorizontal size={18} />
							</button>
						</div>
					</div>
				</div>

				<div className="station-hub-bottom">
					<div><AudioLines size={16} /><span>Playback status reflects the actual player state — nothing is claimed as live until a source is connected and playing.</span></div>
					<VolumeControl />
				</div>
			</div>

			{radio.error ? (
				<div className="stream-notice error-notice" role="alert">
					<Radio size={17} /><p>{radio.error}</p>
					<button onClick={radio.connection.open}>Check source <ArrowUpRight size={14} /></button>
				</div>
			) : (
				<div className="stream-notice">
					<AudioLines size={16} />
					<p>{radio.source ? 'A live source is connected. Press play to listen.' : 'Press play to listen to the rotation, or connect your own live source.'}</p>
					<button onClick={radio.connection.open}>{radio.source ? 'Change source' : 'Connect a source'}<ArrowUpRight size={14} /></button>
				</div>
			)}
		</section>
	);
}
