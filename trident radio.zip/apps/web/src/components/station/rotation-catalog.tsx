import { useEffect, useState } from 'react';
import { AlertCircle, Loader2, Music, Pause, Play, RotateCw, Link2, ListMusic } from 'lucide-react';
import pb from '@/lib/pocketbase-client';
import { useRadio, type NowPlayingTrack } from '@/components/radio-provider';
import { TrackEngagementControls } from '@/components/track-engagement-controls';

type RotationTrack = {
	id: string;
	title: string;
	credit?: string;
	genre?: string;
	audio_file?: string;
	audio_url?: string;
	rotation?: string;
	created?: string;
};

function trackUrl(track: RotationTrack): string {
	if (track.audio_file) return pb.files.getURL(track, track.audio_file);
	return track.audio_url || '';
}

function toNowPlaying(track: RotationTrack): NowPlayingTrack | null {
	const url = trackUrl(track);
	if (!url) return null;
	return {
		id: track.id,
		title: track.title,
		artist: track.credit || 'Unknown artist',
		url,
	};
}

/**
 * Trident Radio rotation catalog — the in-app spin rotation list.
 *
 * Tracks that artists mark "active" from their catalog appear here for every
 * visitor. Only tracks with an available audio file or a usable direct audio
 * URL can be activated, so every entry here is a real, playable audio source.
 * Visitors can play any track or the whole queue through the shared Trident
 * player, which reports the real title and artist of the track playing.
 *
 * This is the in-app rotation catalog. It is NOT a live broadcast and is NOT
 * synced to an external tridentradio.live catalog — no working connection to
 * that external site exists in this project.
 */
export function RotationCatalog() {
	const radio = useRadio();
	const [tracks, setTracks] = useState<RotationTrack[]>([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState('');

	useEffect(() => {
		let cancelled = false;
		(async () => {
			setLoading(true);
			setError('');
			try {
				const list = await pb
					.collection('tracks')
					.getFullList<RotationTrack>({ filter: 'rotation = "active"', sort: '-created', requestKey: null });
				if (!cancelled) setTracks(list);
			} catch {
				if (!cancelled) setError('Could not load the rotation catalog. Please try again later.');
			} finally {
				if (!cancelled) setLoading(false);
			}
		})();
		return () => {
			cancelled = true;
		};
	}, []);

	const playAll = () => {
		const queue = tracks
			.map(toNowPlaying)
			.filter((t): t is NowPlayingTrack => Boolean(t));
		if (queue.length > 0) radio.playQueue(queue, 0);
	};

	const toggle = (track: RotationTrack) => {
		const np = toNowPlaying(track);
		if (!np) return;
		if (radio.nowPlaying?.id === track.id) {
			radio.toggle();
			return;
		}
		radio.playTrack(np);
	};

	return (
		<section id="rotation" className="station-placeholders">
			<div className="section-heading">
				<div>
					<div className="eyebrow"><span className="tiny-line" /> ROTATION CATALOG</div>
					<h2>Trident Radio spin rotation<span className="text-cyan">.</span></h2>
					<p>Tracks artists have shared. Play any track or the whole queue in the Trident player.</p>
				</div>
			</div>

			<div className="rights-banner" role="note">
				<RotateCw size={18} />
				<p>
					<strong>Trident Radio rotation.</strong> These are tracks artists have shared for rotation. It's an in-app catalog, not a live broadcast — press play to listen.
				</p>
			</div>

			{loading ? (
				<p className="catalog-loading"><Loader2 size={16} className="spin" /> Loading rotation…</p>
			) : error ? (
				<p className="track-play-error" role="alert"><AlertCircle size={14} /> {error}</p>
			) : tracks.length > 0 ? (
				<>
					<div className="play-all-bar">
						<button type="button" className="button button-cyan play-all-button" onClick={playAll}>
							<ListMusic size={16} /> Play rotation queue
						</button>
						<span className="play-all-hint">Queues every active track into the Trident player and shows the title and artist of the track playing.</span>
					</div>
					<ul className="track-list">
						{tracks.map((track) => {
							const source = track.audio_file ? 'file' : 'link';
							const subtitle = [track.credit, track.genre].filter(Boolean).join(' • ');
							const current = radio.nowPlaying?.id === track.id;
							const playing = current && (radio.state === 'playing' || radio.state === 'connecting');
							return (
								<li key={track.id} className={`track-card track-cyan is-real ${playing ? 'is-playing' : ''}`}>
									<div className="track-card-main">
										<span className="track-icon" aria-hidden="true">
											{source === 'link' ? <Link2 size={18} /> : <Music size={18} />}
										</span>
										<div className="track-meta">
											<h3>{track.title}</h3>
											<p>{subtitle || 'Audio track'}</p>
										</div>
										<span className={`track-source-badge ${source === 'link' ? 'track-source-link' : 'track-source-file'}`}>
											{source === 'link' ? 'LINK' : 'FILE'}
										</span>
									</div>
									<div className="track-actions">
										<button
											className="track-play"
											onClick={() => toggle(track)}
											aria-label={playing ? `Pause ${track.title}` : `Play ${track.title}`}
										>
											{playing ? <Pause size={15} fill="currentColor" /> : <Play size={15} fill="currentColor" />}
										</button>
									</div>
									<span className="rotation-badge rotation-badge-active" title="In Trident Radio rotation">IN ROTATION</span>
									{current && (
										<span className="now-playing-pill" title="Now playing on the Trident player">NOW PLAYING</span>
									)}
									<div className="track-card-row">
										<TrackEngagementControls track={track} />
									</div>
								</li>
							);
						})}
					</ul>
				</>
			) : (
				<div className="catalog-empty">
					<span className="catalog-empty-icon"><Music size={26} /></span>
					<h3>No tracks are in rotation yet</h3>
					<p>Artists can activate tracks from the catalog page to add them to the Trident Radio rotation.</p>
				</div>
			)}
		</section>
	);
}
