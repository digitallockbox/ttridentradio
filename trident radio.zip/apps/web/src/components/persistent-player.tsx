import { Play, Radio, RotateCcw, Settings2, SkipBack, SkipForward } from 'lucide-react';
import { RADIO_ART, STATE_LABELS } from '@/constants/radio';
import { useRadio } from '@/components/radio-provider';
import { PlayControl, VolumeControl } from '@/components/player-controls';

export function PersistentPlayer() {
	const radio = useRadio();
	const track = radio.nowPlaying;
	const inTrack = Boolean(track);

	if (radio.hasContent === false) {
		return (
			<section className="persistent-player persistent-player-empty" aria-label="Trident Radio">
				<div className="mini-station">
					<img src={RADIO_ART} alt="" width="48" height="48" />
					<div>
						<strong>Trident Radio</strong>
						<span>No music available yet</span>
					</div>
				</div>
				<div className="dock-center">
					<p className="player-empty-note">Tracks will appear here once artists add music.</p>
				</div>
				<div className="dock-right">
					<Radio size={17} className="dock-radio-icon" />
				</div>
			</section>
		);
	}

	return (
		<section className="persistent-player" aria-label="Persistent radio player">
			<div className="mini-station">
				<img src={RADIO_ART} alt="" width="48" height="48" />
				<div>
					<strong>{track ? track.title : 'Trident Radio'}</strong>
					<span className={radio.state === 'playing' ? 'text-cyan' : ''}>
						{radio.autoplayBlocked ? 'Press play to start' : track ? track.artist : STATE_LABELS[radio.state]}
					</span>
				</div>
				<span className="mini-indicator"><Radio size={16} /></span>
			</div>
			<div className="dock-center">
				{radio.autoplayBlocked ? (
					<button className="button button-cyan autoplay-prompt" onClick={radio.startListening}>
						<Play size={18} fill="currentColor" /> Start listening
					</button>
				) : (
					<>
						<div className="dock-transport">
							{inTrack ? (
								<>
									<button className="icon-button live-reset" onClick={radio.playPrev} disabled={radio.queueIndex <= 0} aria-label="Previous track" title="Previous track">
										<SkipBack size={16} />
									</button>
									<PlayControl />
									<button className="icon-button dock-settings" onClick={radio.playNext} disabled={radio.queueIndex >= radio.queue.length - 1} aria-label="Next track" title="Next track">
										<SkipForward size={16} />
									</button>
								</>
							) : (
								<>
									<button className="icon-button live-reset" onClick={radio.goLive} disabled={!radio.source} aria-label="Reconnect to the live edge" title="Reconnect to live">
										<RotateCcw size={16} />
									</button>
									<PlayControl />
									<button className="icon-button dock-settings" onClick={radio.connection.open} aria-label="Stream settings" title="Stream settings">
										<Settings2 size={17} />
									</button>
								</>
							)}
						</div>
						<div className="dock-progress">
							<span>{radio.state === 'playing' ? (track ? 'NOW PLAYING' : 'ON AIR') : 'RADIO'}</span>
							<div className="live-timeline" aria-hidden="true"><span /></div>
							<span>{radio.state === 'playing' ? (track ? 'TRACK' : 'LIVE') : 'OFF AIR'}</span>
						</div>
					</>
				)}
			</div>
			<div className="dock-right">
				{inTrack && (
					<button className="icon-button" onClick={radio.stopTrack} aria-label="Stop track and return to radio" title="Back to radio">
						<Radio size={17} />
					</button>
				)}
				<Radio size={17} className="dock-radio-icon" />
				<VolumeControl compact />
			</div>
		</section>
	);
}
