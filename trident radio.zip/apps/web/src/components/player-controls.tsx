import { LoaderCircle, Pause, Play, Volume2, VolumeX } from 'lucide-react';
import { useRadio } from '@/components/radio-provider';

export function PlayControl({ large = false }: { large?: boolean }) {
  const radio = useRadio();
  const active = radio.state === 'playing' || radio.state === 'connecting';
  return <button className={`play-control ${large ? 'play-control-large' : ''}`} onClick={radio.toggle} aria-label={active ? 'Pause Trident Radio' : 'Play Trident Radio'} title={active ? 'Pause' : 'Play'}>
    {radio.state === 'connecting' ? <LoaderCircle className="spin" size={large ? 25 : 22} /> : active ? <Pause size={large ? 25 : 21} fill="currentColor" /> : <Play size={large ? 25 : 21} fill="currentColor" className="play-glyph" />}
  </button>;
}

export function VolumeControl({ compact = false }: { compact?: boolean }) {
  const radio = useRadio();
  return <div className={`volume-control ${compact ? 'volume-compact' : ''}`}>
    <button className="icon-button" onClick={radio.toggleMute} aria-label={radio.muted ? 'Unmute audio' : 'Mute audio'} title={radio.muted ? 'Unmute' : 'Mute'}>{radio.muted || radio.volume === 0 ? <VolumeX size={19} /> : <Volume2 size={19} />}</button>
    <input aria-label="Volume" type="range" min="0" max="1" step="0.01" value={radio.muted ? 0 : radio.volume} onChange={event => radio.setVolume(Number(event.target.value))} />
    {!compact && <span>{Math.round((radio.muted ? 0 : radio.volume) * 100)}%</span>}
  </div>;
}
