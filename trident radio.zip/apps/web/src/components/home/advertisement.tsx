import { ArrowUpRight, AudioLines, Radio, Scissors } from 'lucide-react';
import { Link } from 'react-router';

type Promo = {
	name: string;
	tagline: string;
	href: string;
	icon: React.ReactNode;
	accent: 'cyan' | 'indigo' | 'violet';
	index: string;
};

const PROMOS: Promo[] = [
	{
		name: 'Trident Radio',
		tagline: 'Your home for live streaming, radio, and creator tools.',
		href: '/station',
		icon: <AudioLines size={22} />,
		accent: 'cyan',
		index: '01',
	},
	{
		name: 'Sitflow.lt',
		tagline: 'A focused space to stream, sit back, and stay in flow.',
		href: 'https://sitflow.lt',
		icon: <Radio size={22} />,
		accent: 'indigo',
		index: '02',
	},
	{
		name: 'Trident AutoSplit',
		tagline: 'Automated splitting for your live broadcasts and recordings.',
		href: '/station',
		icon: <Scissors size={22} />,
		accent: 'violet',
		index: '03',
	},
];

export function Advertisement() {
	return (
		<section id="partners" className="advertisement" aria-label="Featured projects">
			<div className="section-heading">
				<div>
					<div className="eyebrow">FROM THE TRIDENT RADIO NETWORK</div>
					<h2>Built to stream. Made to connect<span className="text-cyan">.</span></h2>
					<p>Projects and tools that share one signal.</p>
				</div>
				<span className="hub-label"><ArrowUpRight size={14} /> EXPLORE THE NETWORK</span>
			</div>
			<div className="promo-grid">
				{PROMOS.map(promo => {
					const external = promo.href.startsWith('http');
					const content = (
						<>
							<span className="promo-icon">{promo.icon}</span>
							<span className="promo-corner">{promo.index}</span>
							<strong className="promo-name">{promo.name}</strong>
							<span className="promo-tagline">{promo.tagline}</span>
							<span className="promo-action">Visit <ArrowUpRight size={14} /></span>
						</>
					);
					return external ? (
						<a key={promo.name} className={`promo-card promo-${promo.accent}`} href={promo.href} target="_blank" rel="noopener noreferrer">{content}</a>
					) : (
						<Link key={promo.name} className={`promo-card promo-${promo.accent}`} to={promo.href}>{content}</Link>
					);
				})}
			</div>
		</section>
	);
}
