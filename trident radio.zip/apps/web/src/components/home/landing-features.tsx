import { Headphones, Heart, ListMusic, Mic, Upload } from 'lucide-react';
import { Link } from 'react-router';

const FEATURES = [
	{
		icon: <Headphones size={22} />,
		title: 'Listen anywhere',
		body: 'A persistent player stays with you as you browse. Play, pause, and set your volume at any time.',
	},
	{
		icon: <Upload size={22} />,
		title: 'Upload your music',
		body: 'Add tracks from a file, a batch drop, or a direct link. You confirm you hold the rights to everything you upload.',
	},
	{
		icon: <ListMusic size={22} />,
		title: 'Build your catalog',
		body: 'Activate tracks into Trident Radio rotation so listeners can hear them in the player.',
	},
	{
		icon: <Mic size={22} />,
		title: 'Podcast episodes',
		body: 'Publish audio episodes that play right here through the Trident player. Drafts stay private until you publish.',
		href: '/podcast',
	},
	{
		icon: <Heart size={22} />,
		title: 'Engage your audience',
		body: 'Listeners can follow you, thumbs-up tracks, and build their own Trident playlist.',
	},
];

export function LandingFeatures() {
	return (
		<section className="landing-features" id="features" aria-label="What you can do">
			{FEATURES.map((feature) => {
				const content = (
					<>
						<span className="landing-feature-icon">{feature.icon}</span>
						<h3>{feature.title}</h3>
						<p>{feature.body}</p>
						{feature.href && <span className="landing-feature-link">Learn more →</span>}
					</>
				);
				return feature.href ? (
					<Link className="landing-feature" key={feature.title} to={feature.href}>{content}</Link>
				) : (
					<a className="landing-feature" key={feature.title} href="#features">{content}</a>
				);
			})}
		</section>
	);
}
