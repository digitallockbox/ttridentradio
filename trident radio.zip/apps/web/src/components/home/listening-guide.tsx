import { ArrowUpRight, Headphones, Play, Radio, Volume2 } from 'lucide-react';
import { useRadio } from '@/components/radio-provider';

export function ListeningGuide() {
  const radio = useRadio();
  return <section id="listening-guide" className="listening-guide"><div className="guide-title"><Headphones size={21} /><div><h2>Make yourself at home.</h2><p>A few things to know about your listening space.</p></div></div>
    <div className="guide-rows"><div><Play size={17} /><h3>Always within reach</h3><p>The bottom player stays with you as you explore. Press play or pause at any time.</p></div><div><Volume2 size={17} /><h3>Set your level</h3><p>Adjust the volume or tap the speaker to mute. Some mobile devices use their own volume buttons.</p></div><div><Radio size={17} /><h3>A live signal, not a playlist</h3><p>There’s no track skipping. Use the reconnect control to return to the latest point in the broadcast.</p></div></div>
    <button className="text-link" onClick={radio.connection.open}>Need a source? Open stream settings <ArrowUpRight size={14} /></button>
  </section>;
}
