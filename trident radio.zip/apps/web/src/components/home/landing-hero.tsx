import { ArrowUpRight, LoaderCircle, Pause, Play, Radio } from 'lucide-react';
import { RADIO_ART, STATE_LABELS } from '@/constants/radio';
import { useRadio } from '@/components/radio-provider';

export function LandingHero() {
	const radio = useRadio();
	const active = radio.state === 'playing' || radio.state === 'connecting';
	const playing = radio.state === 'playing';

	return (
		<section className="landing-hero" aria-label="Trident Radio">
			<div className="landing-hero-copy">
				<div className="eyebrow"><span className="tiny-line" /> TRIDENT RADIO · CREATOROS</div>
				<h1>Your radio.<br />Your creative space<span className="text-cyan">.</span></h1>
				<p>Listen to Trident Radio, upload your own music, and build a catalog that plays in the Trident player — all in one clean, focused space.</p>
				<div className="landing-hero-actions">
					<button type="button" className="button button-cyan" onClick={radio.autoplayBlocked ? radio.startListening : radio.toggle}>
						{radio.state === 'connecting'
							? <LoaderCircle size={18} className="spin" />
							: active
								? <Pause size={18} fill="currentColor" />
								: <Play size={18} fill="currentColor" />}
						{radio.state === 'connecting' ? 'Connecting…' : active ? 'Pause' : radio.autoplayBlocked ? 'Start listening' : 'Listen live'}
					</button>
					<a className="button button-ghost" href="#creatoros">Explore CreatorOS <ArrowUpRight size={16} /></a>
				</div>
				<p className="landing-hero-state">
					<Radio size={14} /> {radio.autoplayBlocked ? 'Press play to start listening' : STATE_LABELS[radio.state]}
				</p>
			</div>
			<div className="landing-hero-art">
				<img src={RADIO_ART} alt="Trident Radio artwork" />
				<span className="landing-hero-art-badge"><Radio size={13} /> {playing ? 'ON AIR' : 'TRIDENT RADIO'}</span>
			</div>
		</section>
	);
}
