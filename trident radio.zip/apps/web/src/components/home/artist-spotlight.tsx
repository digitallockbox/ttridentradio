import { ArrowUpRight, MoreHorizontal } from 'lucide-react';
import { Link } from 'react-router';
import { ARTIST } from '@/data/artist-catalog';

export function ArtistSpotlight() {
  return <aside className="spotlight-panel" aria-label="Artist spotlight">
    <div className="spotlight-heading"><strong>Artist spotlight</strong><Link to="/artist" aria-label="View artist profile"><MoreHorizontal size={21} /></Link></div>
    <Link to="/artist" className="spotlight-art"><img src="https://images.hostinger.com/f6881439-8a7e-4aec-a226-489cfe40cc9a/65779716-f619-4483-abcf-72a387aa12e8.png" srcSet="https://images.hostinger.com/f6881439-8a7e-4aec-a226-489cfe40cc9a/65779716-f619-4483-abcf-72a387aa12e8.png?width=375 375w, https://images.hostinger.com/f6881439-8a7e-4aec-a226-489cfe40cc9a/65779716-f619-4483-abcf-72a387aa12e8.png?width=768 768w, https://images.hostinger.com/f6881439-8a7e-4aec-a226-489cfe40cc9a/65779716-f619-4483-abcf-72a387aa12e8.png 1024w" sizes="(min-width: 1200px) 320px, 100vw" alt="Illustrative soul music artwork" /><span>ARTIST SPOTLIGHT<br /><b>TRIDENT RADIO</b></span></Link>
    <div className="spotlight-title"><div><h2>{ARTIST.name}</h2><p>{ARTIST.role}</p></div><Link to="/artist" aria-label="View artist profile"><ArrowUpRight size={19} /></Link></div>
    <div className="spotlight-credits"><div className="spotlight-credits-heading"><strong>About the artist</strong><Link to="/artist">Show all</Link></div><strong>{ARTIST.name}</strong><p>{ARTIST.role}</p><div className="spotlight-divider" /><strong>Catalog</strong><p>Tracks the artist uploads play in the Trident player</p><small>Artwork is illustrative. Tracks become playable when the artist uploads audio.</small><Link className="spotlight-profile" to="/artist">View artist profile <ArrowUpRight size={14} /></Link></div>
  </aside>;
}
