import { ArrowDown, ArrowUpRight, AudioLines, Disc3, Headphones, Radio, LayoutGrid, Upload } from 'lucide-react';
import { Link } from 'react-router';
import { useRadio } from '@/components/radio-provider';
import { useUpload } from '@/components/upload-dialog';

export function CreatorHub() {
  const radio = useRadio();
  const upload = useUpload();
  return <section id="creatoros" className="creator-hub"><div className="section-heading"><div><div className="eyebrow">BEYOND THE PLAY BUTTON</div><h2>CreatorOS Hub<span className="hub-dot">.</span></h2><p>Your home base for the live-streaming experience.</p></div><span className="hub-label"><LayoutGrid size={14} /> CONNECTED BY SOUND</span></div>
    <div className="hub-links"><button className="hub-link" onClick={radio.connection.open}><span className="hub-icon indigo-icon"><AudioLines size={24} /></span><span className="hub-link-copy"><span className="small-eyebrow">FOR CREATORS</span><strong>Your signal, connected.</strong><span>Connect a live source and make this space yours.</span><span className="hub-action">Open stream settings <ArrowUpRight size={15} /></span></span><span className="hub-corner-number">01</span></button>
    <button className="hub-link" onClick={upload.open}><span className="hub-icon cyan-icon"><Upload size={24} /></span><span className="hub-link-copy"><span className="small-eyebrow">FOR CREATORS</span><strong>Upload your content.</strong><span>Add audio, video, or image files from your device.</span><span className="hub-action">Upload files <ArrowUpRight size={15} /></span></span><span className="hub-corner-number">02</span></button>
    <a className="hub-link" href="#listening-guide"><span className="hub-icon cyan-icon"><Headphones size={24} /></span><span className="hub-link-copy"><span className="small-eyebrow">FOR LISTENERS</span><strong>Less setup. More listening.</strong><span>Get comfortable with your player and controls.</span><span className="hub-action">Explore the player <ArrowDown size={15} /></span></span><span className="hub-corner-number">03</span></a>
    <Link className="hub-link" to="/artist"><span className="hub-icon indigo-icon"><Disc3 size={24} /></span><span className="hub-link-copy"><span className="small-eyebrow">DRAFT CATALOG</span><strong>Anthony D. Simmons — draft profile.</strong><span>A draft artist profile and catalog for review. Not published or streamable.</span><span className="hub-action">View draft catalog <ArrowUpRight size={15} /></span></span><span className="hub-corner-number">04</span></Link></div>
    <div className="hub-footnote"><Radio size={15} /><span>One station. One shared space. No distractions.</span></div>
  </section>;
}
