import { useCookieBanner } from '@/hooks/use-cookie-banner';

export function CookieBanner() {
  const banner = useCookieBanner();
  if (!banner.isOpen) return null;
  return <section className="cookie-banner" role="dialog" aria-label="Cookie preferences">
    <div><strong>A little control over your cookies.</strong><p>Essential cookies keep things working. You choose whether we use optional cookies.</p></div>
    {banner.isCustomizing && <fieldset className="cookie-choices"><legend className="sr-only">Optional cookie categories</legend>
      <label><input type="checkbox" checked={banner.choices.analytics} onChange={e => banner.setChoice('analytics', e.target.checked)} /><span><strong>Analytics</strong><small>Visitor statistics for this site.</small></span></label>
      <label><input type="checkbox" checked={banner.choices.marketing} onChange={e => banner.setChoice('marketing', e.target.checked)} /><span><strong>Marketing</strong><small>Ad measurement and personalized ads.</small></span></label>
      <label><input type="checkbox" checked={banner.choices.platformAnalytics} onChange={e => banner.setChoice('platformAnalytics', e.target.checked)} /><span><strong>Platform analytics</strong><small>Hostinger uses Amplitude to improve the site and checkout, without directly identifying you.</small></span></label>
    </fieldset>}
    <div className="cookie-actions"><button onClick={banner.rejectOptional}>Reject optional</button><button onClick={banner.isCustomizing ? banner.saveChoices : banner.customize}>{banner.isCustomizing ? 'Save choices' : 'Customize'}</button><button onClick={banner.acceptAll}>Accept all</button></div>
  </section>;
}
