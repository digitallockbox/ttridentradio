import { BookOpen, Info, ExternalLink } from 'lucide-react';

export function PlaybookHero() {
	return (
		<section className="playbook-hero">
			<div className="playbook-hero-head">
				<div>
					<div className="eyebrow"><span className="tiny-line" /> CREATOR CAMPAIGN PLAYBOOK</div>
					<h1>The tridentradio.live creator &amp; campaign hub<span className="text-cyan">.</span></h1>
					<p>
						Your comprehensive strategic playbook for setting up a team dashboard, scaling reach with a promotion &amp; discovery toolkit,
						and building a live broadcast identity. Organized into seven clear sections — from account setup to live concert listings.
					</p>
				</div>
				<span className="playbook-badge"><BookOpen size={14} /> STRATEGY GUIDE</span>
			</div>

			<div className="playbook-external">
				<span className="playbook-external-copy">
					<strong>Your artist-platform dashboard</strong>
					<span>Act on any step in this playbook from your own streaming artist-platform dashboard. Trident Radio does not connect to, import, or sync any external platform account, music, or profile.</span>
				</span>
				<ExternalLink size={18} />
			</div>

			<div className="playbook-disclaimer">
				<Info size={16} />
				<p>
					Every capability below is an <strong>external artist-platform tool or concept</strong>, shown here as strategic information.
					None are connected to this site, and none are claimed as configured, verified, or delivering results. Availability depends on
					account access, eligibility, region, and the platform’s current terms. This page does not generate live analytics,
					verified metrics, campaign functionality, or account access, and no artist music or profile is imported into Trident Radio.
				</p>
			</div>

			<nav className="playbook-toc" aria-label="Playbook sections">
				{PLAYBOOK_TOC.map(item => (
					<a key={item.id} href={`#${item.id}`}>{item.label}</a>
				))}
			</nav>
		</section>
	);
}

const PLAYBOOK_TOC = [
	{ id: 'account-setup', label: '01 · Account setup' },
	{ id: 'campaign-kit', label: '02 · Promotion toolkit' },
	{ id: 'visual-branding', label: '03 · Visual branding' },
	{ id: 'monetization', label: '04 · Merch & live events' },
	{ id: 'analytics', label: '05 · Analytics' },
	{ id: 'execution-pipeline', label: '06 · Execution pipeline' },
	{ id: 'live-concert-listings', label: '07 · Concert listings' },
];
