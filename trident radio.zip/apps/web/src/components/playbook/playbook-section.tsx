import {
	BarChart3, Calendar, CalendarDays, Clapperboard, Compass, Heart, LayoutDashboard, Layers, LineChart, Link2, ListMusic, LogIn, MapPin, Megaphone, Music, Rocket, Share2, ShieldCheck, ShoppingBag, Ticket, Timer, UserCircle, Users, Video,
	type LucideIcon,
} from 'lucide-react';
import type { PlaybookSection as PlaybookSectionData } from '@/data/playbook';

const ICONS: Record<string, LucideIcon> = {
	BarChart3, Calendar, CalendarDays, Clapperboard, Compass, Heart, LayoutDashboard, Layers, LineChart, Link2, ListMusic, LogIn, MapPin, Megaphone, Music, Rocket, Share2, ShieldCheck, ShoppingBag, Ticket, Timer, UserCircle, Users, Video,
};

const ACCENTS = ['cyan', 'indigo', 'violet', 'emerald'] as const;

export function PlaybookSection({ section, index }: { section: PlaybookSectionData; index: number }) {
	return (
		<section id={section.id} className={`playbook-section playbook-${ACCENTS[index % ACCENTS.length]}`}>
			<div className="section-heading">
				<div>
					<div className="eyebrow">{section.eyebrow}</div>
					<h2>{section.title}</h2>
					<p>{section.intro}</p>
				</div>
				<span className="hub-label">EXTERNAL · ARTIST PLATFORMS</span>
			</div>
			<div className="playbook-grid">
				{section.items.map(item => {
					const Icon = ICONS[item.icon] ?? Music;
					return (
						<article key={item.title} className="playbook-card">
							<span className="playbook-card-icon"><Icon size={22} /></span>
							<h3>{item.title}</h3>
							<p>{item.body}</p>
							<span className="playbook-card-tag">EXTERNAL TOOL</span>
						</article>
					);
				})}
			</div>
		</section>
	);
}
