import { useState, type FormEvent } from 'react';
import { ArrowUpRight, Link2, Radio, RadioTower, Waves, Zap } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useRadio } from '@/components/radio-provider';

/**
 * Public example streams a visitor can try with one click. These are real,
 * well-known open internet radio streams offered only as starting points — the
 * site does not own or control them, and playback depends on each source's
 * availability and cross-origin permissions.
 */
const EXAMPLE_STREAMS = [
	{ label: 'Chillhop (FluxFM)', url: 'https://streams.fluxfm.de/chillhop/mp3-128/stream/' },
	{ label: 'SomaFM Groove Salad', url: 'https://ice1.somafm.com/groovesalad-128-mp3' },
	{ label: 'SomaFM Drone Zone', url: 'https://ice1.somafm.com/dronezone-128-mp3' },
];

type SourceType = 'mp3' | 'hls';

function SourceForm({ source, connect }: { source: string; connect: (url: string) => void }) {
  const [url, setUrl] = useState(source);
  const [error, setError] = useState('');
  const [sourceType, setSourceType] = useState<SourceType>(source.toLowerCase().includes('.m3u8') ? 'hls' : 'mp3');

  const applyExample = (value: string) => {
    setUrl(value);
    setSourceType(value.toLowerCase().includes('.m3u8') ? 'hls' : 'mp3');
    setError('');
  };

  const submit = (event: FormEvent) => {
    event.preventDefault();
    try {
      const parsed = new URL(url.trim());
      if (parsed.protocol !== 'https:' || parsed.username || parsed.password) throw new Error('invalid');
      connect(parsed.href);
    } catch { setError('Enter a valid HTTPS stream URL without embedded credentials.'); }
  };

  return <form onSubmit={submit} className="source-form">
    <div className="source-type-toggle" role="tablist" aria-label="Source type">
      <button type="button" role="tab" aria-selected={sourceType === 'mp3'} className={`source-type-btn ${sourceType === 'mp3' ? 'active' : ''}`} onClick={() => setSourceType('mp3')}>
        <Waves size={15} /> Direct MP3 / AAC
      </button>
      <button type="button" role="tab" aria-selected={sourceType === 'hls'} className={`source-type-btn ${sourceType === 'hls' ? 'active' : ''}`} onClick={() => setSourceType('hls')}>
        <RadioTower size={15} /> HLS playlist (.m3u8)
      </button>
    </div>

    <label htmlFor="stream-url">Stream URL</label>
    <div className="url-field"><Link2 size={17} /><input id="stream-url" type="url" value={url} onChange={event => { setUrl(event.target.value); setError(''); }} placeholder={sourceType === 'hls' ? 'https://your-station.com/live.m3u8' : 'https://your-station.com/live.mp3'} required aria-describedby="source-help source-error" autoComplete="off" /></div>
    <p id="source-error" className="field-error" role="alert">{error}</p>
    <p id="source-help">{sourceType === 'hls' ? 'Use an HLS (.m3u8) live stream link.' : 'Use a direct MP3 or AAC stream link. Webpage links will not play.'}</p>

    <div className="source-examples">
      <span className="source-examples-label"><Zap size={13} /> Try an example stream</span>
      <div className="source-examples-list">
        {EXAMPLE_STREAMS.map(example => (
          <button key={example.url} type="button" className="source-example-btn" onClick={() => applyExample(example.url)} title={example.url}>
            <Waves size={13} /> {example.label}
          </button>
        ))}
      </div>
      <p className="source-examples-note">Public internet radio streams offered as starting points. The site does not own or control them.</p>
    </div>

    <div className="source-note"><Radio size={17} /><p>No official Trident Radio stream is set. This source plays for your current session only.</p></div>

    <button className="button button-cyan" type="submit">Connect stream <ArrowUpRight size={17} /></button>
  </form>;
}

export function StreamDialog() {
  const radio = useRadio();
  return <Dialog open={radio.connection.isOpen} onOpenChange={open => open ? radio.connection.open() : radio.connection.close()}>
    <DialogContent className="radio-dialog">
      <span className="dialog-icon"><Radio size={25} /></span>
      <DialogTitle className="dialog-title">Connect your signal.</DialogTitle>
      <DialogDescription>Give the player a live audio source, then press play. Pick a source type, try an example, or paste your own URL.</DialogDescription>
      <SourceForm key={radio.source} source={radio.source} connect={radio.connect} />
    </DialogContent>
  </Dialog>;
}
