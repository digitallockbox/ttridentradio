import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { useDisclosure } from '@/hooks/use-disclosure';
import { RADIO_ART, type PlaybackState } from '@/constants/radio';
import type Hls from 'hls.js';
import pb from '@/lib/pocketbase-client';

export type NowPlayingTrack = {
	id: string;
	title: string;
	artist: string;
	url: string;
};

type RadioContextValue = {
	source: string;
	state: PlaybackState;
	error: string;
	volume: number;
	muted: boolean;
	nowPlaying: NowPlayingTrack | null;
	queue: NowPlayingTrack[];
	queueIndex: number;
	connect: (url: string) => void;
	toggle: () => void;
	goLive: () => void;
	setVolume: (volume: number) => void;
	toggleMute: () => void;
	playTrack: (track: NowPlayingTrack) => void;
	playQueue: (tracks: NowPlayingTrack[], startIndex?: number) => void;
	playNext: () => void;
	playPrev: () => void;
	stopTrack: () => void;
	connection: ReturnType<typeof useDisclosure>;
	autoplayBlocked: boolean;
	hasContent: boolean | null;
	startListening: () => void;
};

const RadioContext = createContext<RadioContextValue | null>(null);

export function RadioProvider({ initialSource, children }: { initialSource: string; children: ReactNode }) {
	const audio = useRef<HTMLAudioElement>(null);
	const hls = useRef<Hls | null>(null);
	const wanted = useRef(false);
	const [source, setSource] = useState(initialSource);
	const [sourceRevision, setSourceRevision] = useState(0);
	const [state, setState] = useState<PlaybackState>(initialSource ? 'ready' : 'disconnected');
	const [error, setError] = useState('');
	const [volume, updateVolume] = useState(0.75);
	const [muted, setMuted] = useState(false);
	const [nowPlaying, setNowPlaying] = useState<NowPlayingTrack | null>(null);
	const [queue, setQueue] = useState<NowPlayingTrack[]>([]);
	const [queueIndex, setQueueIndex] = useState(-1);
	const connection = useDisclosure({ closeOnEscape: false });
	const [autoplayBlocked, setAutoplayBlocked] = useState(false);
	const [hasContent, setHasContent] = useState<boolean | null>(null);
	const autoplayAttemptRef = useRef(false);

	// Refs so the shared <audio> event handlers read live values without rebinding.
	const nowPlayingRef = useRef<NowPlayingTrack | null>(null);
	const queueRef = useRef<NowPlayingTrack[]>([]);
	const queueIndexRef = useRef(-1);
	const playNextRef = useRef<() => void>(() => {});
	const playPrevRef = useRef<() => void>(() => {});
	useEffect(() => {
		nowPlayingRef.current = nowPlaying;
	}, [nowPlaying]);
	useEffect(() => {
		queueRef.current = queue;
	}, [queue]);
	useEffect(() => {
		queueIndexRef.current = queueIndex;
	}, [queueIndex]);

	const fail = useCallback((message: string) => {
		wanted.current = false;
		audio.current?.pause();
		setError(message);
		setState('error');
	}, []);

	// Stream setup — only when no catalog track is playing.
	useEffect(() => {
		if (nowPlaying) return;
		const element = audio.current;
		if (!element || !source) return;
		let disposed = false;
		const setup = async () => {
			if (new URL(source).pathname.toLowerCase().endsWith('.m3u8') && !element.canPlayType('application/vnd.apple.mpegurl')) {
				const { default: HlsEngine } = await import('hls.js');
				if (disposed) return;
				if (!HlsEngine.isSupported()) {
					fail('HLS playback is not supported by this browser. Try a direct MP3 or AAC stream.');
					return;
				}
				const engine = new HlsEngine({ enableWorker: true, lowLatencyMode: true });
				hls.current = engine;
				engine.on(HlsEngine.Events.ERROR, (_event, data) => {
					if (data.fatal) fail('The stream could not be loaded. Check the source URL and its cross-origin permissions, then try again.');
				});
				engine.loadSource(source);
				engine.attachMedia(element);
			} else {
				element.src = source;
				element.load();
			}
		};
		void setup().catch(() => {
			if (!disposed) fail('The stream could not be initialized. Please reconnect and try again.');
		});
		return () => {
			disposed = true;
			wanted.current = false;
			element.pause();
			hls.current?.destroy();
			hls.current = null;
			element.removeAttribute('src');
			element.load();
		};
	}, [source, sourceRevision, nowPlaying, fail]);

	// Catalog track playback — takes over the shared audio element.
	useEffect(() => {
		if (!nowPlaying) return;
		const element = audio.current;
		if (!element) return;
		wanted.current = true;
		setError('');
		setState('connecting');
		hls.current?.destroy();
		hls.current = null;
		element.src = nowPlaying.url;
		element.load();
		void element.play().then(() => {
			if (!wanted.current) element.pause();
		}).catch((cause: unknown) => {
			if (cause instanceof Error && cause.name === 'AbortError') return;
			if (cause instanceof Error && cause.name === 'NotAllowedError' && autoplayAttemptRef.current) {
				autoplayAttemptRef.current = false;
				setAutoplayBlocked(true);
				setState('paused');
				return;
			}
			if (!wanted.current) return;
			fail(cause instanceof Error && cause.name === 'NotAllowedError'
				? 'Your browser blocked playback. Press play again to start listening.'
				: 'Unable to play this track. The audio file or link may be invalid or blocked.');
		});
	}, [nowPlaying, fail]);

	const playStream = useCallback(() => {
		const element = audio.current;
		if (!source || !element) {
			connection.open();
			return;
		}
		wanted.current = true;
		setError('');
		setState('connecting');
		hls.current?.startLoad(-1);
		if (element.error) element.load();
		void element.play().then(() => {
			if (!wanted.current) element.pause();
		}).catch((cause: unknown) => {
			if (cause instanceof Error && cause.name === 'AbortError') return;
			if (cause instanceof Error && cause.name === 'NotAllowedError' && autoplayAttemptRef.current) {
				autoplayAttemptRef.current = false;
				setAutoplayBlocked(true);
				setState('paused');
				return;
			}
			if (!wanted.current) return;
			fail(cause instanceof Error && cause.name === 'NotAllowedError'
				? 'Your browser blocked playback. Press play again to start listening.'
				: 'Unable to play this source. Check that it is a working HTTPS audio stream, not a webpage.');
		});
	}, [source, connection.open, fail]);

	const pause = useCallback(() => {
		wanted.current = false;
		audio.current?.pause();
		setState(nowPlayingRef.current ? 'paused' : source ? 'paused' : 'disconnected');
	}, [source]);

	const toggle = () => {
		if (nowPlayingRef.current) {
			const element = audio.current;
			if (!element) return;
			if (state === 'playing' || state === 'connecting') {
				pause();
			} else {
				wanted.current = true;
				setError('');
				setState('connecting');
				void element.play().then(() => {
					if (!wanted.current) element.pause();
				}).catch((cause: unknown) => {
					if (!wanted.current) return;
					if (cause instanceof Error && cause.name === 'AbortError') return;
					fail('Unable to resume playback. Press play again.');
				});
			}
			return;
		}
		if (state === 'playing' || state === 'connecting') pause();
		else playStream();
	};

	const goLive = () => {
		const element = audio.current;
		if (element && element.seekable.length) element.currentTime = Math.max(0, element.seekable.end(element.seekable.length - 1) - 0.5);
		playStream();
	};

	// Stream connecting timeout (track mode has its own short failure path).
	useEffect(() => {
		if (state !== 'connecting' || nowPlaying) return;
		const timeout = window.setTimeout(() => fail('The stream is taking too long to respond. Check your connection or try another source.'), 20000);
		return () => window.clearTimeout(timeout);
	}, [state, nowPlaying, fail]);

	useEffect(() => {
		if (!('mediaSession' in navigator)) return;
		const track = nowPlayingRef.current;
		navigator.mediaSession.metadata = new MediaMetadata({
			title: track ? track.title : 'Trident Radio',
			artist: track ? track.artist : 'Trident Radio',
			artwork: [{ src: RADIO_ART, sizes: '1024x1024', type: 'image/png' }],
		});
		navigator.mediaSession.setActionHandler('play', toggle);
		navigator.mediaSession.setActionHandler('pause', pause);
		navigator.mediaSession.setActionHandler('nexttrack', () => {
			if (nowPlayingRef.current) playNextRef.current();
		});
		navigator.mediaSession.setActionHandler('previoustrack', () => {
			if (nowPlayingRef.current) playPrevRef.current();
		});
		return () => {
			navigator.mediaSession.setActionHandler('play', null);
			navigator.mediaSession.setActionHandler('pause', null);
			navigator.mediaSession.setActionHandler('nexttrack', null);
			navigator.mediaSession.setActionHandler('previoustrack', null);
			navigator.mediaSession.metadata = null;
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [toggle, pause, nowPlaying]);

	useEffect(() => {
		if ('mediaSession' in navigator) navigator.mediaSession.playbackState = state === 'playing' ? 'playing' : 'paused';
	}, [state]);

	const playTrack = useCallback((track: NowPlayingTrack) => {
		wanted.current = false;
		hls.current?.destroy();
		hls.current = null;
		setQueue([track]);
		setQueueIndex(0);
		setNowPlaying(track);
	}, []);

	const playQueue = useCallback((tracks: NowPlayingTrack[], startIndex = 0) => {
		if (tracks.length === 0) return;
		const idx = Math.max(0, Math.min(startIndex, tracks.length - 1));
		wanted.current = false;
		hls.current?.destroy();
		hls.current = null;
		setQueue(tracks);
		setQueueIndex(idx);
		setNowPlaying(tracks[idx]);
	}, []);

	const playNext = useCallback(() => {
		const q = queueRef.current;
		const idx = queueIndexRef.current;
		if (q.length === 0) return;
		const next = idx + 1;
		if (next >= q.length) {
			wanted.current = false;
			audio.current?.pause();
			setNowPlaying(null);
			setQueue([]);
			setQueueIndex(-1);
			setState(source ? 'ready' : 'disconnected');
			return;
		}
		setQueueIndex(next);
		setNowPlaying(q[next]);
	}, [source]);

	const playPrev = useCallback(() => {
		const q = queueRef.current;
		const idx = queueIndexRef.current;
		if (q.length === 0) return;
		const prev = idx - 1;
		if (prev < 0) return;
		setQueueIndex(prev);
		setNowPlaying(q[prev]);
	}, []);

	// Keep refs to the queue advance functions for the mediaSession handlers.
	useEffect(() => {
		playNextRef.current = playNext;
	}, [playNext]);
	useEffect(() => {
		playPrevRef.current = playPrev;
	}, [playPrev]);

	const stopTrack = useCallback(() => {
		wanted.current = false;
		audio.current?.pause();
		setNowPlaying(null);
		setQueue([]);
		setQueueIndex(-1);
		setState(source ? 'ready' : 'disconnected');
	}, [source]);

	const connect = (url: string) => {
		pause();
		setNowPlaying(null);
		setQueue([]);
		setQueueIndex(-1);
		setSource(url);
		setSourceRevision((current) => current + 1);
		setError('');
		setState('ready');
		connection.close();
	};

	const startListening = useCallback(() => {
		setAutoplayBlocked(false);
		toggle();
	}, [toggle]);

	// Auto-populate the Trident Radio queue with every playable track and try
	// to start listening the moment a visitor arrives. Browsers usually block
	// autoplay until the listener interacts, so a friendly "Start listening"
	// prompt is shown then. Tracks without usable audio are excluded, and
	// duplicate ids are skipped so the queue stays clean.
	useEffect(() => {
		let cancelled = false;
		(async () => {
			type RotationTrack = { id: string; title?: string; credit?: string; audio_file?: string; audio_url?: string };
			let queue: NowPlayingTrack[] = [];
			try {
				const list = await pb.collection('tracks').getFullList<RotationTrack>({
					filter: 'rotation = "active"',
					sort: '-created',
					requestKey: null,
				});
				if (cancelled) return;
				const seen = new Set<string>();
				queue = list
					.map((t) => {
						const url = t.audio_file ? pb.files.getURL(t, t.audio_file) : t.audio_url || '';
						if (!url || seen.has(t.id)) return null;
						seen.add(t.id);
						return {
							id: t.id,
							title: t.title || 'Untitled track',
							artist: t.credit || 'Unknown artist',
							url,
						} as NowPlayingTrack;
					})
					.filter((t): t is NowPlayingTrack => t !== null);
			} catch {
				if (cancelled) return;
			}
			if (cancelled) return;
			if (queue.length > 0) {
				setQueue(queue);
				setQueueIndex(0);
				setHasContent(true);
				autoplayAttemptRef.current = true;
				setNowPlaying(queue[0]);
			} else if (source) {
				setHasContent(true);
				autoplayAttemptRef.current = true;
				playStream();
			} else {
				setHasContent(false);
			}
		})();
		return () => { cancelled = true; };
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	const setVolume = (value: number) => {
		const next = Math.max(0, Math.min(1, value));
		if (audio.current) {
			audio.current.volume = next;
			audio.current.muted = false;
		}
		updateVolume(next);
		setMuted(false);
	};

	const toggleMute = () => {
		if (audio.current) audio.current.muted = !muted;
		setMuted(!muted);
	};

	return (
		<RadioContext.Provider
			value={{
				source,
				state,
				error,
				volume,
				muted,
				nowPlaying,
				queue,
				queueIndex,
				connect,
				toggle,
				goLive,
				setVolume,
				toggleMute,
				playTrack,
				playQueue,
				playNext,
				playPrev,
				stopTrack,
				connection,
				autoplayBlocked,
				hasContent,
				startListening,
			}}
		>
			<audio
				ref={audio}
				preload="none"
				aria-label="Trident Radio audio"
				onLoadedMetadata={() => {
					if (audio.current) audio.current.volume = volume;
				}}
				onPlaying={() => {
					setAutoplayBlocked(false);
					if (wanted.current) setState('playing');
				}}
				onWaiting={() => {
					if (wanted.current) setState('connecting');
				}}
				onPause={() => {
					if (!wanted.current) return;
					wanted.current = false;
					setState('paused');
				}}
				onEnded={() => {
					if (nowPlayingRef.current) {
						playNextRef.current();
					} else {
						fail('The broadcast has ended or disconnected. Try reconnecting to the live stream.');
					}
				}}
				onError={() => {
					if (nowPlayingRef.current) {
						fail('This track could not be played. The audio file or link may be invalid or blocked.');
					} else if (source && audio.current?.error) {
						fail('This audio source is unavailable or unsupported. Check the stream URL and try again.');
					}
				}}
			/>
			{children}
		</RadioContext.Provider>
	);
}

export function useRadio() {
	const context = useContext(RadioContext);
	if (!context) throw new Error('Radio controls must be inside RadioProvider.');
	return context;
}
