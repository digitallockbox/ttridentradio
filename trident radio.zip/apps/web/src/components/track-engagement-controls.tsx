import { Link } from 'react-router';
import { ListPlus, ThumbsDown, ThumbsUp, UserCheck } from 'lucide-react';
import { useTrackEngagement } from '@/hooks/use-track-engagement';

/**
 * Minimal track shape the engagement controls need. Works for any track from
 * the `tracks` collection (artist catalog or station rotation) — only the
 * caller's curated records (reactions, playlist entries, follows) change.
 * The original track and its audio stay owned and editable by the artist.
 */
export type EngageableTrack = {
	id: string;
	title?: string;
	credit?: string;
	owner?: string;
};

/**
 * Per-track engagement: follow the artist, thumbs-up/down, and add to / remove
 * from the signed-in listener's personal Trident playlist. All state is
 * owner-scoped in PocketBase, so a listener only ever touches their own
 * reaction / playlist / follow records — never the artist's track or audio.
 * Signed-out visitors see a single sign-in prompt instead of the controls.
 */
export function TrackEngagementControls({ track }: { track: EngageableTrack }) {
	const { isAuthed, reactions, playlistIds, follows, busy, toggleReaction, togglePlaylist, toggleFollow } = useTrackEngagement();
	const artistId = track.owner || '';

	if (!isAuthed) {
		return (
			<p className="engagement-signin">
				<Link to="/login">Sign in</Link> to like, follow, and add to your Trident playlist.
			</p>
		);
	}

	const reaction = reactions[track.id];
	const inPlaylist = playlistIds.has(track.id);
	const following = artistId ? follows.has(artistId) : false;

	return (
		<div className="track-engagement">
			<button
				className={`engagement-btn ${following ? 'is-active follow' : ''}`}
				onClick={() => artistId && toggleFollow(artistId)}
				disabled={busy || !artistId}
				aria-pressed={following}
				title={following ? 'Unfollow artist' : 'Follow artist'}
				aria-label={following ? `Unfollow ${track.credit}` : `Follow ${track.credit}`}
			>
				<UserCheck size={15} />
			</button>
			<button
				className={`engagement-btn ${reaction === 'like' ? 'is-active like' : ''}`}
				onClick={() => toggleReaction(track.id, 'like')}
				disabled={busy}
				aria-pressed={reaction === 'like'}
				title="Thumbs up"
				aria-label={`Thumbs up ${track.title}`}
			>
				<ThumbsUp size={15} />
			</button>
			<button
				className={`engagement-btn ${reaction === 'dislike' ? 'is-active dislike' : ''}`}
				onClick={() => toggleReaction(track.id, 'dislike')}
				disabled={busy}
				aria-pressed={reaction === 'dislike'}
				title="Thumbs down"
				aria-label={`Thumbs down ${track.title}`}
			>
				<ThumbsDown size={15} />
			</button>
			<button
				className={`engagement-btn ${inPlaylist ? 'is-active playlist' : ''}`}
				onClick={() => togglePlaylist(track.id)}
				disabled={busy}
				aria-pressed={inPlaylist}
				title={inPlaylist ? 'Remove from playlist' : 'Add to Trident playlist'}
				aria-label={inPlaylist ? `Remove ${track.title} from playlist` : `Add ${track.title} to playlist`}
			>
				<ListPlus size={15} />
			</button>
		</div>
	);
}
