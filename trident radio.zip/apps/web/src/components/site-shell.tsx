import { useState } from 'react';
import { BookOpen, ChevronRight, Disc3, Home, Library, ListMusic, Mic, Plus, Radio, Search, Settings2, Upload } from 'lucide-react';
import { Form, Link, useLocation, useSearchParams } from 'react-router';
import { useRadio } from '@/components/radio-provider';
import { useUpload } from '@/components/upload-dialog';
import { ArtistSpotlight } from '@/components/home/artist-spotlight';
import { AuthNav } from '@/components/auth/auth-nav';
import { openCookiePreferences } from '@/lib/cookie-consent';
import { RADIO_ART } from '@/constants/radio';

const responsiveImage = (src: string) => `${src}?width=375 375w, ${src}?width=768 768w, ${src} 1024w`;

const libraryItems = [
  { title: 'Trident Radio', subtitle: 'Station · Trident Radio', href: '/station', image: RADIO_ART },
  { title: 'Anthony D. Simmons', subtitle: 'Artist · Trident Radio', href: '/artist', image: 'https://images.hostinger.com/f6881439-8a7e-4aec-a226-489cfe40cc9a/65779716-f619-4483-abcf-72a387aa12e8.png' },
  { title: 'Artist catalog', subtitle: 'Music · Anthony D. Simmons', href: '/artist#catalog', image: 'https://images.hostinger.com/f6881439-8a7e-4aec-a226-489cfe40cc9a/d60392da-7c08-4ea5-9775-619dc080afde.png' },
  { title: 'CreatorOS Hub', subtitle: 'Creator tools · CreatorOS Hub', href: '/#creatoros', image: 'https://images.hostinger.com/f6881439-8a7e-4aec-a226-489cfe40cc9a/0e1fa34e-6477-4359-bb3d-c2eccc4c5771.png' },
];

export function SiteShell({ children }: { children: React.ReactNode }) {
  const radio = useRadio();
  const upload = useUpload();
  const location = useLocation();
  const [params] = useSearchParams();
  const [libraryFilter, setLibraryFilter] = useState('All');
  const isHome = location.pathname === '/';
  const visibleItems = libraryItems.filter(item => libraryFilter === 'All' || (libraryFilter === 'Artists' ? item.title === 'Anthony D. Simmons' : item.title !== 'Anthony D. Simmons'));

  return <div className={`app-shell ${isHome ? 'is-home' : ''}`}>
    <header className="dashboard-header">
      <Link to="/" className="dashboard-brand" aria-label="Trident Radio home"><img src={RADIO_ART} alt="" className="brand-logo" /><strong>Trident Radio</strong></Link>
      <div className="header-search-group">
        <Link to="/" className="header-home" aria-label="Home"><Home size={22} fill="currentColor" /></Link>
        <Form action="/" method="get" className="dashboard-search" role="search">
          <Search size={22} aria-hidden="true" />
          <input key={params.get('q') || ''} name="q" defaultValue={params.get('q') || ''} placeholder="What do you want to listen to?" aria-label="Search the dashboard" />
          <button type="submit" aria-label="Search"><ListMusic size={21} /></button>
        </Form>
      </div>
      <div className="dashboard-header-actions"><Link to="/podcast" className="header-creator">Podcast</Link><Link to="/#creatoros" className="header-creator">Explore CreatorOS</Link><Link to="/playbook" className="header-creator">Campaign Playbook</Link><button className="header-upload" onClick={upload.open}><Upload size={17} /> Upload</button><button className="header-settings" onClick={radio.connection.open} aria-label="Stream settings" title="Stream settings"><Settings2 size={19} /></button><AuthNav /></div>
    </header>
    <aside className="library-sidebar" aria-label="Your library">
      <div className="library-heading"><div><Library size={20} /><strong>Your Library</strong></div><button onClick={upload.open}><Plus size={18} /> <span>Create</span></button></div>
      <div className="library-filters" aria-label="Filter library">{['All', 'Music', 'Artists'].map(filter => <button key={filter} className={libraryFilter === filter ? 'selected' : ''} onClick={() => setLibraryFilter(filter)} aria-pressed={libraryFilter === filter}>{filter}</button>)}</div>
      <div className="library-sort"><Search size={17} /><span>Recents <ListMusic size={16} /></span></div>
      <nav className="library-list" aria-label="Library navigation">
        {visibleItems.map((item, index) => <Link to={item.href} className="library-item" key={item.title}><img src={item.image} srcSet={responsiveImage(item.image)} sizes="45px" alt="" className={item.title === 'Anthony D. Simmons' ? 'round-art' : ''} /><span><strong className={index === 0 && libraryFilter !== 'Artists' ? 'library-current' : ''}>{item.title}</strong><small>{item.subtitle}</small></span></Link>)}
        <Link to="/#listening-guide" className="library-item"><span className="library-icon"><Radio size={21} /></span><span><strong>Listening guide</strong><small>Get to know your player</small></span></Link>
        <Link to="/playbook" className="library-item"><span className="library-icon"><BookOpen size={21} /></span><span><strong>Campaign playbook</strong><small>Strategy · Creator resources</small></span></Link>
        <Link to="/station#station-setup" className="library-item"><span className="library-icon library-icon-purple"><Disc3 size={21} /></span><span><strong>Station hub</strong><small>Setup · Trident Radio</small></span></Link>
        <Link to="/podcast" className="library-item"><span className="library-icon"><Mic size={21} /></span><span><strong>Podcast</strong><small>Episodes · Trident Radio</small></span></Link>
        <Link to="/playlist" className="library-item"><span className="library-icon"><ListMusic size={21} /></span><span><strong>Your playlist</strong><small>Curate · Any artist</small></span></Link>
      </nav>
      <div className="library-bottom"><Link to="/signup" className="library-join"><Plus size={15} /> Join as artist</Link><Link to="/playbook" className="library-join"><BookOpen size={15} /> Campaign playbook</Link><button onClick={radio.connection.open}><Settings2 size={15} /> Stream settings</button><button onClick={openCookiePreferences}>Cookie settings</button><span>TRIDENT RADIO</span></div>
    </aside>
    <div className="main-shell">{!isHome && <div className="inner-breadcrumb"><Link to="/">Home</Link><ChevronRight size={14} /><span>{location.pathname === '/playbook' ? 'Campaign playbook' : location.pathname === '/artist' ? 'Artist catalog' : location.pathname === '/account' ? 'Your account' : location.pathname === '/signup' ? 'Artist sign-up' : location.pathname === '/login' ? 'Sign in' : location.pathname === '/podcast' ? 'Podcast' : location.pathname === '/playlist' ? 'Your playlist' : 'Station hub'}</span></div>}{children}</div>
    {isHome && <ArtistSpotlight />}
  </div>;
}
