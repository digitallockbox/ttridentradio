import { Link } from 'react-router';
import { useAuth } from '@/hooks/use-auth';

/**
 * Header auth control. The session lives in localStorage, so the server
 * renders signed-out; render a neutral placeholder while the browser restores
 * the session to avoid a "Sign in" flash for signed-in visitors.
 */
export function AuthNav() {
	const { user, isAuthed, isLoading } = useAuth();

	if (isLoading) {
		return <span className="profile-mark" aria-hidden="true">··</span>;
	}

	if (isAuthed && user) {
		const initials = (user.name || user.email || 'A')
			.split(/\s+/)
			.map((part: string) => part.charAt(0))
			.join('')
			.slice(0, 2)
			.toUpperCase();
		return (
			<Link to="/account" className="profile-mark" aria-label="Your account" title="Your account">
				{initials}
			</Link>
		);
	}

	return <Link to="/login" className="header-signin" aria-label="Sign in">Sign in</Link>;
}
