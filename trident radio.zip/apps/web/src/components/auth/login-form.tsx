import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { AlertCircle, Loader2, LogIn, MailCheck } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbase-client';

export function LoginForm() {
	const { login } = useAuth();
	const navigate = useNavigate();
	const [email, setEmail] = useState('');
	const [password, setPassword] = useState('');
	const [error, setError] = useState('');
	const [busy, setBusy] = useState(false);
	const [resetSent, setResetSent] = useState(false);
	const [verifySent, setVerifySent] = useState(false);

	const submit = async (event: React.FormEvent) => {
		event.preventDefault();
		setError('');
		setBusy(true);
		try {
			await login(email.trim(), password);
			navigate('/account');
		} catch (err) {
			const status = (err as { status?: number }).status;
			if (status === 400) {
				setError('That email or password doesn\'t match an account.');
			} else {
				setError('Could not sign in right now. Please try again.');
			}
		} finally {
			setBusy(false);
		}
	};

	const sendReset = async () => {
		if (!email.trim()) {
			setError('Enter your email above first, then resend the reset link.');
			return;
		}
		setError('');
		try {
			await pb.collection('users').requestPasswordReset(email.trim());
			setResetSent(true);
		} catch {
			setError('Could not send a reset link. Try again in a moment.');
		}
	};

	const sendVerification = async () => {
		if (!email.trim()) {
			setError('Enter your email above first, then resend the verification link.');
			return;
		}
		setError('');
		try {
			await pb.collection('users').requestVerification(email.trim());
			setVerifySent(true);
		} catch {
			setError('Could not send a verification link. Try again in a moment.');
		}
	};

	return (
		<form className="auth-form" onSubmit={submit}>
			<div className="auth-field">
				<label htmlFor="login-email">Email</label>
				<input
					id="login-email"
					type="email"
					autoComplete="email"
					required
					value={email}
					onChange={e => setEmail(e.target.value)}
					placeholder="you@example.com"
				/>
			</div>
			<div className="auth-field">
				<label htmlFor="login-password">Password</label>
				<input
					id="login-password"
					type="password"
					autoComplete="current-password"
					required
					value={password}
					onChange={e => setPassword(e.target.value)}
					placeholder="Your password"
				/>
			</div>

			{error && (
				<p className="field-error auth-error" role="alert">
					<AlertCircle size={14} /> {error}
				</p>
			)}

			<button type="submit" className="button button-cyan auth-submit" disabled={busy}>
				{busy ? <><Loader2 size={17} className="spin" /> Signing in…</> : <><LogIn size={17} /> Sign in</>}
			</button>

			<div className="auth-help">
				{resetSent ? (
					<p className="auth-help-sent"><MailCheck size={14} /> Reset link sent — check your inbox.</p>
				) : (
					<button type="button" onClick={sendReset}>Forgot password?</button>
				)}
				{verifySent ? (
					<p className="auth-help-sent"><MailCheck size={14} /> Verification link sent.</p>
				) : (
					<button type="button" onClick={sendVerification}>Resend verification</button>
				)}
			</div>

			<p className="auth-switch">
				New artist? <Link to="/signup">Create an account</Link>
			</p>
		</form>
	);
}
