import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { AlertCircle, Loader2, UserPlus } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbase-client';

export function SignupForm() {
	const { signup } = useAuth();
	const navigate = useNavigate();
	const [name, setName] = useState('');
	const [email, setEmail] = useState('');
	const [password, setPassword] = useState('');
	const [confirm, setConfirm] = useState('');
	const [error, setError] = useState('');
	const [busy, setBusy] = useState(false);

	const submit = async (event: React.FormEvent) => {
		event.preventDefault();
		setError('');

		if (password.length < 8) {
			setError('Password must be at least 8 characters.');
			return;
		}
		if (password !== confirm) {
			setError('Passwords do not match.');
			return;
		}

		setBusy(true);
		try {
			await signup(email.trim(), password, { name: name.trim(), role: 'artist' });
			// Best-effort email confirmation — not required to sign in.
			try {
				await pb.collection('users').requestVerification(email.trim());
			} catch {
				/* verification email is best-effort */
			}
			navigate('/account');
		} catch (err) {
			const status = (err as { status?: number }).status;
			if (status === 400) {
				setError('That email is already registered or the details are invalid.');
			} else {
				setError('Could not create the account right now. Please try again.');
			}
		} finally {
			setBusy(false);
		}
	};

	return (
		<form className="auth-form" onSubmit={submit}>
			<div className="auth-field">
				<label htmlFor="signup-name">Artist / display name</label>
				<input
					id="signup-name"
					type="text"
					autoComplete="name"
					required
					value={name}
					onChange={e => setName(e.target.value)}
					placeholder="Your artist name"
				/>
			</div>
			<div className="auth-field">
				<label htmlFor="signup-email">Email</label>
				<input
					id="signup-email"
					type="email"
					autoComplete="email"
					required
					value={email}
					onChange={e => setEmail(e.target.value)}
					placeholder="you@example.com"
				/>
			</div>
			<div className="auth-field">
				<label htmlFor="signup-password">Password</label>
				<input
					id="signup-password"
					type="password"
					autoComplete="new-password"
					required
					value={password}
					onChange={e => setPassword(e.target.value)}
					placeholder="At least 8 characters"
				/>
			</div>
			<div className="auth-field">
				<label htmlFor="signup-confirm">Confirm password</label>
				<input
					id="signup-confirm"
					type="password"
					autoComplete="new-password"
					required
					value={confirm}
					onChange={e => setConfirm(e.target.value)}
					placeholder="Re-enter your password"
				/>
			</div>

			{error && (
				<p className="field-error auth-error" role="alert">
					<AlertCircle size={14} /> {error}
				</p>
			)}

			<button type="submit" className="button button-cyan auth-submit" disabled={busy}>
				{busy ? <><Loader2 size={17} className="spin" /> Creating account…</> : <><UserPlus size={17} /> Create artist account</>}
			</button>

			<p className="auth-switch">
				Already have an account? <Link to="/login">Sign in</Link>
			</p>
		</form>
	);
}
