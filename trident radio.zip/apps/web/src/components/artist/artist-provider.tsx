import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import pb from '@/lib/pocketbase-client';
import { useRadio, type NowPlayingTrack } from '@/components/radio-provider';

export type RotationStatus = 'pending' | 'active' | 'paused' | '';

export type ArtistTrack = {
	id: string;
	collectionId: string;
	collectionName: string;
	title: string;
	credit?: string;
	genre?: string;
	audio_file?: string;
	audio_url?: string;
	rotation?: RotationStatus;
	owner?: string;
	created?: string;
};

type ArtistContextValue = {
	tracks: ArtistTrack[];
	playableTracks: ArtistTrack[];
	loading: boolean;
	error: string;
	artistId: string;
	reload: () => void;
	patchTrack: (id: string, patch: Partial<ArtistTrack>) => void;
	playAll: () => void;
	playTrack: (track: ArtistTrack) => void;
};

const ArtistContext = createContext<ArtistContextValue | null>(null);

export function trackAudioUrl(track: ArtistTrack): string {
	if (track.audio_file) return pb.files.getURL(track, track.audio_file);
	if (track.audio_url) return track.audio_url;
	return '';
}

export function isRotationEligible(track: ArtistTrack): boolean {
	return Boolean(track.audio_file || track.audio_url);
}

export function rotationStatus(track: ArtistTrack): RotationStatus {
	const value = track.rotation;
	if (value === 'active' || value === 'paused' || value === 'pending') return value;
	return 'pending';
}

export const ROTATION_BADGE: Record<RotationStatus, { label: string; className: string }> = {
	pending: { label: 'PENDING ROTATION', className: 'rotation-badge-pending' },
	active: { label: 'IN ROTATION', className: 'rotation-badge-active' },
	paused: { label: 'ROTATION PAUSED', className: 'rotation-badge-paused' },
	'': { label: 'PENDING ROTATION', className: 'rotation-badge-pending' },
};

export function toNowPlaying(track: ArtistTrack): NowPlayingTrack | null {
	const url = trackAudioUrl(track);
	if (!url) return null;
	return {
		id: track.id,
		title: track.title,
		artist: track.credit || 'Unknown artist',
		url,
	};
}

/**
 * Shared artist-catalog state. Fetches the track list once and exposes it to
 * both the hero (for the Play / stats CTA) and the catalog (for the list,
 * rotation controls, and engagement). Playback goes through the shared Trident
 * Radio player so the now-playing track and artist surface everywhere.
 */
export function ArtistProvider({ children }: { children: ReactNode }) {
	const radio = useRadio();
	const [tracks, setTracks] = useState<ArtistTrack[]>([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState('');

	const reload = useCallback(async () => {
		setLoading(true);
		setError('');
		try {
			const list = await pb.collection('tracks').getFullList<ArtistTrack>({ sort: '-created', requestKey: null });
			setTracks(list);
		} catch {
			setError('Could not load tracks. Please try again later.');
		} finally {
			setLoading(false);
		}
	}, []);

	useEffect(() => {
		void reload();
	}, [reload]);

	const patchTrack = useCallback((id: string, patch: Partial<ArtistTrack>) => {
		setTracks((prev) => prev.map((t) => (t.id === id ? { ...t, ...patch } : t)));
	}, []);

	const playableTracks = useMemo(() => tracks.filter(isRotationEligible), [tracks]);

	const artistId = useMemo(() => {
		const withOwner = tracks.find((t) => t.owner);
		return withOwner?.owner || '';
	}, [tracks]);

	const playAll = useCallback(() => {
		const queue = playableTracks
			.map(toNowPlaying)
			.filter((t): t is NowPlayingTrack => Boolean(t));
		if (queue.length > 0) radio.playQueue(queue, 0);
	}, [playableTracks, radio]);

	const playTrack = useCallback(
		(track: ArtistTrack) => {
			const np = toNowPlaying(track);
			if (!np) return;
			if (radio.nowPlaying?.id === track.id) {
				radio.toggle();
				return;
			}
			radio.playTrack(np);
		},
		[radio],
	);

	return (
		<ArtistContext.Provider
			value={{ tracks, playableTracks, loading, error, artistId, reload, patchTrack, playAll, playTrack }}
		>
			{children}
		</ArtistContext.Provider>
	);
}

export function useArtist() {
	const ctx = useContext(ArtistContext);
	if (!ctx) throw new Error('useArtist must be used inside ArtistProvider.');
	return ctx;
}
