import { useState, type FormEvent } from 'react';
import {
	AlertCircle,
	ArrowUpRight,
	CheckCircle2,
	FileAudio,
	Link2,
	Loader2,
	Music,
	UploadCloud,
	X,
} from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbase-client';

type AddMode = 'file' | 'batch' | 'url';

type BatchStatus = 'queued' | 'uploading' | 'done' | 'error';

type BatchItem = {
	id: string;
	file: File;
	title: string;
	status: BatchStatus;
	error?: string;
};

const AUDIO_ACCEPT =
	'.mp3,.wav,.ogg,.m4a,.flac,.aac,.weba,.webm,audio/mpeg,audio/mp3,audio/wav,audio/ogg,audio/aac,audio/flac,audio/x-m4a,audio/m4a,audio/webm,audio/mp4';

const MAX_BYTES = 20 * 1024 * 1024; // 20 MB — matches the tracks file field cap

function isAudioFile(file: File): boolean {
	if (file.type.startsWith('audio/')) return true;
	const name = file.name.toLowerCase();
	return /\.(mp3|wav|ogg|m4a|flac|aac|weba|webm)$/i.test(name);
}

function formatSize(bytes: number) {
	if (bytes < 1024) return `${bytes} B`;
	if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
	return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function stripExtension(name: string): string {
	return name.replace(/\.[^.]+$/, '');
}

/**
 * Detects an HLS playlist URL. The catalog player uses a plain <audio>
 * element, so an HLS feed (.m3u8) cannot be played as a catalog track and
 * must not be advertised as one. Live station streams are configured separately
 * through the stream settings dialog.
 */
function looksLikeHls(url: string): boolean {
	try {
		const parsed = new URL(url);
		return parsed.pathname.toLowerCase().includes('.m3u8');
	} catch {
		return false;
	}
}

/**
 * Dialog for adding tracks to the artist catalog through three ingestion
 * methods: a single direct file upload, a drag-and-drop batch dropzone, or a
 * direct audio URL. Tracks are created directly through the browser SDK under
 * the signed-in user, so PocketBase access rules enforce ownership. HLS/live
 * stream URLs are rejected with an honest explanation rather than added as
 * playable tracks.
 */
export function AddTrackDialog({
	open,
	onClose,
	onAdded,
}: {
	open: boolean;
	onClose: () => void;
	onAdded: () => void;
}) {
	const { user } = useAuth();
	const [mode, setMode] = useState<AddMode>('file');

	// Shared fields
	const [genre, setGenre] = useState('');
	const [credit, setCredit] = useState(user?.name ?? '');

	// Single-file mode
	const [title, setTitle] = useState('');
	const [file, setFile] = useState<File | null>(null);

	// URL mode
	const [url, setUrl] = useState('');

	// Batch mode
	const [batch, setBatch] = useState<BatchItem[]>([]);
	const [batchDragging, setBatchDragging] = useState(false);
	const [batchSaving, setBatchSaving] = useState(false);

	const [error, setError] = useState('');
	const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
	const [saving, setSaving] = useState(false);
	const [rightsConfirmed, setRightsConfirmed] = useState(false);

	const reset = () => {
		setMode('file');
		setTitle('');
		setGenre('');
		setCredit(user?.name ?? '');
		setFile(null);
		setUrl('');
		setBatch([]);
		setBatchDragging(false);
		setBatchSaving(false);
		setError('');
		setFieldErrors({});
		setRightsConfirmed(false);
	};

	const close = () => {
		reset();
		onClose();
	};

	const validateUrl = (value: string): string | null => {
		const trimmed = value.trim();
		if (!trimmed) return 'Paste a direct audio link.';
		try {
			const parsed = new URL(trimmed);
			if (!['http:', 'https:'].includes(parsed.protocol)) {
				return 'The link must start with http:// or https://.';
			}
		} catch {
			return 'That does not look like a valid URL.';
		}
		if (looksLikeHls(trimmed)) {
			return 'HLS live streams (.m3u8) are not supported as catalog tracks. The catalog player plays individual audio files. To set a live station stream, use the stream settings dialog.';
		}
		return null;
	};

	const submitFile = async () => {
		if (!user) {
			setError('Sign in to add a track.');
			return;
		}
		const errors: Record<string, string> = {};
		if (!title.trim()) errors.title = 'Title is required.';
		if (!file) errors.file = 'Choose an audio file to upload.';
		setFieldErrors(errors);
		if (Object.keys(errors).length > 0) return;

		setSaving(true);
		setError('');
		try {
			const formData = new FormData();
			formData.append('title', title.trim());
			formData.append('genre', genre.trim());
			formData.append('credit', credit.trim() || user.name || '');
			formData.append('owner', user.id);
			formData.append('rotation', 'pending');
			formData.append('audio_file', file as File, (file as File).name);
			await pb.collection('tracks').create(formData);
			reset();
			onAdded();
			onClose();
		} catch (err) {
			mapPocketBaseError(err, 'Could not add the track. Please check the details and try again.');
		} finally {
			setSaving(false);
		}
	};

	const submitUrl = async () => {
		if (!user) {
			setError('Sign in to add a track.');
			return;
		}
		const errors: Record<string, string> = {};
		if (!title.trim()) errors.title = 'Title is required.';
		const urlError = validateUrl(url);
		if (urlError) errors.url = urlError;
		setFieldErrors(errors);
		if (Object.keys(errors).length > 0) return;

		setSaving(true);
		setError('');
		try {
			await pb.collection('tracks').create({
				title: title.trim(),
				genre: genre.trim(),
				credit: credit.trim() || user.name || '',
				audio_url: url.trim(),
				rotation: 'pending',
				owner: user.id,
			});
			reset();
			onAdded();
			onClose();
		} catch (err) {
			mapPocketBaseError(err, 'Could not add the track. Please try again.');
		} finally {
			setSaving(false);
		}
	};

	const addBatchFiles = (list: FileList | null) => {
		if (!list || list.length === 0) return;
		setError('');
		const incoming = Array.from(list);
		const rejected: string[] = [];
		const accepted: BatchItem[] = [];
		for (const f of incoming) {
			if (!isAudioFile(f)) {
				rejected.push(f.name);
				continue;
			}
			if (f.size > MAX_BYTES) {
				rejected.push(`${f.name} (over 20 MB)`);
				continue;
			}
			accepted.push({
				id: `${f.name}-${f.size}-${Math.random().toString(36).slice(2, 8)}`,
				file: f,
				title: stripExtension(f.name),
				status: 'queued',
			});
		}
		if (rejected.length > 0) {
			setError(`Skipped: ${rejected.join(', ')}. Only audio files up to 20 MB are accepted.`);
		}
		if (accepted.length > 0) {
			setBatch(current => [...current, ...accepted]);
		}
	};

	const removeBatchItem = (id: string) =>
		setBatch(current => current.filter(item => item.id !== id));

	const setBatchTitle = (id: string, value: string) =>
		setBatch(current => current.map(item => (item.id === id ? { ...item, title: value } : item)));

	const uploadBatch = async () => {
		if (!user) {
			setError('Sign in to add tracks.');
			return;
		}
		const pending = batch.filter(item => item.status === 'queued' || item.status === 'error');
		if (pending.length === 0) return;
		setBatchSaving(true);
		setError('');

		await Promise.all(
			pending.map(async (item, index) => {
				setBatch(current =>
					current.map(row => (row.id === item.id ? { ...row, status: 'uploading', error: undefined } : row)),
				);
				try {
					const formData = new FormData();
					formData.append('title', item.title.trim() || stripExtension(item.file.name));
					formData.append('genre', genre.trim());
					formData.append('credit', credit.trim() || user.name || '');
					formData.append('owner', user.id);
					formData.append('rotation', 'pending');
					formData.append('audio_file', item.file, item.file.name);
					// Distinct requestKey per create so parallel writes don't
					// auto-cancel each other (shared SDK key = METHOD + path).
					await pb.collection('tracks').create(formData, { requestKey: `add-track-batch-${item.id}-${index}` });
					setBatch(current =>
						current.map(row => (row.id === item.id ? { ...row, status: 'done' } : row)),
					);
				} catch (err) {
					const message = extractPocketBaseMessage(err, 'Could not upload this file.');
					setBatch(current =>
						current.map(row => (row.id === item.id ? { ...row, status: 'error', error: message } : row)),
					);
				}
			}),
		);

		setBatchSaving(false);
		// Refresh the catalog so newly added tracks appear, but keep the dialog
		// open so the user sees every file's result.
		onAdded();
	};

	const finishBatch = () => {
		reset();
		onClose();
	};

	function mapPocketBaseError(err: unknown, fallback: string) {
		const response = (err as { response?: { data?: Record<string, { message?: string }> } }).response;
		if (response?.data) {
			const mapped: Record<string, string> = {};
			for (const [field, detail] of Object.entries(response.data)) {
				if (detail?.message) mapped[field] = detail.message;
			}
			if (Object.keys(mapped).length > 0) {
				setFieldErrors(prev => ({ ...prev, ...mapped }));
				return;
			}
		}
		setError(fallback);
	}

	function extractPocketBaseMessage(err: unknown, fallback: string): string {
		const response = (err as { response?: { data?: Record<string, { message?: string }> } }).response;
		if (response?.data) {
			const messages = Object.values(response.data)
				.map(detail => detail?.message)
				.filter(Boolean);
			if (messages.length > 0) return messages.join(' ');
		}
		return fallback;
	}

	const submit = (event: FormEvent) => {
		event.preventDefault();
		if (mode === 'file') void submitFile();
		else if (mode === 'url') void submitUrl();
	};

	const batchDoneCount = batch.filter(item => item.status === 'done').length;
	const batchErrorCount = batch.filter(item => item.status === 'error').length;
	const batchHasPending = batch.some(item => item.status === 'queued' || item.status === 'error');
	const batchAllDone = batch.length > 0 && batch.every(item => item.status === 'done');

	return (
		<Dialog open={open} onOpenChange={open => { if (!open) close(); }}>
			<DialogContent className="radio-dialog upload-dialog">
				<span className="dialog-icon"><Music size={25} /></span>
				<DialogTitle className="dialog-title">Add tracks.</DialogTitle>
				<DialogDescription>
					Choose how to add audio to your catalog: upload a single file, drop a batch, or paste a direct audio link. Every track with audio is submitted to the Trident Radio rotation catalog as pending — activate it from the catalog to add it to spin rotation.
				</DialogDescription>

				<div className="track-mode-toggle" role="tablist" aria-label="Add track by">
					<button
						type="button"
						role="tab"
						aria-selected={mode === 'file'}
						className={`track-mode-btn ${mode === 'file' ? 'active' : ''}`}
						onClick={() => setMode('file')}
					>
						<UploadCloud size={15} /> File upload
					</button>
					<button
						type="button"
						role="tab"
						aria-selected={mode === 'batch'}
						className={`track-mode-btn ${mode === 'batch' ? 'active' : ''}`}
						onClick={() => setMode('batch')}
					>
						<FileAudio size={15} /> Batch drop
					</button>
					<button
						type="button"
						role="tab"
						aria-selected={mode === 'url'}
						className={`track-mode-btn ${mode === 'url' ? 'active' : ''}`}
						onClick={() => setMode('url')}
					>
						<Link2 size={15} /> Stream URL
					</button>
				</div>

				<div className="rights-confirm">
					<label className="rights-confirm-label">
						<input
							type="checkbox"
							checked={rightsConfirmed}
							onChange={(e) => setRightsConfirmed(e.target.checked)}
						/>
						<span>I own or am authorized to distribute this audio, and it does not infringe any third party’s rights.</span>
					</label>
					<p className="rights-confirm-note">Only upload audio you have the rights to share. Unauthorized or copyright-infringing uploads are prohibited and may be removed. This confirmation does not guarantee uploads are copyright-free or that infringing material can be automatically detected.</p>
				</div>

				{mode !== 'batch' && (
					<form className="source-form" onSubmit={submit}>
						<div className="auth-field">
							<label htmlFor="track-title">Track title</label>
							<input
								id="track-title"
								type="text"
								required
								maxLength={200}
								value={title}
								onChange={e => setTitle(e.target.value)}
								placeholder="e.g. Midnight Groove"
							/>
							{fieldErrors.title && <p className="field-error" role="alert">{fieldErrors.title}</p>}
						</div>

						<div className="auth-field">
							<label htmlFor="track-genre">Genre</label>
							<input
								id="track-genre"
								type="text"
								maxLength={100}
								value={genre}
								onChange={e => setGenre(e.target.value)}
								placeholder="e.g. R&B / Soul"
							/>
						</div>

						<div className="auth-field">
							<label htmlFor="track-credit">Credit</label>
							<input
								id="track-credit"
								type="text"
								maxLength={200}
								value={credit}
								onChange={e => setCredit(e.target.value)}
								placeholder="Artist name"
							/>
						</div>

						{mode === 'file' ? (
							<div className="auth-field">
								<label htmlFor="track-file">Audio file</label>
								<label className="dropzone" htmlFor="track-file">
									<input
										id="track-file"
										type="file"
										accept={AUDIO_ACCEPT}
										className="dropzone-input"
										onChange={e => setFile(e.target.files?.[0] ?? null)}
									/>
									<UploadCloud size={24} />
									<span className="dropzone-title">{file ? file.name : 'Choose an audio file'}</span>
									<span className="dropzone-hint">MP3, WAV, OGG, M4A, FLAC — up to 20 MB</span>
								</label>
								{fieldErrors.file && <p className="field-error" role="alert">{fieldErrors.file}</p>}
								{fieldErrors.audio_file && <p className="field-error" role="alert">{fieldErrors.audio_file}</p>}
							</div>
						) : (
							<div className="auth-field">
								<label htmlFor="track-url">Direct audio link</label>
								<input
									id="track-url"
									type="url"
									value={url}
									onChange={e => setUrl(e.target.value)}
									placeholder="https://example.com/track.mp3"
								/>
								{fieldErrors.url && <p className="field-error" role="alert">{fieldErrors.url}</p>}
								{fieldErrors.audio_url && <p className="field-error" role="alert">{fieldErrors.audio_url}</p>}
								<p className="add-track-hint">
									Use a direct link to an audio file (MP3, WAV, etc.). HLS playlists (.m3u8) and live radio feeds are not supported as catalog tracks — the catalog player plays individual audio files. To set a live station stream, use the stream settings dialog.
								</p>
							</div>
						)}

						{error && <p className="field-error auth-error" role="alert"><AlertCircle size={14} /> {error}</p>}

						<div className="add-track-actions">
							<button type="button" className="button button-ghost" onClick={close} disabled={saving}>Cancel</button>
							<button type="submit" className="button button-cyan" disabled={saving || !rightsConfirmed}>
								{saving ? <><Loader2 size={17} className="spin" /> Adding…</> : <>Add track</>}
							</button>
						</div>
					</form>
				)}

				{mode === 'batch' && (
					<div className="source-form">
						<div className="auth-field">
							<label htmlFor="batch-genre">Genre (applies to all)</label>
							<input
								id="batch-genre"
								type="text"
								maxLength={100}
								value={genre}
								onChange={e => setGenre(e.target.value)}
								placeholder="e.g. R&B / Soul"
							/>
						</div>
						<div className="auth-field">
							<label htmlFor="batch-credit">Credit (applies to all)</label>
							<input
								id="batch-credit"
								type="text"
								maxLength={200}
								value={credit}
								onChange={e => setCredit(e.target.value)}
								placeholder="Artist name"
							/>
						</div>

						<label
							className={`dropzone ${batchDragging ? 'dropzone-active' : ''}`}
							onDragOver={event => { event.preventDefault(); setBatchDragging(true); }}
							onDragLeave={() => setBatchDragging(false)}
							onDrop={event => {
								event.preventDefault();
								setBatchDragging(false);
								addBatchFiles(event.dataTransfer.files);
							}}
						>
							<input
								type="file"
								multiple
								accept={AUDIO_ACCEPT}
								className="dropzone-input"
								onChange={event => { addBatchFiles(event.target.files); event.currentTarget.value = ''; }}
							/>
							<UploadCloud size={26} />
							<span className="dropzone-title">Drag &amp; drop audio files here</span>
							<span className="dropzone-hint">or click to browse — MP3, WAV, OGG, M4A, FLAC up to 20 MB each</span>
						</label>

						{error && <p className="field-error" role="alert">{error}</p>}

						{batch.length > 0 && (
							<ul className="upload-list">
								{batch.map(item => (
									<li key={item.id}>
										<span className="upload-file-icon"><FileAudio size={18} /></span>
										<span className="upload-file-name">
											<input
												type="text"
												value={item.title}
												maxLength={200}
												onChange={e => setBatchTitle(item.id, e.target.value)}
												placeholder={stripExtension(item.file.name)}
												disabled={item.status === 'done' || batchSaving}
												aria-label={`Title for ${item.file.name}`}
												style={{ background: 'none', border: 'none', padding: 0, color: 'inherit', width: '100%' }}
											/>
										</span>
										<span className="upload-file-size">{formatSize(item.file.size)}</span>
										<span className="upload-status">
											{item.status === 'queued' && <span className="upload-status-text">Queued</span>}
											{item.status === 'uploading' && <Loader2 size={15} className="spin" />}
											{item.status === 'done' && <CheckCircle2 size={15} className="upload-status-done" />}
											{item.status === 'error' && <AlertCircle size={15} className="upload-status-error" />}
										</span>
										<button
											type="button"
											className="upload-remove"
											onClick={() => removeBatchItem(item.id)}
											disabled={batchSaving}
											aria-label={`Remove ${item.file.name}`}
										>
											<X size={15} />
										</button>
										{item.status === 'error' && item.error && (
											<span className="upload-file-error" role="alert">{item.error}</span>
										)}
									</li>
								))}
							</ul>
						)}

						{batchAllDone ? (
							<div className="source-note upload-note upload-note-success">
								<CheckCircle2 size={17} />
								<p>{batchDoneCount} track{batchDoneCount > 1 ? 's' : ''} added to your catalog. Each file was stored server-side and added as a track you own.</p>
							</div>
						) : (
							<div className="source-note upload-note">
								<UploadCloud size={17} />
								<p>Each dropped file is uploaded to Trident Radio storage and added to the catalog as a track under your account. Files are sent only when you press upload.</p>
							</div>
						)}

						{batchErrorCount > 0 && !batchAllDone && (
							<p className="field-error" role="alert">{batchErrorCount} file{batchErrorCount > 1 ? 's' : ''} failed. You can retry.</p>
						)}

						<div className="add-track-actions">
							{batchAllDone ? (
								<button type="button" className="button button-cyan" onClick={finishBatch}>
									Done <ArrowUpRight size={17} />
								</button>
							) : (
								<>
									<button type="button" className="button button-ghost" onClick={close} disabled={batchSaving}>Cancel</button>
									<button
										type="button"
										className="button button-cyan"
										onClick={uploadBatch}
										disabled={batchSaving || !batchHasPending || !rightsConfirmed}
									>
										{batchSaving
											? <><Loader2 size={17} className="spin" /> Uploading…</>
											: <>Upload {batch.length > 0 ? `${batch.length} file${batch.length > 1 ? 's' : ''}` : ''} <ArrowUpRight size={17} /></>}
									</button>
								</>
							)}
						</div>
					</div>
				)}
			</DialogContent>
		</Dialog>
	);
}
