import { Disc3, ListMusic, Pause, Play, Pencil, Plus, UserCheck, UserPlus } from 'lucide-react';
import { Link } from 'react-router';
import { ARTIST } from '@/data/artist-catalog';
import { useAuth } from '@/hooks/use-auth';
import { useRadio } from '@/components/radio-provider';
import { useArtist } from './artist-provider';
import { useTrackEngagement } from '@/hooks/use-track-engagement';

/**
 * Artist hero. A welcoming cover banner with the artist's identity, honest
 * draft status, real track counts, and primary actions: Play (queues every
 * playable track into the Trident player), Follow (signed-in listeners), and
 * Edit profile / Add track (the artist themselves). No fabricated followers,
 * verification, or analytics — counts reflect the actual catalog.
 */
export function ArtistHero() {
	const { user, isAuthed, isLoading } = useAuth();
	const radio = useRadio();
	const { tracks, playableTracks, playAll, artistId, loading } = useArtist();
	const { follows, toggleFollow, busy } = useTrackEngagement();

	const isOwnPage = Boolean(isAuthed && artistId && user?.id === artistId);
	const following = artistId ? follows.has(artistId) : false;
	const trackCount = tracks.length;
	const playableCount = playableTracks.length;
	const currentTrack = radio.nowPlaying;
	const isPlayingThisArtist = currentTrack
		? tracks.some((t) => t.id === currentTrack.id) && (radio.state === 'playing' || radio.state === 'connecting')
		: false;

	const handlePlay = () => {
		if (isPlayingThisArtist) {
			radio.toggle();
			return;
		}
		playAll();
	};

	const handleFollow = () => {
		if (artistId) void toggleFollow(artistId);
	};

	return (
		<section id="artist" className="artist-hero-section">
			<div className="artist-cover">
				<div className="artist-cover-glow" aria-hidden="true" />
				<div className="artist-cover-noise" aria-hidden="true" />
				<div className="artist-cover-content">
					<div className="artist-cover-avatar" aria-hidden="true">{ARTIST.initials}</div>
					<div className="artist-cover-identity">
						<div className="artist-cover-type">
							<span className="artist-type-pill"><Disc3 size={12} /> ARTIST PROFILE</span>
						</div>
						<h1>{ARTIST.name}</h1>
						<p className="artist-cover-sub">
							{ARTIST.role} <span className="artist-cover-dot">·</span> {ARTIST.label}
						</p>
						<div className="artist-cover-stats">
							<div className="artist-stat">
								<strong>{loading ? '—' : trackCount}</strong>
								<span>{trackCount === 1 ? 'Track' : 'Tracks'}</span>
							</div>
							<div className="artist-stat">
								<strong>{loading ? '—' : playableCount}</strong>
								<span>Playable</span>
							</div>
							<div className="artist-stat">
								<strong>{ARTIST.label}</strong>
								<span>Label</span>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div className="artist-hero-actions">
				<button
					type="button"
					className={`artist-cta artist-cta-play ${isPlayingThisArtist ? 'is-playing' : ''}`}
					onClick={handlePlay}
					disabled={!loading && playableCount === 0}
					title={playableCount === 0 ? 'No playable tracks yet' : `Play ${playableCount} track${playableCount === 1 ? '' : 's'}`}
				>
					{isPlayingThisArtist ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" />}
					{isPlayingThisArtist ? 'Pause' : 'Play'}
				</button>

				{!isLoading && isOwnPage ? (
					<>
						<Link className="artist-cta artist-cta-ghost" to="/account">
							<Pencil size={16} /> Edit profile
						</Link>
						<a className="artist-cta artist-cta-ghost" href="#catalog">
							<Plus size={16} /> Add track
						</a>
					</>
				) : !isLoading && isAuthed && artistId ? (
					<button
						type="button"
						className={`artist-cta artist-cta-ghost ${following ? 'is-following' : ''}`}
						onClick={handleFollow}
						disabled={busy}
						aria-pressed={following}
					>
						{following ? <UserCheck size={16} /> : <UserPlus size={16} />}
						{following ? 'Following' : 'Follow'}
					</button>
				) : !isLoading && !isAuthed ? (
					<Link className="artist-cta artist-cta-ghost" to="/login">
						<UserPlus size={16} /> Sign in to follow
					</Link>
				) : null}

				{playableCount > 0 && (
					<a className="artist-cta artist-cta-link" href="#catalog">
						<ListMusic size={16} /> View catalog
					</a>
				)}
			</div>

		</section>
	);
}
