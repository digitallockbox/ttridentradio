import { useState } from 'react';
import { Link2, Loader2, Music, Pause, Play, Plus, AlertCircle, RotateCw, ThumbsUp, ThumbsDown, ListPlus, UserCheck, ListMusic } from 'lucide-react';
import { Link } from 'react-router';
import { useAuth } from '@/hooks/use-auth';
import { useRadio } from '@/components/radio-provider';
import { useTrackEngagement } from '@/hooks/use-track-engagement';
import pb from '@/lib/pocketbase-client';
import {
	useArtist,
	type ArtistTrack,
	type RotationStatus,
	isRotationEligible,
	rotationStatus,
	ROTATION_BADGE,
} from './artist-provider';
import { AddTrackDialog } from './add-track-dialog';

function EngagementControls({ track }: { track: ArtistTrack }) {
	const { isAuthed, reactions, playlistIds, follows, busy, toggleReaction, togglePlaylist, toggleFollow } = useTrackEngagement();
	const artistId = track.owner || '';

	if (!isAuthed) {
		return (
			<p className="engagement-signin">
				<Link to="/login">Sign in</Link> to like, follow, and add to your Trident playlist.
			</p>
		);
	}

	const reaction = reactions[track.id];
	const inPlaylist = playlistIds.has(track.id);
	const following = artistId ? follows.has(artistId) : false;

	return (
		<div className="track-engagement">
			<button
				className={`engagement-btn ${following ? 'is-active follow' : ''}`}
				onClick={() => artistId && toggleFollow(artistId)}
				disabled={busy || !artistId}
				aria-pressed={following}
				title={following ? 'Unfollow artist' : 'Follow artist'}
				aria-label={following ? `Unfollow ${track.credit}` : `Follow ${track.credit}`}
			>
				<UserCheck size={15} />
			</button>
			<button
				className={`engagement-btn ${reaction === 'like' ? 'is-active like' : ''}`}
				onClick={() => toggleReaction(track.id, 'like')}
				disabled={busy}
				aria-pressed={reaction === 'like'}
				title="Thumbs up"
				aria-label={`Thumbs up ${track.title}`}
			>
				<ThumbsUp size={15} />
			</button>
			<button
				className={`engagement-btn ${reaction === 'dislike' ? 'is-active dislike' : ''}`}
				onClick={() => toggleReaction(track.id, 'dislike')}
				disabled={busy}
				aria-pressed={reaction === 'dislike'}
				title="Thumbs down"
				aria-label={`Thumbs down ${track.title}`}
			>
				<ThumbsDown size={15} />
			</button>
			<button
				className={`engagement-btn ${inPlaylist ? 'is-active playlist' : ''}`}
				onClick={() => togglePlaylist(track.id)}
				disabled={busy}
				aria-pressed={inPlaylist}
				title={inPlaylist ? 'Remove from playlist' : 'Add to Trident playlist'}
				aria-label={inPlaylist ? `Remove ${track.title} from playlist` : `Add ${track.title} to playlist`}
			>
				<ListPlus size={15} />
			</button>
		</div>
	);
}

function RealTrackCard({
	track,
	isPlaying,
	isCurrent,
	onToggle,
	canManage,
	onToggleRotation,
	rotationBusy,
}: {
	track: ArtistTrack;
	isPlaying: boolean;
	isCurrent: boolean;
	onToggle: () => void;
	canManage: boolean;
	onToggleRotation: (track: ArtistTrack) => void;
	rotationBusy: boolean;
}) {
	const source = track.audio_file ? 'file' : 'link';
	const subtitle = [track.credit, track.genre].filter(Boolean).join(' • ');
	const status = rotationStatus(track);
	const eligible = isRotationEligible(track);
	const badge = ROTATION_BADGE[status];

	return (
		<li className={`track-card track-cyan is-real ${isPlaying ? 'is-playing' : ''}`}>
			<div className="track-card-main">
				<span className="track-icon" aria-hidden="true">
					{source === 'link' ? <Link2 size={18} /> : <Music size={18} />}
				</span>
				<div className="track-meta">
					<h3>{track.title}</h3>
					<p>{subtitle || 'Audio track'}</p>
				</div>
				<span className={`track-source-badge ${source === 'link' ? 'track-source-link' : 'track-source-file'}`}>
					{source === 'link' ? 'LINK' : 'FILE'}
				</span>
			</div>

			<div className="track-actions">
				{canManage && eligible && (
					<button
						className={`rotation-toggle ${status === 'active' ? 'rotation-toggle-active' : ''}`}
						onClick={() => onToggleRotation(track)}
						disabled={rotationBusy}
						title={status === 'active' ? 'Pause rotation' : 'Add to rotation'}
						aria-label={status === 'active' ? `Pause rotation for ${track.title}` : `Add ${track.title} to rotation`}
					>
						{rotationBusy ? <Loader2 size={14} className="spin" /> : <RotateCw size={14} />}
						{status === 'active' ? 'Pause' : 'Rotate'}
					</button>
				)}
				<button
					className="track-play"
					onClick={onToggle}
					aria-label={isPlaying ? `Pause ${track.title}` : `Play ${track.title}`}
				>
					{isPlaying ? <Pause size={15} fill="currentColor" /> : <Play size={15} fill="currentColor" />}
				</button>
			</div>

			{eligible && (
				<span className={`rotation-badge ${badge.className}`} title="Trident Radio rotation status">
					{badge.label}
				</span>
			)}

			{isCurrent && (
				<span className="now-playing-pill" title="Now playing on the Trident player">
					NOW PLAYING
				</span>
			)}

			<div className="track-card-row">
				<EngagementControls track={track} />
			</div>
		</li>
	);
}

/**
 * Artist catalog. Real tracks added through the "Add track" flow are fetched
 * from PocketBase and are playable through the shared Trident player when an
 * audio file or direct audio URL is configured. Per-track controls let signed-in
 * listeners follow the artist, thumbs-up/down, and add to their Trident playlist.
 */
export function ArtistCatalog() {
	const { isAuthed, isLoading } = useAuth();
	const radio = useRadio();
	const { tracks, playableTracks, loading, error, reload, patchTrack, playAll, playTrack } = useArtist();
	const [addOpen, setAddOpen] = useState(false);
	const [rotationBusyId, setRotationBusyId] = useState<string | null>(null);
	const [rotationError, setRotationError] = useState('');

	const toggleRotation = async (track: ArtistTrack) => {
		if (!isAuthed) return;
		if (!isRotationEligible(track)) return;
		const status = rotationStatus(track);
		const next: RotationStatus = status === 'active' ? 'paused' : 'active';
		setRotationError('');
		setRotationBusyId(track.id);
		try {
			await pb.collection('tracks').update<ArtistTrack>(track.id, { rotation: next });
			patchTrack(track.id, { rotation: next });
		} catch {
			setRotationError(`Could not update rotation for “${track.title}”. Please try again.`);
		} finally {
			setRotationBusyId(null);
		}
	};

	const playableCount = playableTracks.length;

	return (
		<section id="catalog" className="artist-catalog-section">
			<div className="section-heading">
				<div>
					<div className="eyebrow">CATALOG</div>
					<h2>Brickyard Beats catalog<span className="text-cyan">.</span></h2>
					<p>Tracks the artist adds are playable through the Trident player when an audio file or direct link is configured. Sign in to follow, like, and build your Trident playlist.</p>
				</div>
				<div className="catalog-heading-actions">
					{!isLoading && isAuthed && (
					<button type="button" className="button button-cyan add-track-button" onClick={() => setAddOpen(true)}>
						<Plus size={16} /> Add track
					</button>
					)}
				</div>
			</div>

			{rotationError && (
				<p className="track-play-error" role="alert"><AlertCircle size={14} /> {rotationError}</p>
			)}

			{loading ? (
				<p className="catalog-loading"><Loader2 size={16} className="spin" /> Loading tracks…</p>
			) : error ? (
				<p className="track-play-error" role="alert"><AlertCircle size={14} /> {error}</p>
			) : tracks.length > 0 ? (
				<>
					{playableCount > 0 && (
						<div className="play-all-bar">
							<button type="button" className="button button-cyan play-all-button" onClick={playAll}>
								<ListMusic size={16} /> Play all {playableCount} track{playableCount > 1 ? 's' : ''}
							</button>
							<span className="play-all-hint">Queues every track with audio into the Trident player rotation queue.</span>
						</div>
					)}
					<ul className="track-list">
						{tracks.map((track) => {
							const current = radio.nowPlaying?.id === track.id;
							return (
								<RealTrackCard
									key={track.id}
									track={track}
									isCurrent={current}
									isPlaying={current && (radio.state === 'playing' || radio.state === 'connecting')}
									onToggle={() => playTrack(track)}
									canManage={isAuthed}
									onToggleRotation={toggleRotation}
									rotationBusy={rotationBusyId === track.id}
								/>
							);
						})}
					</ul>
				</>
			) : (
				<div className="catalog-empty">
					<span className="catalog-empty-icon"><Music size={26} /></span>
					<h3>No tracks yet</h3>
					<p>{isAuthed ? 'Add your first track to start building your catalog. Uploaded audio becomes playable in the Trident player.' : 'This artist hasn’t added any tracks yet. Check back soon.'}</p>
					{isAuthed && (
						<button type="button" className="button button-cyan add-track-button" onClick={() => setAddOpen(true)}>
							<Plus size={16} /> Add your first track
						</button>
					)}
				</div>
			)}

			{tracks.length > 0 && (
				<div className="stream-notice">
					<RotateCw size={16} />
					<p>Tracks with audio enter the Trident Radio rotation catalog as pending. Activate a track here to add it to spin rotation — it then appears in the station rotation catalog. Only the track owner can change rotation status.</p>
				</div>
			)}

			<AddTrackDialog open={addOpen} onClose={() => setAddOpen(false)} onAdded={reload} />
		</section>
	);
}
