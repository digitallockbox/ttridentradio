import { useEffect, useState } from 'react';
import { AlertCircle, Calendar, Link2, Loader2, Mic, Pause, Play, Plus, ListMusic, Headphones } from 'lucide-react';
import { Link } from 'react-router';
import pb from '@/lib/pocketbase-client';
import { useAuth } from '@/hooks/use-auth';
import { useRadio, type NowPlayingTrack } from '@/components/radio-provider';
import { AddEpisodeDialog } from './add-episode-dialog';
import { formatDate } from '@/lib/intl-format';

export type PodcastEpisode = {
	id: string;
	collectionId: string;
	collectionName: string;
	title: string;
	description?: string;
	credit?: string;
	audio_file?: string;
	audio_url?: string;
	published?: boolean;
	owner?: string;
	created?: string;
};

function episodeUrl(episode: PodcastEpisode): string {
	if (episode.audio_file) return pb.files.getURL(episode, episode.audio_file);
	return episode.audio_url || '';
}

function toNowPlaying(episode: PodcastEpisode): NowPlayingTrack | null {
	const url = episodeUrl(episode);
	if (!url) return null;
	return {
		id: episode.id,
		title: episode.title,
		artist: episode.credit || 'Trident Radio Podcast',
		url,
	};
}

/**
 * Public podcast episode list. Fetches published episodes from PocketBase and
 * plays them through the shared Trident player when an audio file or direct
 * link is attached. Shows an honest empty state when no episodes are published
 * yet — no fabricated episodes, metrics, or external service connections.
 */
export function EpisodeList() {
	const { isAuthed, isLoading } = useAuth();
	const radio = useRadio();
	const [episodes, setEpisodes] = useState<PodcastEpisode[]>([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState('');
	const [addOpen, setAddOpen] = useState(false);

	const reload = async () => {
		setLoading(true);
		setError('');
		try {
			const list = await pb
				.collection('podcast_episodes')
				.getFullList<PodcastEpisode>({ filter: 'published = true', sort: '-created', requestKey: null });
			setEpisodes(list);
		} catch {
			setError('Could not load podcast episodes. Please try again later.');
		} finally {
			setLoading(false);
		}
	};

	useEffect(() => {
		void reload();
	}, []);

	const playAll = () => {
		const queue = episodes
			.map(toNowPlaying)
			.filter((t): t is NowPlayingTrack => Boolean(t));
		if (queue.length > 0) radio.playQueue(queue, 0);
	};

	const toggle = (episode: PodcastEpisode) => {
		const np = toNowPlaying(episode);
		if (!np) return;
		if (radio.nowPlaying?.id === episode.id) {
			radio.toggle();
			return;
		}
		radio.playTrack(np);
	};

	const playableCount = episodes.filter(e => episodeUrl(e)).length;

	return (
		<section id="episodes" className="podcast-episodes-section">
			<div className="section-heading">
				<div>
					<div className="eyebrow">EPISODES</div>
					<h2>Published episodes<span className="text-cyan">.</span></h2>
					<p>Every published episode with attached audio is playable through the Trident player. No episodes are fabricated or imported from an external podcast platform.</p>
				</div>
				{!isLoading && isAuthed && (
					<button type="button" className="button button-cyan add-track-button" onClick={() => setAddOpen(true)}>
						<Plus size={16} /> Publish episode
					</button>
				)}
			</div>

			{loading ? (
				<p className="catalog-loading"><Loader2 size={16} className="spin" /> Loading episodes…</p>
			) : error ? (
				<p className="track-play-error" role="alert"><AlertCircle size={14} /> {error}</p>
			) : episodes.length > 0 ? (
				<>
					{playableCount > 0 && (
						<div className="play-all-bar">
							<button type="button" className="button button-cyan play-all-button" onClick={playAll}>
								<ListMusic size={16} /> Play all {playableCount} episode{playableCount > 1 ? 's' : ''}
							</button>
							<span className="play-all-hint">Queues every episode with audio into the Trident player.</span>
						</div>
					)}
					<ul className="episode-list">
						{episodes.map((episode) => {
							const url = episodeUrl(episode);
							const source = episode.audio_file ? 'file' : 'link';
							const current = radio.nowPlaying?.id === episode.id;
							const playing = current && (radio.state === 'playing' || radio.state === 'connecting');
							return (
								<li key={episode.id} className={`episode-card ${playing ? 'is-playing' : ''} ${url ? 'is-real' : ''}`}>
									<div className="episode-card-main">
										<span className="episode-number" aria-hidden="true"><Mic size={18} /></span>
										<div className="episode-meta">
											<h3>{episode.title}</h3>
											<p className="episode-desc">{episode.description || 'No description provided.'}</p>
											<div className="episode-sub">
												{episode.credit && <span>{episode.credit}</span>}
												{episode.created && (
													<span className="episode-date"><Calendar size={12} /> {formatDate(episode.created, { locale: 'en-US' })}</span>
												)}
												<span className={`track-source-badge ${source === 'link' ? 'track-source-link' : 'track-source-file'}`}>
													{source === 'link' ? <><Link2 size={10} /> LINK</> : 'FILE'}
												</span>
											</div>
										</div>
									</div>
									<div className="episode-actions">
										{url ? (
											<button
												className="track-play"
												onClick={() => toggle(episode)}
												aria-label={playing ? `Pause ${episode.title}` : `Play ${episode.title}`}
											>
												{playing ? <Pause size={15} fill="currentColor" /> : <Play size={15} fill="currentColor" />}
											</button>
										) : (
											<span className="episode-no-audio" title="No audio attached">No audio</span>
										)}
										{current && (
											<span className="now-playing-pill" title="Now playing on the Trident player">NOW PLAYING</span>
										)}
									</div>
								</li>
							);
						})}
					</ul>
				</>
			) : (
				<div className="catalog-empty">
					<span className="catalog-empty-icon"><Headphones size={26} /></span>
					<h3>No episodes published yet</h3>
					<p>
						{isAuthed
							? 'Publish your first episode to launch the Trident Radio podcast. Uploaded audio becomes playable right here through the Trident player.'
							: 'There are no published podcast episodes yet. Check back soon, or sign in as an artist to publish one.'}
					</p>
					{!isLoading && isAuthed && (
						<button type="button" className="button button-cyan add-track-button" onClick={() => setAddOpen(true)}>
							<Plus size={16} /> Publish your first episode
						</button>
					)}
					{!isLoading && !isAuthed && (
						<Link className="button button-ghost add-track-button" to="/login">Sign in to publish</Link>
					)}
				</div>
			)}

			<AddEpisodeDialog open={addOpen} onClose={() => setAddOpen(false)} onAdded={reload} />
		</section>
	);
}
