import { useState, type FormEvent } from 'react';
import {
	AlertCircle,
	ArrowUpRight,
	Loader2,
	Link2,
	Mic,
	UploadCloud,
} from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbase-client';

type AddMode = 'file' | 'url';

const AUDIO_ACCEPT =
	'.mp3,.wav,.ogg,.m4a,.flac,.aac,.weba,.webm,audio/mpeg,audio/mp3,audio/wav,audio/ogg,audio/aac,audio/flac,audio/x-m4a,audio/m4a,audio/webm,audio/mp4';

function looksLikeHls(url: string): boolean {
	try {
		const parsed = new URL(url);
		return parsed.pathname.toLowerCase().includes('.m3u8');
	} catch {
		return false;
	}
}

/**
 * Dialog for signed-in artists to publish a podcast episode through a direct
 * audio file upload or a direct audio URL. Episodes are created through the
 * browser SDK under the signed-in user, so PocketBase access rules enforce
 * ownership. HLS/live stream URLs are rejected with an honest explanation.
 */
export function AddEpisodeDialog({
	open,
	onClose,
	onAdded,
}: {
	open: boolean;
	onClose: () => void;
	onAdded: () => void;
}) {
	const { user } = useAuth();
	const [mode, setMode] = useState<AddMode>('file');
	const [title, setTitle] = useState('');
	const [description, setDescription] = useState('');
	const [credit, setCredit] = useState(user?.name ?? '');
	const [file, setFile] = useState<File | null>(null);
	const [url, setUrl] = useState('');
	const [published, setPublished] = useState(false);
	const [error, setError] = useState('');
	const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
	const [saving, setSaving] = useState(false);
	const [rightsConfirmed, setRightsConfirmed] = useState(false);

	const reset = () => {
		setMode('file');
		setTitle('');
		setDescription('');
		setCredit(user?.name ?? '');
		setFile(null);
		setUrl('');
		setPublished(false);
		setError('');
		setFieldErrors({});
		setRightsConfirmed(false);
	};

	const close = () => {
		reset();
		onClose();
	};

	const validateUrl = (value: string): string | null => {
		const trimmed = value.trim();
		if (!trimmed) return 'Paste a direct audio link.';
		try {
			const parsed = new URL(trimmed);
			if (!['http:', 'https:'].includes(parsed.protocol)) {
				return 'The link must start with http:// or https://.';
			}
		} catch {
			return 'That does not look like a valid URL.';
		}
		if (looksLikeHls(trimmed)) {
			return 'HLS live streams (.m3u8) are not supported as podcast episodes. Use a direct audio file link instead.';
		}
		return null;
	};

	const submit = async (event: FormEvent) => {
		event.preventDefault();
		if (!user) {
			setError('Sign in to publish an episode.');
			return;
		}
		const errors: Record<string, string> = {};
		if (!title.trim()) errors.title = 'Title is required.';
		if (mode === 'file' && !file) errors.file = 'Choose an audio file to upload.';
		if (mode === 'url') {
			const urlError = validateUrl(url);
			if (urlError) errors.url = urlError;
		}
		setFieldErrors(errors);
		if (Object.keys(errors).length > 0) return;

		setSaving(true);
		setError('');
		try {
			if (mode === 'file') {
				const formData = new FormData();
				formData.append('title', title.trim());
				formData.append('description', description.trim());
				formData.append('credit', credit.trim() || user.name || '');
				formData.append('owner', user.id);
				formData.append('published', String(published));
				formData.append('audio_file', file as File, (file as File).name);
				await pb.collection('podcast_episodes').create(formData);
			} else {
				await pb.collection('podcast_episodes').create({
					title: title.trim(),
					description: description.trim(),
					credit: credit.trim() || user.name || '',
					audio_url: url.trim(),
					published,
					owner: user.id,
				});
			}
			reset();
			onAdded();
			onClose();
		} catch (err) {
			const response = (err as { response?: { data?: Record<string, { message?: string }> } }).response;
			if (response?.data) {
				const mapped: Record<string, string> = {};
				for (const [field, detail] of Object.entries(response.data)) {
					if (detail?.message) mapped[field] = detail.message;
				}
				if (Object.keys(mapped).length > 0) {
					setFieldErrors(prev => ({ ...prev, ...mapped }));
					setSaving(false);
					return;
				}
			}
			setError('Could not publish the episode. Please check the details and try again.');
		} finally {
			setSaving(false);
		}
	};

	return (
		<Dialog open={open} onOpenChange={open => { if (!open) close(); }}>
			<DialogContent className="radio-dialog upload-dialog">
				<span className="dialog-icon"><Mic size={25} /></span>
				<DialogTitle className="dialog-title">Publish an episode.</DialogTitle>
				<DialogDescription>
					Upload an audio file or paste a direct audio link to publish a podcast episode. Episodes with audio
					are playable through the Trident player. Leave “Publish now” off to save a draft only you can see.
				</DialogDescription>

				<div className="track-mode-toggle" role="tablist" aria-label="Add episode by">
					<button
						type="button"
						role="tab"
						aria-selected={mode === 'file'}
						className={`track-mode-btn ${mode === 'file' ? 'active' : ''}`}
						onClick={() => setMode('file')}
					>
						<UploadCloud size={15} /> File upload
					</button>
					<button
						type="button"
						role="tab"
						aria-selected={mode === 'url'}
						className={`track-mode-btn ${mode === 'url' ? 'active' : ''}`}
						onClick={() => setMode('url')}
					>
						<Link2 size={15} /> Stream URL
					</button>
				</div>

				<div className="rights-confirm">
					<label className="rights-confirm-label">
						<input
							type="checkbox"
							checked={rightsConfirmed}
							onChange={(e) => setRightsConfirmed(e.target.checked)}
						/>
						<span>I own or am authorized to distribute this audio, and it does not infringe any third party’s rights.</span>
					</label>
					<p className="rights-confirm-note">Only upload audio you have the rights to share. Unauthorized or copyright-infringing uploads are prohibited and may be removed.</p>
				</div>

				<form className="source-form" onSubmit={submit}>
					<div className="auth-field">
						<label htmlFor="episode-title">Episode title</label>
						<input
							id="episode-title"
							type="text"
							required
							maxLength={200}
							value={title}
							onChange={e => setTitle(e.target.value)}
							placeholder="e.g. Behind the Mix — Episode 1"
						/>
						{fieldErrors.title && <p className="field-error" role="alert">{fieldErrors.title}</p>}
					</div>

					<div className="auth-field">
						<label htmlFor="episode-credit">Host / credit</label>
						<input
							id="episode-credit"
							type="text"
							maxLength={200}
							value={credit}
							onChange={e => setCredit(e.target.value)}
							placeholder="Host name"
						/>
					</div>

					<div className="auth-field">
						<label htmlFor="episode-description">Description</label>
						<textarea
							id="episode-description"
							rows={4}
							maxLength={2000}
							value={description}
							onChange={e => setDescription(e.target.value)}
							placeholder="What is this episode about?"
						/>
					</div>

					{mode === 'file' ? (
						<div className="auth-field">
							<label htmlFor="episode-file">Audio file</label>
							<label className="dropzone" htmlFor="episode-file">
								<input
									id="episode-file"
									type="file"
									accept={AUDIO_ACCEPT}
									className="dropzone-input"
									onChange={e => setFile(e.target.files?.[0] ?? null)}
								/>
								<UploadCloud size={24} />
								<span className="dropzone-title">{file ? file.name : 'Choose an audio file'}</span>
								<span className="dropzone-hint">MP3, WAV, OGG, M4A, FLAC — up to 20 MB</span>
							</label>
							{fieldErrors.file && <p className="field-error" role="alert">{fieldErrors.file}</p>}
							{fieldErrors.audio_file && <p className="field-error" role="alert">{fieldErrors.audio_file}</p>}
						</div>
					) : (
						<div className="auth-field">
							<label htmlFor="episode-url">Direct audio link</label>
							<input
								id="episode-url"
								type="url"
								value={url}
								onChange={e => setUrl(e.target.value)}
								placeholder="https://example.com/episode.mp3"
							/>
							{fieldErrors.url && <p className="field-error" role="alert">{fieldErrors.url}</p>}
							{fieldErrors.audio_url && <p className="field-error" role="alert">{fieldErrors.audio_url}</p>}
							<p className="add-track-hint">
								Use a direct link to an audio file (MP3, WAV, etc.). HLS playlists (.m3u8) and live radio feeds are not supported as episodes.
							</p>
						</div>
					)}

					<label className="episode-publish-toggle">
						<input
							type="checkbox"
							checked={published}
							onChange={e => setPublished(e.target.checked)}
						/>
						<span>
							<strong>Publish now</strong>
							<small>Published episodes are listenable by everyone. Leave off to save a private draft.</small>
						</span>
					</label>

					{error && <p className="field-error auth-error" role="alert"><AlertCircle size={14} /> {error}</p>}

					<div className="add-track-actions">
						<button type="button" className="button button-ghost" onClick={close} disabled={saving}>Cancel</button>
						<button type="submit" className="button button-cyan" disabled={saving || !rightsConfirmed}>
							{saving ? <><Loader2 size={17} className="spin" /> Publishing…</> : <>Publish episode <ArrowUpRight size={17} /></>}
						</button>
					</div>
				</form>
			</DialogContent>
		</Dialog>
	);
}


