import { Mic, Radio } from 'lucide-react';
import { RADIO_ART } from '@/constants/radio';

/**
 * Podcast page hero. Introduces the Trident Radio podcast as a real,
 * audio-backed experience — no fabricated episodes or external service
 * connections are implied.
 */
export function PodcastHero() {
	return (
		<section className="podcast-hero">
			<div className="podcast-hero-art" aria-hidden="true">
				<img src={RADIO_ART} alt="" />
				<span className="podcast-hero-badge"><Mic size={14} /> PODCAST</span>
			</div>
			<div className="podcast-hero-copy">
				<div className="eyebrow"><span className="tiny-line" /> TRIDENT RADIO PODCAST</div>
				<h1>Conversations, sessions &amp; stories<span className="text-cyan">.</span></h1>
				<p>
					The Trident Radio podcast brings creator conversations, station sessions, and behind-the-scenes
					stories into one place. Published episodes play right here through the Trident player when an audio
					file or direct link is attached — no external podcast platform connection is required or implied.
				</p>
				<div className="podcast-hero-meta">
					<span><Radio size={14} /> Plays in the Trident player</span>
					<span>Published episodes only</span>
				</div>
			</div>
		</section>
	);
}
