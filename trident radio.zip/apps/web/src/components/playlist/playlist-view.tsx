import { useCallback, useEffect, useState } from 'react';
import { AlertCircle, ListMusic, Loader2, Music, Pause, Play, Trash2 } from 'lucide-react';
import { Link } from 'react-router';
import pb from '@/lib/pocketbase-client';
import { useAuth } from '@/hooks/use-auth';
import { useRadio, type NowPlayingTrack } from '@/components/radio-provider';

type ExpandedTrack = {
	id: string;
	collectionId: string;
	title: string;
	credit?: string;
	genre?: string;
	audio_file?: string;
	audio_url?: string;
	owner?: string;
};

type PlaylistItem = {
	id: string;
	created: string;
	expand?: { track?: ExpandedTrack };
};

function trackUrl(track: ExpandedTrack): string {
	if (track.audio_file) return pb.files.getURL(track, track.audio_file);
	return track.audio_url || '';
}

function toNowPlaying(track: ExpandedTrack): NowPlayingTrack | null {
	const url = trackUrl(track);
	if (!url) return null;
	return {
		id: track.id,
		title: track.title,
		artist: track.credit || 'Unknown artist',
		url,
	};
}

/**
 * The signed-in listener's personal Trident playlist. Tracks are curated from
 * any artist's catalog or the station rotation — listeners only add/remove
 * their own playlist entries; the original track and audio stay owned and
 * editable by the artist. Playback goes through the shared Trident player so
 * the now-playing track and artist surface everywhere. Signed-out visitors
 * see a clear sign-in prompt.
 */
export function PlaylistView() {
	const { isAuthed, isLoading } = useAuth();
	const radio = useRadio();
	const [items, setItems] = useState<PlaylistItem[]>([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState('');
	const [busyId, setBusyId] = useState<string | null>(null);

	const load = useCallback(async () => {
		setLoading(true);
		setError('');
		try {
			const list = await pb.collection('playlist_items').getFullList<PlaylistItem>({
				sort: '-created',
				expand: 'track',
				requestKey: null,
			});
			setItems(list);
		} catch {
			setError('Could not load your playlist. Please try again later.');
		} finally {
			setLoading(false);
		}
	}, []);

	useEffect(() => {
		if (!isAuthed) {
			setItems([]);
			setLoading(false);
			return;
		}
		void load();
	}, [isAuthed, load]);

	const tracks = items
		.map((item) => {
			const track = item.expand?.track;
			if (!track) return null;
			return { item, track };
		})
		.filter((x): x is { item: PlaylistItem; track: ExpandedTrack } => Boolean(x));

	const playableTracks = tracks
		.map((t) => toNowPlaying(t.track))
		.filter((t): t is NowPlayingTrack => Boolean(t));

	const playAll = () => {
		if (playableTracks.length > 0) radio.playQueue(playableTracks, 0);
	};

	const toggle = (track: ExpandedTrack) => {
		const np = toNowPlaying(track);
		if (!np) return;
		if (radio.nowPlaying?.id === track.id) {
			radio.toggle();
			return;
		}
		radio.playTrack(np);
	};

	const remove = async (itemId: string, trackTitle: string) => {
		setBusyId(itemId);
		try {
			await pb.collection('playlist_items').delete(itemId);
			setItems((prev) => prev.filter((i) => i.id !== itemId));
		} catch {
			setError(`Could not remove “${trackTitle}” from your playlist. Please try again.`);
		} finally {
			setBusyId(null);
		}
	};

	if (isLoading) {
		return <p className="catalog-loading"><Loader2 size={16} className="spin" /> Loading your playlist…</p>;
	}

	if (!isAuthed) {
		return (
			<div className="catalog-empty">
				<span className="catalog-empty-icon"><ListMusic size={26} /></span>
				<h3>Sign in to build your playlist</h3>
				<p>Your Trident playlist lets you curate playable tracks from any artist on Trident Radio. Sign in to start adding tracks from artist catalogs and the rotation.</p>
				<Link to="/login" className="button button-cyan add-track-button">Sign in</Link>
			</div>
		);
	}

	return (
		<section id="playlist" className="artist-catalog-section">
			<div className="section-heading">
				<div>
					<div className="eyebrow"><span className="tiny-line" /> MY PLAYLIST</div>
					<h2>Your curated tracks<span className="text-cyan">.</span></h2>
					<p>Tracks you’ve added from any artist on Trident Radio. Play the whole list or any single track through the Trident player. You curate the playlist — only the artist can edit or remove the original track and audio.</p>
				</div>
			</div>

			{error && <p className="track-play-error" role="alert"><AlertCircle size={14} /> {error}</p>}

			{loading ? (
				<p className="catalog-loading"><Loader2 size={16} className="spin" /> Loading your playlist…</p>
			) : tracks.length > 0 ? (
				<>
					<div className="play-all-bar">
						<button type="button" className="button button-cyan play-all-button" onClick={playAll} disabled={playableTracks.length === 0}>
							<ListMusic size={16} /> Play all {playableTracks.length} track{playableTracks.length === 1 ? '' : 's'}
						</button>
						<span className="play-all-hint">Queues every playable track in your playlist into the Trident player.</span>
					</div>
					<ul className="track-list">
						{tracks.map(({ item, track }) => {
							const isPlayable = Boolean(trackUrl(track));
							const current = radio.nowPlaying?.id === track.id;
							const playing = current && (radio.state === 'playing' || radio.state === 'connecting');
							const subtitle = [track.credit, track.genre].filter(Boolean).join(' • ');
							return (
								<li key={item.id} className={`track-card track-cyan is-real ${playing ? 'is-playing' : ''}`}>
									<div className="track-card-main">
										<span className="track-icon" aria-hidden="true"><Music size={18} /></span>
										<div className="track-meta">
											<h3>{track.title}</h3>
											<p>{subtitle || 'Audio track'}</p>
										</div>
									</div>
									<div className="playlist-track-actions">
										<button
											className="track-play"
											onClick={() => toggle(track)}
											disabled={!isPlayable}
											aria-label={playing ? `Pause ${track.title}` : `Play ${track.title}`}
										>
											{playing ? <Pause size={15} fill="currentColor" /> : <Play size={15} fill="currentColor" />}
										</button>
										<button
											className="track-remove"
											onClick={() => remove(item.id, track.title)}
											disabled={busyId === item.id}
											aria-label={`Remove ${track.title} from playlist`}
											title="Remove from playlist"
										>
											{busyId === item.id ? <Loader2 size={15} className="spin" /> : <Trash2 size={15} />}
										</button>
									</div>
									{current && <span className="now-playing-pill" title="Now playing on the Trident player">NOW PLAYING</span>}
								</li>
							);
						})}
					</ul>
				</>
			) : (
				<div className="catalog-empty">
					<span className="catalog-empty-icon"><ListMusic size={26} /></span>
					<h3>Your playlist is empty</h3>
					<p>Add tracks from any artist catalog or the Trident Radio rotation to start building your playlist.</p>
					<Link to="/station#rotation" className="button button-cyan add-track-button">Browse rotation</Link>
				</div>
			)}
		</section>
	);
}
