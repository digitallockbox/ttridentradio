import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { ArrowUpRight, CheckCircle2, FileAudio, FileVideo, FileImage, Loader2, Upload, UploadCloud, X, AlertCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';

type UploadStatus = 'queued' | 'uploading' | 'done' | 'error';

type QueuedFile = {
	id: string;
	name: string;
	size: number;
	type: string;
	status: UploadStatus;
	raw: File;
	url?: string;
	error?: string;
};

const MAX_BYTES = 20 * 1024 * 1024; // 20 MB per file — matches the server body cap

function formatSize(bytes: number) {
	if (bytes < 1024) return `${bytes} B`;
	if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
	return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function fileIcon(type: string) {
	if (type.startsWith('audio/')) return <FileAudio size={18} />;
	if (type.startsWith('video/')) return <FileVideo size={18} />;
	if (type.startsWith('image/')) return <FileImage size={18} />;
	return <Upload size={18} />;
}

type UploadContextValue = { open: () => void };

const UploadContext = createContext<UploadContextValue | null>(null);

export function UploadProvider({ children }: { children: ReactNode }) {
	const [isOpen, setIsOpen] = useState(false);
	const open = useCallback(() => setIsOpen(true), []);
	const value = useMemo(() => ({ open }), [open]);
	return (
		<UploadContext.Provider value={value}>
			{children}
			<UploadDialog isOpen={isOpen} onClose={() => setIsOpen(false)} />
		</UploadContext.Provider>
	);
}

export function useUpload() {
	const context = useContext(UploadContext);
	if (!context) throw new Error('useUpload must be used inside UploadProvider.');
	return context;
}

function UploadDialog({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
	const [files, setFiles] = useState<QueuedFile[]>([]);
	const [error, setError] = useState('');
	const [dragging, setDragging] = useState(false);
	const [isUploading, setIsUploading] = useState(false);

	const addFiles = (list: FileList | null) => {
		if (!list || list.length === 0) return;
		setError('');
		const incoming = Array.from(list);
		const tooLarge = incoming.find(file => file.size > MAX_BYTES);
		if (tooLarge) {
			setError(`"${tooLarge.name}" is larger than 20 MB. Choose a smaller file.`);
			return;
		}
		setFiles(current => [
			...current,
			...incoming.map(file => ({
				id: `${file.name}-${file.size}-${Math.random().toString(36).slice(2, 8)}`,
				name: file.name,
				size: file.size,
				type: file.type || 'application/octet-stream',
				status: 'queued' as UploadStatus,
				raw: file,
			})),
		]);
	};

	const removeFile = (id: string) => setFiles(current => current.filter(file => file.id !== id));

	const reset = () => {
		setFiles([]);
		setError('');
		setIsUploading(false);
		onClose();
	};

	const uploadOne = async (queued: QueuedFile): Promise<void> => {
		const body = new FormData();
		body.append('file', queued.raw, queued.raw.name);

		setFiles(current => current.map(f => (f.id === queued.id ? { ...f, status: 'uploading' } : f)));

		try {
			const response = await fetch('/api/v1/upload', { method: 'POST', body });
			const payload = await response.json().catch(() => null);

			if (!response.ok || !payload?.success) {
				const message = payload?.error || `Upload failed (${response.status}).`;
				setFiles(current => current.map(f => (f.id === queued.id ? { ...f, status: 'error', error: message } : f)));
				return;
			}

			setFiles(current => current.map(f => (f.id === queued.id ? { ...f, status: 'done', url: payload.url } : f)));
		} catch {
			setFiles(current => current.map(f => (f.id === queued.id ? { ...f, status: 'error', error: 'Network error — please try again.' } : f)));
		}
	};

	const uploadAll = async () => {
		const pending = files.filter(f => f.status === 'queued' || f.status === 'error');
		if (pending.length === 0) return;
		setIsUploading(true);
		setError('');
		await Promise.all(pending.map(uploadOne));
		setIsUploading(false);
	};

	const doneCount = files.filter(f => f.status === 'done').length;
	const errorCount = files.filter(f => f.status === 'error').length;
	const allDone = files.length > 0 && doneCount === files.length;
	const hasUploadable = files.some(f => f.status === 'queued' || f.status === 'error');

	return (
		<Dialog open={isOpen} onOpenChange={open => { if (!open) reset(); }}>
			<DialogContent className="radio-dialog upload-dialog">
				<span className="dialog-icon"><UploadCloud size={25} /></span>
				<DialogTitle className="dialog-title">Upload your content.</DialogTitle>
				<DialogDescription>Add audio, video, or image files from your device.</DialogDescription>

				<label
					className={`dropzone ${dragging ? 'dropzone-active' : ''}`}
					onDragOver={event => { event.preventDefault(); setDragging(true); }}
					onDragLeave={() => setDragging(false)}
					onDrop={event => { event.preventDefault(); setDragging(false); addFiles(event.dataTransfer.files); }}
				>
					<input
						type="file"
						multiple
						accept="audio/*,video/*,image/*"
						className="dropzone-input"
						onChange={event => { addFiles(event.target.files); event.currentTarget.value = ''; }}
					/>
					<UploadCloud size={26} />
					<span className="dropzone-title">Drag &amp; drop files here</span>
					<span className="dropzone-hint">or click to browse — audio, video, images up to 20 MB</span>
				</label>

				{error && <p className="field-error" role="alert">{error}</p>}

				{files.length > 0 && (
					<ul className="upload-list">
						{files.map(file => (
							<li key={file.id}>
								<span className="upload-file-icon">{fileIcon(file.type)}</span>
								<span className="upload-file-name">{file.name}</span>
								<span className="upload-file-size">{formatSize(file.size)}</span>
								<span className="upload-status">
									{file.status === 'queued' && <span className="upload-status-text">Queued</span>}
									{file.status === 'uploading' && <Loader2 size={15} className="spin" />}
									{file.status === 'done' && <CheckCircle2 size={15} className="upload-status-done" />}
									{file.status === 'error' && <AlertCircle size={15} className="upload-status-error" />}
								</span>
								<button
									type="button"
									className="upload-remove"
									onClick={() => removeFile(file.id)}
									disabled={isUploading}
									aria-label={`Remove ${file.name}`}
								>
									<X size={15} />
								</button>
								{file.status === 'done' && file.url && (
									<a className="upload-file-url" href={file.url} target="_blank" rel="noreferrer">
										Stored — view file <ArrowUpRight size={12} />
									</a>
								)}
								{file.status === 'error' && file.error && (
									<span className="upload-file-error" role="alert">{file.error}</span>
								)}
							</li>
						))}
					</ul>
				)}

				{allDone ? (
					<div className="source-note upload-note upload-note-success">
						<CheckCircle2 size={17} />
						<p>{doneCount} file{doneCount > 1 ? 's' : ''} uploaded to your Trident Radio storage. Each file is kept server-side under <code>/uploads</code> until it is added to a stream or catalog.</p>
					</div>
				) : (
					<div className="source-note upload-note">
						<Upload size={17} />
						<p>Files are sent to the Trident Radio server and stored in the project's file storage. Nothing leaves your device until you press upload.</p>
					</div>
				)}

				{errorCount > 0 && !allDone && (
					<p className="field-error" role="alert">{errorCount} file{errorCount > 1 ? 's' : ''} failed to upload. You can retry.</p>
				)}

				<div className="upload-actions">
					<button type="button" className="button button-ghost" onClick={reset} disabled={isUploading}>Cancel</button>
					<button
						type="button"
						className="button button-cyan"
						onClick={uploadAll}
						disabled={isUploading || !hasUploadable}
					>
						{isUploading
							? <><Loader2 size={17} className="spin" /> Uploading…</>
							: <>Upload {files.length > 0 ? `${files.length} file${files.length > 1 ? 's' : ''}` : ''} <ArrowUpRight size={17} /></>}
					</button>
				</div>
			</DialogContent>
		</Dialog>
	);
}

