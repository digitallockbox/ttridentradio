import { useEffect, useState } from 'react';
import { Link } from 'react-router';
import {
	AlertCircle,
	BadgeCheck,
	Loader2,
	LogOut,
	Save,
	Shield,
	Upload,
	Users,
} from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import pb from '@/lib/pocketbase-client';

type ArtistUser = {
	id: string;
	name: string;
	email: string;
	bio?: string;
	role?: string;
	verified?: boolean;
	avatar?: string;
	created?: string;
};

function avatarUrl(rec: { id: string; avatar?: string }) {
	if (!rec.avatar) return '';
	return pb.files.getURL({ id: rec.id, collectionId: 'users', collectionName: 'users' } as never, rec.avatar);
}

export function AccountPanel() {
	const { user, logout } = useAuth();
	const profile = (user ?? null) as unknown as ArtistUser | null;
	const [name, setName] = useState(profile?.name ?? '');
	const [bio, setBio] = useState(profile?.bio ?? '');
	const [avatar, setAvatar] = useState<File | null>(null);
	const [saving, setSaving] = useState(false);
	const [saved, setSaved] = useState(false);
	const [error, setError] = useState('');

	const isAdmin = profile?.role === 'admin';

	const saveProfile = async (event: React.FormEvent) => {
		event.preventDefault();
		if (!user) return;
		setError('');
		setSaved(false);
		setSaving(true);
		try {
			const data: Record<string, unknown> = { name, bio };
			if (avatar) data.avatar = avatar;
			await pb.collection('users').update(user.id, data);
			setSaved(true);
			setAvatar(null);
		} catch {
			setError('Could not save your profile. Please try again.');
		} finally {
			setSaving(false);
		}
	};

	return (
		<section className="account-section">
			<div className="section-heading">
				<div>
					<div className="eyebrow">YOUR ACCOUNT</div>
					<h2>Artist profile<span className="text-cyan">.</span></h2>
					<p>Edit how you appear across Trident Radio and the CreatorOS Hub.</p>
				</div>
				{isAdmin && <span className="outline-label admin-badge"><Shield size={13} /> ADMIN</span>}
			</div>

			<form className="artist-panel account-panel" onSubmit={saveProfile}>
				<div className="artist-panel-top">
					<span className="station-category"><i className="status-dot" /> {isAdmin ? 'OWNER / ADMIN' : 'ARTIST'}</span>
					<span className="signal-label">{user?.email}</span>
				</div>

				<div className="account-body">
					<div className="account-avatar-block">
						<div className="artist-avatar account-avatar" aria-hidden="true">
							{profile?.avatar
								? <img src={avatarUrl(profile)} alt="" />
								: (name || profile?.email || 'A').charAt(0).toUpperCase()}
						</div>
						<label className="account-avatar-upload">
							<Upload size={15} /> Change avatar
							<input
								type="file"
								accept="image/jpeg,image/png,image/webp,image/gif,image/svg+xml"
								onChange={e => setAvatar(e.target.files?.[0] ?? null)}
							/>
						</label>
						{avatar && <span className="account-avatar-pending">{avatar.name}</span>}
					</div>

					<div className="account-fields">
						<div className="auth-field">
							<label htmlFor="account-name">Display name</label>
							<input
								id="account-name"
								type="text"
								required
								value={name}
								onChange={e => setName(e.target.value)}
							/>
						</div>
						<div className="auth-field">
							<label htmlFor="account-bio">Bio</label>
							<textarea
								id="account-bio"
								rows={4}
								maxLength={1000}
								value={bio}
								onChange={e => setBio(e.target.value)}
								placeholder="Tell listeners who you are."
							/>
						</div>
						<div className="account-meta">
							<span><BadgeCheck size={14} /> {profile?.verified ? 'Email verified' : 'Email not verified yet'}</span>
						</div>

						{error && <p className="field-error auth-error" role="alert"><AlertCircle size={14} /> {error}</p>}
						{saved && <p className="auth-help-sent">Profile saved.</p>}

						<div className="account-actions">
							<button type="submit" className="button button-cyan" disabled={saving}>
								{saving ? <><Loader2 size={17} className="spin" /> Saving…</> : <><Save size={17} /> Save profile</>}
							</button>
							<button type="button" className="button button-ghost" onClick={logout}>
								<LogOut size={16} /> Sign out
							</button>
						</div>
					</div>
				</div>
			</form>

			{isAdmin && <AdminArtists />}
		</section>
	);
}

function AdminArtists() {
	const [artists, setArtists] = useState<ArtistUser[]>([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState('');
	const [editingId, setEditingId] = useState<string | null>(null);
	const [editName, setEditName] = useState('');
	const [editBio, setEditBio] = useState('');
	const [savingId, setSavingId] = useState<string | null>(null);

	const load = async () => {
		setLoading(true);
		setError('');
		try {
			const list = await pb.collection('users').getFullList<ArtistUser>({
				sort: '-created',
				requestKey: null,
			});
			setArtists(list);
		} catch {
			setError('Could not load artist accounts.');
		} finally {
			setLoading(false);
		}
	};

	useEffect(() => {
		load();
	}, []);

	const startEdit = (artist: ArtistUser) => {
		setEditingId(artist.id);
		setEditName(artist.name ?? '');
		setEditBio(artist.bio ?? '');
	};

	const saveEdit = async (id: string) => {
		setSavingId(id);
		try {
			await pb.collection('users').update(id, { name: editName, bio: editBio });
			setArtists(prev => prev.map(a => (a.id === id ? { ...a, name: editName, bio: editBio } : a)));
			setEditingId(null);
		} catch {
			setError('Could not save that profile.');
		} finally {
			setSavingId(null);
		}
	};

	return (
		<section className="admin-artists">
			<div className="section-heading">
				<div>
					<div className="eyebrow">ADMIN</div>
					<h2>Manage artists<span className="text-cyan">.</span></h2>
					<p>Every registered artist on the platform.</p>
				</div>
				<span className="hub-label"><Users size={14} /> {artists.length} ACCOUNTS</span>
			</div>

			{error && <p className="field-error auth-error" role="alert"><AlertCircle size={14} /> {error}</p>}

			{loading ? (
				<p className="admin-loading"><Loader2 size={16} className="spin" /> Loading artists…</p>
			) : artists.length === 0 ? (
				<p className="admin-empty">No artist accounts yet.</p>
			) : (
				<ul className="admin-list">
					{artists.map(artist => (
						<li key={artist.id} className="admin-row">
							<div className="admin-row-main">
								<div className="artist-avatar admin-avatar" aria-hidden="true">
									{artist.avatar
										? <img src={avatarUrl(artist)} alt="" />
										: (artist.name || artist.email || 'A').charAt(0).toUpperCase()}
								</div>
								<div className="admin-row-meta">
									{editingId === artist.id ? (
										<input className="admin-edit-input" value={editName} onChange={e => setEditName(e.target.value)} />
									) : (
										<strong>{artist.name || '(no name)'}</strong>
									)}
									<span>{artist.email}</span>
									<span className="admin-row-role">
										{artist.role === 'admin' ? 'Admin' : 'Artist'}
										{artist.verified ? ' · Verified' : ' · Unverified'}
									</span>
								</div>
							</div>
							<div className="admin-row-actions">
								{editingId === artist.id ? (
									<>
										<textarea
											className="admin-edit-bio"
											rows={2}
											value={editBio}
											onChange={e => setEditBio(e.target.value)}
											placeholder="Bio"
										/>
										<button type="button" className="button button-cyan admin-mini" disabled={savingId === artist.id} onClick={() => saveEdit(artist.id)}>
											{savingId === artist.id ? <Loader2 size={14} className="spin" /> : <Save size={14} />} Save
										</button>
										<button type="button" className="button button-ghost admin-mini" onClick={() => setEditingId(null)}>Cancel</button>
									</>
								) : (
									<button type="button" className="button button-ghost admin-mini" onClick={() => startEdit(artist)}>Edit</button>
								)}
							</div>
						</li>
					))}
				</ul>
			)}

			<div className="admin-footnote">
				<Link to="/artist">View the draft artist catalog page</Link>
			</div>
		</section>
	);
}
