import type { Route } from './+types/podcast';
import { seo } from '@/lib/seo';
import { RADIO_ART } from '@/constants/radio';
import { PodcastHero } from '@/components/podcast/podcast-hero';
import { EpisodeList } from '@/components/podcast/episode-list';
import { SiteFooter } from '@/components/site-footer';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Trident Radio Podcast',
		description: 'The Trident Radio podcast: creator conversations, station sessions, and behind-the-scenes stories. Published episodes play right here through the Trident player when audio is available.',
		image: RADIO_ART,
		jsonLd: [
			{
				'@context': 'https://schema.org',
				'@type': 'PodcastSeries',
				name: 'Trident Radio Podcast',
				description: 'Creator conversations, station sessions, and behind-the-scenes stories from Trident Radio.',
				webFeed: '',
			},
			{ '@context': 'https://schema.org', '@type': 'Organization', name: 'Trident Radio' },
		],
	});
}

export default function PodcastPage() {
	return (
		<main className="main-content">
			<PodcastHero />
			<EpisodeList />
			<SiteFooter />
		</main>
	);
}
