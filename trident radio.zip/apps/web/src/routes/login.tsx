import type { Route } from './+types/login';
import { seo } from '@/lib/seo';
import { LoginForm } from '@/components/auth/login-form';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Sign in | Trident Radio & CreatorOS Hub',
		description: 'Sign in to your Trident Radio artist account to edit your profile and manage your presence on the CreatorOS Hub.',
	});
}

export default function LoginPage() {
	return (
		<main className="main-content auth-page">
			<div className="auth-card">
				<div className="auth-card-head">
					<div className="eyebrow"><span className="tiny-line" /> ARTIST SIGN-IN</div>
					<h1>Welcome back<span className="text-cyan">.</span></h1>
					<p>Sign in to edit your artist profile and manage your space.</p>
				</div>
				<LoginForm />
			</div>
		</main>
	);
}
