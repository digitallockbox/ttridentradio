import type { Route } from './+types/artist';
import { seo } from '@/lib/seo';
import { ArtistProvider } from '@/components/artist/artist-provider';
import { ArtistHero } from '@/components/artist/artist-hero';
import { ArtistCatalog } from '@/components/artist/artist-catalog';
import { SiteFooter } from '@/components/site-footer';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Anthony D. Simmons — Artist Catalog | Trident Radio',
		description: 'Listen to Anthony D. Simmons on Trident Radio. Play tracks from the Brickyard Beats catalog, follow the artist, and add tracks to your Trident playlist.',
		jsonLd: [
			{ '@context': 'https://schema.org', '@type': 'WebSite', name: 'Trident Radio', description: 'Trident Radio live audio player and CreatorOS Hub.' },
			{ '@context': 'https://schema.org', '@type': 'Organization', name: 'Trident Radio' },
		],
	});
}

export default function ArtistPage() {
	return (
		<main className="main-content">
			<ArtistProvider>
				<ArtistHero />
				<ArtistCatalog />
			</ArtistProvider>
			<SiteFooter />
		</main>
	);
}
