import type { Route } from './+types/playbook';
import { seo } from '@/lib/seo';
import { RADIO_ART } from '@/constants/radio';
import { PLAYBOOK_SECTIONS } from '@/data/playbook';
import { PlaybookHero } from '@/components/playbook/playbook-hero';
import { PlaybookSection } from '@/components/playbook/playbook-section';
import { SiteFooter } from '@/components/site-footer';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Creator Campaign Playbook — Trident Radio',
		description: 'A strategic playbook for tridentradio.live creators: account setup, a promotion & discovery toolkit, visual branding, merch & live events, and audience analytics — presented as external artist-platform capabilities.',
		image: RADIO_ART,
		jsonLd: [
			{ '@context': 'https://schema.org', '@type': 'WebSite', name: 'Trident Radio Creator Campaign Playbook', description: 'Strategic creator and campaign playbook for tridentradio.live.' },
			{ '@context': 'https://schema.org', '@type': 'Organization', name: 'Trident Radio' },
		],
	});
}

export default function PlaybookPage() {
	return (
		<main className="main-content">
			<PlaybookHero />
			{PLAYBOOK_SECTIONS.map((section, index) => (
				<PlaybookSection key={section.id} section={section} index={index} />
			))}
			<SiteFooter />
		</main>
	);
}
