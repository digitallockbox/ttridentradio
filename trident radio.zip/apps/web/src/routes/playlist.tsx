import type { Route } from './+types/playlist';
import { seo } from '@/lib/seo';
import { PlaylistView } from '@/components/playlist/playlist-view';
import { SiteFooter } from '@/components/site-footer';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Your Playlist | Trident Radio',
		description: 'Curate and play your personal Trident Radio playlist from tracks by any artist. Add and remove tracks, then play them through the Trident player.',
		jsonLd: [
			{ '@context': 'https://schema.org', '@type': 'WebSite', name: 'Trident Radio', description: 'Trident Radio live audio player and CreatorOS Hub.' },
		],
	});
}

export default function PlaylistPage() {
	return (
		<main className="main-content">
			<section className="page-heading">
				<div>
					<div className="eyebrow"><span className="tiny-line" /> YOUR PLAYLIST</div>
					<h1>Your Trident playlist<span className="text-cyan">.</span></h1>
					<p>Curate playable tracks from any artist on Trident Radio. Add tracks from artist catalogs and the rotation, then play your playlist through the Trident player.</p>
				</div>
			</section>
			<PlaylistView />
			<SiteFooter />
		</main>
	);
}
