import type { Route } from './+types/station';
import { seo } from '@/lib/seo';
import { RADIO_ART } from '@/constants/radio';
import { StationHero } from '@/components/station/station-hero';
import { RotationCatalog } from '@/components/station/rotation-catalog';
import { SiteFooter } from '@/components/site-footer';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Trident Radio Station Hub',
		description: 'The TridentRadio.live station hub: a single place to tune into Trident Radio, with clearly labeled setup placeholders for syndication, wallet, and royalty routing that are not yet configured.',
		image: RADIO_ART,
		jsonLd: [
			{ '@context': 'https://schema.org', '@type': 'WebSite', name: 'Trident Radio Station Hub', description: 'Trident Radio station hub.' },
			{ '@context': 'https://schema.org', '@type': 'Organization', name: 'Trident Radio' },
		],
	});
}

export default function StationPage() {
	return (
		<main className="main-content">
			<StationHero />
			<RotationCatalog />
			<SiteFooter />
		</main>
	);
}
