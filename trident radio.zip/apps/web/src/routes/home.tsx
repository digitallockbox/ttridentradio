import type { Route } from './+types/home';
import { seo } from '@/lib/seo';
import { RADIO_ART } from '@/constants/radio';
import { LandingHero } from '@/components/home/landing-hero';
import { LandingFeatures } from '@/components/home/landing-features';
import { CreatorHub } from '@/components/home/creator-hub';
import { ListeningGuide } from '@/components/home/listening-guide';
import { Advertisement } from '@/components/home/advertisement';
import { SiteFooter } from '@/components/site-footer';

export function meta({ matches, location }: Route.MetaArgs) {
  return seo({ matches, location }, {
    title: 'Trident Radio — Listen, Create, and Share',
    description: 'Trident Radio is a clean, focused space to listen to live radio, upload your own music, and build a catalog that plays in the Trident player.',
    image: RADIO_ART,
    jsonLd: [{ '@context': 'https://schema.org', '@type': 'WebSite', name: 'Trident Radio', description: 'Trident Radio live audio player and CreatorOS Hub.' }, { '@context': 'https://schema.org', '@type': 'Organization', name: 'Trident Radio' }],
  });
}

export default function HomePage() {
  return <main className="main-content dashboard-content"><LandingHero /><LandingFeatures /><CreatorHub /><ListeningGuide /><Advertisement /><SiteFooter /></main>;
}
