import { ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router';
import type { Route } from './+types/checkout.cancelled';
import { seo } from '@/lib/seo';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Checkout cancelled | Trident Radio',
		description: 'Your Trident Radio checkout was cancelled. Nothing was charged.',
		noindex: true,
	});
}

export default function CheckoutCancelled() {
	return (
		<main className="main-content auth-page">
			<div className="auth-card">
				<span className="dialog-icon"><ArrowUpRight size={25} /></span>
				<h1>Checkout cancelled<span className="text-cyan">.</span></h1>
				<p className="auth-card-head-p">Your payment was not completed and nothing was charged. Feel free to try again whenever you are ready.</p>
				<div className="add-track-actions">
					<Link className="button button-ghost" to="/station">Go to station</Link>
					<Link className="button button-cyan" to="/">Back home</Link>
				</div>
			</div>
		</main>
	);
}
