import { apiError, json, readFormData, withApi } from '@/lib/api.server';
import { pocketbaseAdmin } from '@/lib/pocketbase-client.server';

/**
 * POST /api/v1/upload
 * Stores a single audio/video/image file in the PocketBase `uploads`
 * collection (server-side, superuser) and returns its public file URL so the
 * caller can verify where the file landed.
 */
export const action = withApi(async ({ request }) => {
  const formData = await readFormData(request);
  const file = formData.get('file');

  if (!(file instanceof File)) {
    return apiError(422, 'No file was provided.');
  }

  if (file.size === 0) {
    return apiError(422, 'The selected file is empty.');
  }

  const isAllowed = file.type.startsWith('audio/')
    || file.type.startsWith('video/')
    || file.type.startsWith('image/');

  if (!isAllowed) {
    return apiError(422, 'Only audio, video, and image files are accepted.');
  }

  const pbFormData = new FormData();
  pbFormData.append('file', file, file.name);
  pbFormData.append('name', file.name);
  pbFormData.append('mime', file.type || 'application/octet-stream');
  pbFormData.append('size', String(file.size));

  const record = await pocketbaseAdmin.createRecord<{ id: string; file: string }>(
    'uploads',
    pbFormData,
  );

  const publicPath = `/hcgi/platform/api/files/uploads/${record.id}/${record.file}`;

  return json({
    success: true,
    id: record.id,
    name: file.name,
    size: file.size,
    url: publicPath,
  });
});
