import type { Route } from './+types/account';
import { seo } from '@/lib/seo';
import { requireAuth } from '@/lib/require-auth';
import { AccountPanel } from '@/components/account/account-panel';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Your account | Trident Radio & CreatorOS Hub',
		description: 'Edit your Trident Radio artist profile. Admins can manage every artist on the platform.',
	});
}

export function clientLoader() {
	return { user: requireAuth() };
}
clientLoader.hydrate = true as const;

export function HydrateFallback() {
	return (
		<main className="main-content auth-page">
			<div className="auth-card">
				<p className="admin-loading">Loading your account…</p>
			</div>
		</main>
	);
}

export default function AccountPage({ loaderData }: Route.ComponentProps) {
	return (
		<main className="main-content auth-page">
			<AccountPanel key={loaderData.user.id} />
		</main>
	);
}
