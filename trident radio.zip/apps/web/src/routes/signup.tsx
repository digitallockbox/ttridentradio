import type { Route } from './+types/signup';
import { seo } from '@/lib/seo';
import { SignupForm } from '@/components/auth/signup-form';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Artist sign-up | Trident Radio & CreatorOS Hub',
		description: 'Create your artist account on Trident Radio to edit your profile and join the CreatorOS Hub.',
	});
}

export default function SignupPage() {
	return (
		<main className="main-content auth-page">
			<div className="auth-card">
				<div className="auth-card-head">
					<div className="eyebrow"><span className="tiny-line" /> JOIN AS AN ARTIST</div>
					<h1>Create your account<span className="text-cyan">.</span></h1>
					<p>Sign up to edit your artist profile and take part in the CreatorOS Hub.</p>
				</div>
				<SignupForm />
			</div>
		</main>
	);
}
