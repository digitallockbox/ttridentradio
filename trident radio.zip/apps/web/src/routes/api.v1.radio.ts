import { json, withApi } from '@/lib/api.server';
import { getConfig } from '@/lib/radio-engine.server';

/**
 * GET /api/v1/radio
 * Returns the active Trident Radio stream ingest configuration (title, URL,
 * source type, status). This is the source the player boots with.
 */
export const loader = withApi(async () => {
  return json({ success: true, config: getConfig() });
});
