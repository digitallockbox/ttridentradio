import { apiError, json, readJsonBody, withApi } from '@/lib/api.server';
import { updateConfig } from '@/lib/radio-engine.server';

/**
 * POST /api/v1/radio/update
 * Updates the Trident Radio live stream source. Accepts a JSON body:
 *   { streamUrl, streamTitle?, sourceType? }
 * sourceType labels the ingest kind (Direct Audio Stream, HLS (.m3u8) Relay,
 * Icecast/Direct Audio Relay, Shoutcast Relay, Third-Party Relay, Custom).
 */
export const action = withApi(async ({ request }) => {
  const { streamUrl, streamTitle, sourceType } = await readJsonBody<{
    streamUrl?: string;
    streamTitle?: string;
    sourceType?: string;
  }>(request);

  if (!streamUrl) {
    return apiError(422, 'streamUrl is required');
  }

  let parsed: URL;
  try {
    parsed = new URL(streamUrl);
  } catch {
    return apiError(422, 'streamUrl must be a valid URL');
  }

  // Browsers block mixed-content (http stream on an https page), and the
  // player requires a cross-origin-permissive source — enforce https.
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password) {
    return apiError(
      422,
      'streamUrl must be a clean https URL (no embedded credentials) so playback is not blocked as mixed content.',
    );
  }

  const updated = updateConfig(parsed.href, streamTitle, sourceType);
  return json({
    success: true,
    message: 'Trident Radio live stream source updated successfully.',
    config: updated,
  });
});
