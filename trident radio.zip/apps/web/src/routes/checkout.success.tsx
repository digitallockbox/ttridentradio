import { useEffect } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router';
import type { Route } from './+types/checkout.success';
import { seo } from '@/lib/seo';
import { useCart } from '@/hooks/use-ecommerce-cart';

export function meta({ matches, location }: Route.MetaArgs) {
	return seo({ matches, location }, {
		title: 'Order confirmed | Trident Radio',
		description: 'Your Trident Radio order is confirmed.',
		noindex: true,
	});
}

export default function CheckoutSuccess() {
	const { isLoading, clear } = useCart();

	useEffect(() => {
		if (!isLoading) {
			clear();
		}
	}, [isLoading, clear]);

	return (
		<main className="main-content auth-page">
			<div className="auth-card">
				<span className="dialog-icon"><CheckCircle2 size={25} /></span>
				<h1>Order confirmed<span className="text-cyan">.</span></h1>
				<p className="auth-card-head-p">Thanks for your purchase. Your order is confirmed and a receipt is on its way.</p>
				<div className="add-track-actions">
					<Link className="button button-ghost" to="/station">Go to station</Link>
					<Link className="button button-cyan" to="/">Back home</Link>
				</div>
			</div>
		</main>
	);
}
