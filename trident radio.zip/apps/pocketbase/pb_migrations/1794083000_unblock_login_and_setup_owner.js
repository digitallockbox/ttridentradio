/// <reference path="../pb_data/types.d.ts" />

// Removes the `verified = true` auth gate that blocked every login attempt:
// signup's auto-login threw (new users are unverified) and the seeded owner
// account could not sign in, so the authenticated artist upload experience
// was unreachable. Login no longer requires a verified email — email
// verification is still requested on signup as best-effort confirmation.
//
// The real account/ownership protections stay in place: the `role` field
// remains locked against self-escalation, tracks remain owner-scoped, and
// admin user management stays admin-only.
//
// Also completes the owner account setup with a known strong password and a
// verified email so the owner can sign in immediately.
migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    users.authRule = "";
    app.save(users);

    const ownerEmail = "calerashipping@gmail.com";
    try {
      const owner = app.findAuthRecordByEmail("users", ownerEmail);
      owner.setPassword("TridentRadio#2026");
      owner.set("verified", true);
      app.save(owner);
    } catch (_) {
      /* owner record not present in this environment; nothing to update */
    }
  },
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    users.authRule = "verified = true";
    app.save(users);
  },
);
