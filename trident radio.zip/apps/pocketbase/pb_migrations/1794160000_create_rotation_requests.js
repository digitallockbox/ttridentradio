/// <reference path="../pb_data/types.d.ts" />

// Pay-to-Play rotation slot requests. An artist pays for a rotation slot
// (hour / day / week), receives a shareable link, and the request enters a
// pending/approval flow. Payment does NOT guarantee a slot — the request is
// reviewed and either approved (track enters rotation) or rejected.
//
// Reads are public so the shareable link (/rotation-request/:token) works for
// anyone. Writes are owner-scoped (the artist creates and advances their own
// request) plus admin (approval / rejection). The status field is the only
// thing that transitions, and the owner advancing awaiting_payment -> pending
// after checkout is the expected path.
migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    const tracks = app.findCollectionByNameOrId("tracks");

    const collection = new Collection({
      type: "base",
      name: "rotation_requests",
      // Public reads: the shareable link must open for anyone.
      listRule: "",
      viewRule: "",
      createRule: "@request.auth.id != '' && @request.auth.id = @request.body.owner",
      updateRule: "(@request.auth.id != '' && @request.auth.id = owner) || @request.auth.role = 'admin'",
      deleteRule: "@request.auth.id != '' && @request.auth.id = owner",
      fields: [
        {
          name: "track",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: tracks.id,
          cascadeDelete: true,
        },
        {
          name: "owner",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: users.id,
          cascadeDelete: true,
        },
        { name: "category", type: "text", max: 100 },
        {
          name: "duration",
          type: "select",
          required: true,
          maxSelect: 1,
          values: ["hour", "day", "week"],
        },
        {
          name: "status",
          type: "select",
          required: true,
          maxSelect: 1,
          values: ["awaiting_payment", "pending", "approved", "rejected"],
        },
        { name: "token", type: "text", required: true, max: 64 },
        { name: "note", type: "text", max: 500 },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
      indexes: [
        "CREATE UNIQUE INDEX idx_rotation_requests_token ON rotation_requests (token) WHERE token != ''",
      ],
    });
    app.save(collection);
  },
  (app) => {
    try {
      const collection = app.findCollectionByNameOrId("rotation_requests");
      app.delete(collection);
    } catch (e) {
      if (e.message.includes("no rows in result set")) return;
      throw e;
    }
  },
);
