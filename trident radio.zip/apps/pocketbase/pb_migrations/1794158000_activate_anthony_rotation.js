/// <reference path="../pb_data/types.d.ts" />

// Puts Anthony D. Simmons's playable catalog tracks into the Trident Radio
// rotation so listeners hear his music as the station's rotation playlist.
//
// Only tracks that actually have a usable audio source — an uploaded audio
// file OR a valid direct audio URL — are activated. Tracks without playable
// audio are left as "pending" so the rotation never lists something that
// cannot play. Ownership protections are untouched: writes remain
// owner-scoped and only the track owner can later pause/rotate their tracks.
//
// This is a one-time activation of existing tracks owned by the platform
// owner (Anthony D. Simmons, calerashipping@gmail.com). Tracks uploaded
// afterward still default to "pending" and are activated by their owner
// from the artist catalog page.
migrate(
  (app) => {
    let owner;
    try {
      owner = app.findFirstRecordByFilter(
        "users",
        "email = 'calerashipping@gmail.com'",
      );
    } catch (_) {
      // Owner account not present in this environment — nothing to activate.
      return;
    }

    const ownerId = owner.id;

    let tracks = [];
    try {
      // Anthony's tracks only.
      tracks = app.findRecordsByFilter(
        "tracks",
        "owner = '" + ownerId + "'",
        "",
        1,
        500,
      );
    } catch (_) {
      return;
    }

    for (const rec of tracks) {
      const hasFile = rec.get("audio_file") !== "" && rec.get("audio_file") != null;
      const hasUrl = rec.get("audio_url") !== "" && rec.get("audio_url") != null;
      if (hasFile || hasUrl) {
        rec.set("rotation", "active");
        app.save(rec);
      }
    }
  },
  (app) => {
    // Revert: set Anthony's tracks that we activated back to "pending".
    let owner;
    try {
      owner = app.findFirstRecordByFilter(
        "users",
        "email = 'calerashipping@gmail.com'",
      );
    } catch (_) {
      return;
    }

    let tracks = [];
    try {
      tracks = app.findRecordsByFilter(
        "tracks",
        "owner = '" + owner.id + "' && rotation = 'active'",
        "",
        1,
        500,
      );
    } catch (_) {
      return;
    }

    for (const rec of tracks) {
      rec.set("rotation", "pending");
      app.save(rec);
    }
  },
);
