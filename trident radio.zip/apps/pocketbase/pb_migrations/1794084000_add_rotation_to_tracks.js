/// <reference path="../pb_data/types.d.ts" />

// Adds a `rotation` select field to the `tracks` collection so uploaded tracks
// can be included in the in-app Trident Radio catalog for spin rotation.
//
// Values:
//   - "pending": newly uploaded track awaiting rotation activation (default)
//   - "active": track is in the Trident Radio rotation catalog
//   - "paused": track was in rotation but paused by its owner
//
// Only tracks with an available audio file or a usable direct audio URL are
// eligible for rotation; the frontend enforces that before letting the owner
// activate a track. Writes remain owner-scoped (updateRule already restricts
// to the owner), so only the track's owner can change its rotation status —
// account ownership protections are preserved.
migrate(
  (app) => {
    const tracks = app.findCollectionByNameOrId("tracks");
    tracks.fields.add(
      new SelectField({
        name: "rotation",
        maxSelect: 1,
        values: ["pending", "active", "paused"],
      }),
    );
    app.save(tracks);

    // Backfill any existing tracks to "pending" so they have a defined status.
    const existing = app.findRecordsByFilter("tracks", "id != ''", "", 1, 500);
    for (const rec of existing) {
      if (!rec.get("rotation")) {
        rec.set("rotation", "pending");
        app.save(rec);
      }
    }
  },
  (app) => {
    const tracks = app.findCollectionByNameOrId("tracks");
    tracks.fields.removeByName("rotation");
    app.save(tracks);
  },
);
