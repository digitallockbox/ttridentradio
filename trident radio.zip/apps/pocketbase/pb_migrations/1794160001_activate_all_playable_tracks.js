/// <reference path="../pb_data/types.d.ts" />

// Fixes the empty Trident Radio rotation catalog. The previous activation
// migration only activated tracks owned by one specific email, so when that
// owner is absent (or its tracks lack audio) the station rotation shows
// "No tracks are in rotation yet" even though playable tracks exist.
//
// This activates EVERY track that has a usable audio source — an uploaded
// audio file OR a valid direct audio URL — regardless of owner, so the
// rotation catalog reflects all playable music on the platform. Tracks
// without playable audio stay "pending". Ownership protections are untouched:
// writes remain owner-scoped and only the track owner can later pause/rotate.
migrate(
  (app) => {
    let tracks = [];
    try {
      tracks = app.findRecordsByFilter("tracks", "rotation != 'active'", "", 1, 500);
    } catch (_) {
      return;
    }

    for (const rec of tracks) {
      const hasFile = rec.get("audio_file") !== "" && rec.get("audio_file") != null;
      const hasUrl = rec.get("audio_url") !== "" && rec.get("audio_url") != null;
      if (hasFile || hasUrl) {
        rec.set("rotation", "active");
        app.save(rec);
      }
    }
  },
  (app) => {
    // Revert is a no-op: we do not want to deactivate playable tracks.
  },
);
