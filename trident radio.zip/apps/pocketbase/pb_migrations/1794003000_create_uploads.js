/// <reference path="../pb_data/types.d.ts" />

// Stores creator-uploaded audio/video/image files. Writes happen only through
// the server-side /api/v1/upload route (superuser), so createRule is null.
// viewRule is open so a returned file URL resolves for verification; listRule
// is null so the collection is not enumerable.
migrate(
  (app) => {
    let collection;
    try {
      collection = app.findCollectionByNameOrId("uploads");
    } catch (_) {
      collection = new Collection({
        type: "base",
        name: "uploads",
        listRule: null,
        viewRule: "",
        createRule: null,
        updateRule: null,
        deleteRule: null,
        fields: [
          {
            name: "file",
            type: "file",
            maxSelect: 1,
            maxSize: 26214400, // 25 MB headroom above the 20 MB upload cap
            mimeTypes: [
              "audio/*",
              "video/*",
              "image/*",
            ],
          },
          { name: "name", type: "text", max: 300 },
          { name: "mime", type: "text", max: 200 },
          { name: "size", type: "number" },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
      });
      app.save(collection);
    }
  },
  (app) => {
    try {
      const collection = app.findCollectionByNameOrId("uploads");
      app.delete(collection);
    } catch (e) {
      if (e.message.includes("no rows in result set")) {
        return;
      }
      throw e;
    }
  },
);
