/// <reference path="../pb_data/types.d.ts" />

// Creates three owner-scoped collections that back the per-track engagement
// features on the artist catalog and station rotation:
//   - track_reactions: a signed-in user's thumbs-up (like) / thumbs-down
//     (dislike) on a track. One reaction per user per track.
//   - playlist_items: a signed-in user's personal "Trident playlist" entries.
//     One entry per user per track.
//   - follows: a signed-in user's artist follows. One follow per user per artist.
//
// All three are owner-scoped (only the owner can list/view/create/update/delete
// their own records), preserving artist ownership and account protections.
// Writes require the submitted `owner` to match the caller.
migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    const tracks = app.findCollectionByNameOrId("tracks");

    // --- track_reactions ---
    let reactions;
    try {
      reactions = app.findCollectionByNameOrId("track_reactions");
    } catch (_) {
      reactions = new Collection({
        type: "base",
        name: "track_reactions",
        listRule: "@request.auth.id != '' && @request.auth.id = owner",
        viewRule: "@request.auth.id != '' && @request.auth.id = owner",
        createRule: "@request.auth.id != '' && @request.auth.id = @request.body.owner",
        updateRule: "@request.auth.id != '' && @request.auth.id = owner",
        deleteRule: "@request.auth.id != '' && @request.auth.id = owner",
        fields: [
          {
            name: "track",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: tracks.id,
            cascadeDelete: true,
          },
          {
            name: "kind",
            type: "select",
            required: true,
            maxSelect: 1,
            values: ["like", "dislike"],
          },
          {
            name: "owner",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
        indexes: [
          "CREATE UNIQUE INDEX idx_track_reactions_owner_track ON track_reactions (owner, track)",
        ],
      });
      app.save(reactions);
    }

    // --- playlist_items ---
    let playlist;
    try {
      playlist = app.findCollectionByNameOrId("playlist_items");
    } catch (_) {
      playlist = new Collection({
        type: "base",
        name: "playlist_items",
        listRule: "@request.auth.id != '' && @request.auth.id = owner",
        viewRule: "@request.auth.id != '' && @request.auth.id = owner",
        createRule: "@request.auth.id != '' && @request.auth.id = @request.body.owner",
        updateRule: "@request.auth.id != '' && @request.auth.id = owner",
        deleteRule: "@request.auth.id != '' && @request.auth.id = owner",
        fields: [
          {
            name: "track",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: tracks.id,
            cascadeDelete: true,
          },
          {
            name: "owner",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
        indexes: [
          "CREATE UNIQUE INDEX idx_playlist_items_owner_track ON playlist_items (owner, track)",
        ],
      });
      app.save(playlist);
    }

    // --- follows ---
    let follows;
    try {
      follows = app.findCollectionByNameOrId("follows");
    } catch (_) {
      follows = new Collection({
        type: "base",
        name: "follows",
        listRule: "@request.auth.id != '' && @request.auth.id = owner",
        viewRule: "@request.auth.id != '' && @request.auth.id = owner",
        createRule: "@request.auth.id != '' && @request.auth.id = @request.body.owner",
        updateRule: "@request.auth.id != '' && @request.auth.id = owner",
        deleteRule: "@request.auth.id != '' && @request.auth.id = owner",
        fields: [
          {
            name: "artist",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          {
            name: "owner",
            type: "relation",
            required: true,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
        indexes: [
          "CREATE UNIQUE INDEX idx_follows_owner_artist ON follows (owner, artist)",
        ],
      });
      app.save(follows);
    }
  },
  (app) => {
    for (const name of ["track_reactions", "playlist_items", "follows"]) {
      try {
        app.delete(app.findCollectionByNameOrId(name));
      } catch (e) {
        if (e && e.message && e.message.includes("no rows in result set")) {
          continue;
        }
        throw e;
      }
    }
  },
);
