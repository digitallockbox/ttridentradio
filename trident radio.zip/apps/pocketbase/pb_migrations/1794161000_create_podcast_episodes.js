/// <reference path="../pb_data/types.d.ts" />

// Podcast episodes for the Trident Radio / CreatorOS Hub.
//
// Published episodes are publicly listenable (anyone can list/view published
// episodes). Unpublished (draft) episodes are only visible to their owner.
// Writes are owner-scoped: a signed-in artist creates and manages their own
// episodes. No episodes are seeded — the podcast page shows an honest empty
// state until a real episode with audio is published.
migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    const collection = new Collection({
      type: "base",
      name: "podcast_episodes",
      // Public reads for published episodes; owners also see their own drafts.
      listRule: "published = true || @request.auth.id = owner",
      viewRule: "published = true || @request.auth.id = owner",
      createRule: "@request.auth.id != '' && @request.auth.id = @request.body.owner",
      updateRule: "@request.auth.id != '' && @request.auth.id = owner",
      deleteRule: "@request.auth.id != '' && @request.auth.id = owner",
      fields: [
        { name: "title", type: "text", required: true, max: 200 },
        { name: "description", type: "text", max: 2000 },
        { name: "credit", type: "text", max: 200 },
        {
          name: "audio_file",
          type: "file",
          maxSelect: 1,
          maxSize: 26214400,
          mimeTypes: [
            "audio/mpeg",
            "audio/mp3",
            "audio/wav",
            "audio/x-wav",
            "audio/ogg",
            "audio/webm",
            "audio/aac",
            "audio/flac",
            "audio/x-flac",
            "audio/x-m4a",
            "audio/m4a",
            "audio/mp4",
          ],
        },
        { name: "audio_url", type: "url" },
        {
          name: "owner",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: users.id,
          cascadeDelete: true,
        },
        // `published` is a toggle flag — leave required off so the natural
        // false default (draft) is accepted on create.
        { name: "published", type: "bool" },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
      indexes: [],
    });
    app.save(collection);
  },
  (app) => {
    try {
      const collection = app.findCollectionByNameOrId("podcast_episodes");
      app.delete(collection);
    } catch (e) {
      if (e.message.includes("no rows in result set")) return;
      throw e;
    }
  },
);
