/// <reference path="../pb_data/types.d.ts" />

// Re-asserts the owner/admin account login so the owner can sign in reliably
// without resetting their password. Earlier seed migrations set the password
// once; if a preview database reset wiped the account or the password drifted,
// login failed with "invalid login credentials". This idempotent migration
// restores the known credentials (calerashipping@gmail.com / TridentRadio#2026),
// keeps the email verified, and re-runs on any fresh database so the owner is
// never locked out. Login does not require a verified email (authRule stays
// empty); the role field stays locked against self-escalation by the earlier
// migrations.
migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    const ownerEmail = "calerashipping@gmail.com";
    const ownerId = $security.sha256("users:" + ownerEmail).substring(0, 15);

    let owner;
    try {
      owner = app.findAuthRecordByEmail("users", ownerEmail);
    } catch (_) {
      owner = new Record(users);
      owner.set("id", ownerId);
      owner.setEmail(ownerEmail);
      owner.set("name", "Anthony D. Simmons");
      owner.set("role", "admin");
    }

    owner.setPassword("TridentRadio#2026");
    owner.set("verified", true);
    owner.set("role", "admin");
    owner.set("name", "Anthony D. Simmons");
    app.save(owner);
  },
  (app) => {
    // No-op revert: do not delete or lock the owner account.
  },
);
