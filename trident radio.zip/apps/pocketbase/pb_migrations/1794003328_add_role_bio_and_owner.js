/// <reference path="../pb_data/types.d.ts" />

// Adds a privileged `role` field (artist/admin) and a `bio` field to the
// existing `users` auth collection, locks `role` against self-escalation,
// opens admin read/write access for managing artist profiles, requires a
// verified email before login, and seeds the owner/admin account for
// Anthony D. Simmons (calerashipping@gmail.com) — unverified, with a random
// throwaway password the owner replaces via the built-in password-reset flow.
migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    if (!users.fields.getByName("role")) {
      users.fields.add(
        new SelectField({
          name: "role",
          required: false,
          maxSelect: 1,
          values: ["artist", "admin"],
        }),
      );
    }

    if (!users.fields.getByName("bio")) {
      users.fields.add(new TextField({ name: "bio", max: 1000 }));
    }

    // Admins can list/view every user (to manage artist profiles); everyone
    // else only sees their own record.
    users.listRule = "id = @request.auth.id || @request.auth.role = 'admin'";
    users.viewRule = "id = @request.auth.id || @request.auth.role = 'admin'";

    // Public artist sign-up: role may be omitted or set to "artist" only.
    users.createRule =
      "@request.body.role:isset = false || @request.body.role = 'artist'";

    // Self-edit with role locked (no escalation); admins may edit anyone.
    users.updateRule =
      "(id = @request.auth.id && @request.body.role:changed = false) || @request.auth.role = 'admin'";

    users.deleteRule = "id = @request.auth.id";

    // Require a verified email before authentication is allowed.
    users.authRule = "verified = true";

    app.save(users);

    // Seed the owner account. The password below is a random, unrevealed
    // throwaway — the owner completes setup by verifying the email and
    // resetting the password through PocketBase's built-in flow. No assumed
    // password is used to log in.
    const ownerEmail = "calerashipping@gmail.com";
    try {
      app.findAuthRecordByEmail("users", ownerEmail);
    } catch (_) {
      const owner = new Record(users);
      owner.set(
        "id",
        $security.sha256("users:" + ownerEmail).substring(0, 15),
      );
      owner.setEmail(ownerEmail);
      owner.setPassword(
        $security.sha256(
          "owner-setup:" + ownerEmail + ":trident-radio",
        ).substring(0, 24),
      );
      owner.set("name", "Anthony D. Simmons");
      owner.set("role", "admin");
      owner.set("verified", false);
      app.save(owner);
    }
  },
  (app) => {
    try {
      const users = app.findCollectionByNameOrId("users");
      if (users.fields.getByName("role")) {
        users.fields.removeByName("role");
      }
      if (users.fields.getByName("bio")) {
        users.fields.removeByName("bio");
      }
      users.listRule = "id = @request.auth.id";
      users.viewRule = "id = @request.auth.id";
      users.createRule = "";
      users.updateRule = "id = @request.auth.id";
      users.deleteRule = "id = @request.auth.id";
      users.authRule = "";
      app.save(users);
    } catch (_) {
      /* collection gone */
    }

    try {
      const owner = app.findAuthRecordByEmail(
        "users",
        "calerashipping@gmail.com",
      );
      app.delete(owner);
    } catch (_) {
      /* already gone */
    }
  },
);
