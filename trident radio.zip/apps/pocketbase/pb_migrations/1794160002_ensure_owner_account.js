/// <reference path="../pb_data/types.d.ts" />

// Re-seeds the owner/admin account after a preview database reset. The earlier
// seed migrations are already marked applied, so they will not re-run — but the
// records they created are gone from this fresh preview database. This migration
// restores the owner account (Anthony D. Simmons) with a known strong password
// and a verified email so the owner can sign in immediately, manage artists,
// and use the Pay-to-Play flow. It is idempotent: if the owner already exists,
// it only re-asserts the password and verified status.
migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");
    const ownerEmail = "calerashipping@gmail.com";
    const ownerId = $security.sha256("users:" + ownerEmail).substring(0, 15);

    let owner;
    try {
      owner = app.findAuthRecordByEmail("users", ownerEmail);
    } catch (_) {
      owner = new Record(users);
      owner.set("id", ownerId);
      owner.setEmail(ownerEmail);
      owner.set("name", "Anthony D. Simmons");
      owner.set("role", "admin");
    }

    owner.setPassword("TridentRadio#2026");
    owner.set("verified", true);
    owner.set("role", "admin");
    owner.set("name", "Anthony D. Simmons");
    app.save(owner);
  },
  (app) => {
    // No-op revert: do not delete the owner account.
  },
);
