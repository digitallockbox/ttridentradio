/// <reference path="../pb_data/types.d.ts" />

// The Pay-to-Play rotation-slot purchase flow was removed from the UI, but the
// `rotation_requests` collection was left with public list/view rules ("").
// That exposed every rotation request's owner, track, category, duration,
// status, token, and note to anyone, including anonymous visitors. No code
// references this collection anymore, so lock every rule down to null (nobody
// via REST). The collection and its existing records are preserved; only the
// access rules change. If Pay-to-Play is ever re-introduced, a new migration
// can re-open the specific rules it needs.
migrate(
  (app) => {
    const collection = app.findCollectionByNameOrId("rotation_requests");
    collection.listRule = null;
    collection.viewRule = null;
    collection.createRule = null;
    collection.updateRule = null;
    collection.deleteRule = null;
    app.save(collection);
  },
  (app) => {
    const collection = app.findCollectionByNameOrId("rotation_requests");
    collection.listRule = "";
    collection.viewRule = "";
    collection.createRule =
      "@request.auth.id != '' && @request.auth.id = @request.body.owner";
    collection.updateRule =
      "(@request.auth.id != '' && @request.auth.id = owner) || @request.auth.role = 'admin'";
    collection.deleteRule =
      "@request.auth.id != '' && @request.auth.id = owner";
    app.save(collection);
  },
);
