/// <reference path="../pb_data/types.d.ts" />

// 1. Fixes the `uploads` file field: PocketBase does NOT match wildcard mime
//    patterns such as "audio/*" — they are stored literally, so every real
//    upload (e.g. audio/mpeg) was rejected with "mime type must be one of...".
//    Replace the wildcards with an explicit list of accepted mime types.
// 2. Creates a `tracks` collection so artists can add tracks to the catalog
//    by uploading an audio file or pasting a direct audio URL. Tracks are
//    publicly readable (so the catalog renders for everyone) but only the
//    owner can create/edit/delete their own.
migrate(
  (app) => {
    // --- 1. Fix uploads.file mimeTypes ---
    const uploads = app.findCollectionByNameOrId("uploads");
    uploads.fields.removeByName("file");
    uploads.fields.add(
      new FileField({
        name: "file",
        maxSelect: 1,
        maxSize: 26214400, // 25 MB
        mimeTypes: [
          "audio/mpeg",
          "audio/mp3",
          "audio/wav",
          "audio/x-wav",
          "audio/ogg",
          "audio/webm",
          "audio/aac",
          "audio/flac",
          "audio/x-flac",
          "audio/x-m4a",
          "audio/m4a",
          "audio/mp4",
          "video/mp4",
          "video/webm",
          "video/ogg",
          "video/quicktime",
          "video/x-msvideo",
          "image/jpeg",
          "image/png",
          "image/webp",
          "image/gif",
          "image/svg+xml",
          "image/avif",
        ],
      }),
    );
    app.save(uploads);

    // --- 2. Create tracks collection ---
    const users = app.findCollectionByNameOrId("users");
    const tracks = new Collection({
      type: "base",
      name: "tracks",
      // Public read so the catalog renders for every visitor; writes are
      // owner-scoped.
      listRule: "",
      viewRule: "",
      createRule: "@request.auth.id != ''",
      updateRule: "@request.auth.id != '' && @request.auth.id = owner",
      deleteRule: "@request.auth.id != '' && @request.auth.id = owner",
      fields: [
        { name: "title", type: "text", required: true, max: 200 },
        { name: "credit", type: "text", max: 200 },
        { name: "genre", type: "text", max: 100 },
        {
          name: "audio_file",
          type: "file",
          maxSelect: 1,
          maxSize: 26214400, // 25 MB
          mimeTypes: [
            "audio/mpeg",
            "audio/mp3",
            "audio/wav",
            "audio/x-wav",
            "audio/ogg",
            "audio/webm",
            "audio/aac",
            "audio/flac",
            "audio/x-flac",
            "audio/x-m4a",
            "audio/m4a",
            "audio/mp4",
          ],
        },
        { name: "audio_url", type: "url", max: 2000 },
        {
          name: "owner",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: users.id,
          cascadeDelete: true,
        },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
    });
    app.save(tracks);
  },
  (app) => {
    try {
      const tracks = app.findCollectionByNameOrId("tracks");
      app.delete(tracks);
    } catch (e) {
      if (e && e.message && e.message.includes("no rows in result set")) {
        // already absent
      } else {
        throw e;
      }
    }
    // uploads.file mimeTypes left as the explicit list (wildcards were broken).
  },
);
